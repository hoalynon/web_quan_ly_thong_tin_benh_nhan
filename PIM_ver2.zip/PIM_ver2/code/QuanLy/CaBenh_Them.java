package QuanLy;



import java.awt.*;
import javax.swing.*;
import javax.swing.text.DateFormatter;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import com.toedter.calendar.JDateChooser;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CaBenh_Them implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonThem;

	private JRadioButton rbuttonTaiGia;
	private JRadioButton rbuttonNhapVien;
	private JRadioButton rbuttonCachLy;
	private ButtonGroup bgroupHinhThuc;
	
	private JTextField textfieldMaBN;
	private JTextField textfieldMaBS;
	private JTextField textfieldMaBenh;
	private JTextField textfieldMaPhong;
	
	private JDateChooser NgayBatDau;
	private JDateChooser NgayKetThuc;
	
	private JSpinner spinnerNgayBatDau;
	private JSpinner spinnerNgayKetThuc;
	
	private JComboBox comboBoxMucDo;
	private JComboBox comboBoxTinhTrang;
	
	private String listMucDo[]  = {"Khong cap cuu","Hoi Suc","Nang","Cham soc dac biet","Cap cuu"}; 
	private String listTinhTrang[]  = {"Hen kham","Dang dieu tri","Thanh cong","That bai"}; 


	CaBenh_Them(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel0 = new JPanel();
		panel0.setBackground(Color.decode("#d6e7ef"));
		panel0.setPreferredSize(new Dimension (160,60));
		panel0.setLayout(new BorderLayout());
		panelContent.add(panel0,BorderLayout.NORTH);
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (100,260));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.CENTER);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(new FlowLayout(FlowLayout.TRAILING,50,20));
		panelContent.add(panel2, BorderLayout.SOUTH);
		
		JLabel labelHeading = new JLabel("THEM MOI CA BENH");
        labelHeading.setFont(new Font("Bevan", Font.BOLD, 16));
        labelHeading.setForeground(new Color(40, 82, 106));
        labelHeading.setHorizontalAlignment(SwingConstants.CENTER);
        panel0.add(labelHeading, BorderLayout.CENTER);
		
		JLabel labelMaBN = new JLabel("Ma BN : ");
		labelMaBN.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBN.setBounds(30, 30, 115, 20);
		labelMaBN.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBN);
		
		textfieldMaBN = new JTextField();
		textfieldMaBN.setBounds(150, 30, 115, 20);
		textfieldMaBN.setColumns(10);
		panel1.add(textfieldMaBN);
		
		JLabel labelMaBS = new JLabel("Ma BS : ");
		labelMaBS.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBS.setBounds(30, 70, 115, 20);
		labelMaBS.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBS);
		
		textfieldMaBS = new JTextField();
		textfieldMaBS.setBounds(150, 70, 115, 20);
		textfieldMaBS.setColumns(10);
		panel1.add(textfieldMaBS);
		
		JLabel labelMaBenh = new JLabel("Ma Benh : ");
		labelMaBenh.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMaBenh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBenh.setBounds(30, 110, 115, 20);
		panel1.add(labelMaBenh);
		
		textfieldMaBenh = new JTextField();
		textfieldMaBenh.setColumns(10);
		textfieldMaBenh.setBounds(150, 110, 115, 20);
		panel1.add(textfieldMaBenh);
		
		JLabel labelMaPhong = new JLabel("Ma Phong : ");
		labelMaPhong.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMaPhong.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaPhong.setBounds(30, 150, 115, 20);
		panel1.add(labelMaPhong);
		
		textfieldMaPhong = new JTextField();
		textfieldMaPhong.setColumns(10);
		textfieldMaPhong.setBounds(150, 150, 115, 20);
		panel1.add(textfieldMaPhong);
		
		JLabel labelHinhThuc = new JLabel("Hinh Thuc : ");
		labelHinhThuc.setHorizontalAlignment(SwingConstants.RIGHT);
		labelHinhThuc.setFont(new Font("Bevan", Font.BOLD, 12));
		labelHinhThuc.setBounds(30, 190, 115, 20);
		panel1.add(labelHinhThuc);

		rbuttonTaiGia = new JRadioButton("Tai Gia");
		rbuttonTaiGia.setBackground(Color.decode("#d6e7ef"));
		rbuttonTaiGia.setBounds(150, 190, 70, 20);
		rbuttonTaiGia.setActionCommand("Tai gia");
		panel1.add(rbuttonTaiGia);
		
		rbuttonNhapVien = new JRadioButton("Nhap Vien");
		rbuttonNhapVien.setBackground(Color.decode("#d6e7ef"));
		rbuttonNhapVien.setBounds(220, 190, 90, 20);
		rbuttonNhapVien.setActionCommand("Nhap Vien");
		panel1.add(rbuttonNhapVien);
		
		rbuttonCachLy = new JRadioButton("Cach Ly");
		rbuttonCachLy.setBackground(Color.decode("#d6e7ef"));
		rbuttonCachLy.setBounds(310, 190, 70, 20);
		rbuttonCachLy.setActionCommand("Cach ly");
		panel1.add(rbuttonCachLy);
		
		bgroupHinhThuc = new ButtonGroup();
		bgroupHinhThuc.add(rbuttonTaiGia);
		bgroupHinhThuc.add(rbuttonNhapVien);
		bgroupHinhThuc.add(rbuttonCachLy);

		JLabel labelMucDo = new JLabel("Muc Do : ");
		labelMucDo.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMucDo.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMucDo.setBounds(300, 30, 115, 20);
		panel1.add(labelMucDo);
		
		comboBoxMucDo = new JComboBox(listMucDo);
		comboBoxMucDo.setBounds(420, 30, 115, 20);
		panel1.add(comboBoxMucDo);
		
		JLabel labelTinhTrang = new JLabel("Tinh Trang : ");
		labelTinhTrang.setHorizontalAlignment(SwingConstants.RIGHT);
		labelTinhTrang.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTinhTrang.setBounds(300, 70, 115, 20);
		panel1.add(labelTinhTrang);
		
		comboBoxTinhTrang = new JComboBox(listTinhTrang);
		comboBoxTinhTrang.setBounds(420, 70, 115, 20);
		panel1.add(comboBoxTinhTrang);
		
		JLabel labelNgayBatDau = new JLabel("Bat Dau: ");
		labelNgayBatDau.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgayBatDau.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgayBatDau.setBounds(300, 110, 115, 20);
		panel1.add(labelNgayBatDau);
		
		NgayBatDau = new JDateChooser();
		NgayBatDau.setBounds(420, 110, 115, 20);
		NgayBatDau.setFont(new Font("Bevan", Font.PLAIN, 12));
		NgayBatDau.setDateFormatString("dd/MM/yyyy");
		panel1.add(NgayBatDau);
		
		SpinnerDateModel modelNgayBatDau = new SpinnerDateModel();
        modelNgayBatDau.setValue(Calendar.getInstance().getTime());
        spinnerNgayBatDau = new JSpinner(modelNgayBatDau);
        JSpinner.DateEditor editorNgayBatDau = new JSpinner.DateEditor(spinnerNgayBatDau, "HH:mm:ss");
        spinnerNgayBatDau.setEditor(editorNgayBatDau);
        spinnerNgayBatDau.setBounds(540, 110, 80, 20);
        panel1.add(spinnerNgayBatDau);
        DateFormatter formatterNgayBatDau = (DateFormatter)editorNgayBatDau.getTextField().getFormatter();
        formatterNgayBatDau.setAllowsInvalid(false);
        formatterNgayBatDau.setOverwriteMode(true);
		
		JLabel labelNgayKetThuc = new JLabel("Ket Thuc: ");
		labelNgayKetThuc.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgayKetThuc.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgayKetThuc.setBounds(300, 150, 115, 20);
		panel1.add(labelNgayKetThuc);
		
		NgayKetThuc = new JDateChooser();
		NgayKetThuc.setBounds(420, 150, 115, 20);
		NgayKetThuc.setFont(new Font("Bevan", Font.PLAIN, 12));
		NgayKetThuc.setDateFormatString("dd/MM/yyyy");
		panel1.add(NgayKetThuc);
		
		SpinnerDateModel modelNgayKetThuc = new SpinnerDateModel();
        modelNgayKetThuc.setValue(Calendar.getInstance().getTime());
        spinnerNgayKetThuc = new JSpinner(modelNgayKetThuc);
        JSpinner.DateEditor editorNgayKetThuc = new JSpinner.DateEditor(spinnerNgayKetThuc, "HH:mm:ss");
        spinnerNgayKetThuc.setEditor(editorNgayKetThuc);
        spinnerNgayKetThuc.setBounds(540, 150, 80, 20);
        panel1.add(spinnerNgayKetThuc);
        DateFormatter formatterNgayKetThuc = (DateFormatter)editorNgayKetThuc.getTextField().getFormatter();
        formatterNgayKetThuc.setAllowsInvalid(false);
        formatterNgayKetThuc.setOverwriteMode(true);
		
		buttonThem = new JButton("    Them    ");
		buttonThem.setForeground(Color.decode("#28526a"));
		buttonThem.setBackground(Color.decode("#91B6C9"));
		buttonThem.addActionListener(this);
		buttonThem.setFont(new Font("Bevan", Font.BOLD, 12));
		//buttonThem.setBounds(80, 30, 85, 21);
		buttonThem.setBorderPainted(false);
		panel2.add(buttonThem);
	
	}
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == buttonThem) {
			Them();
		}
	}
	
	public void Them() {
		
		String stringNgayBatDau = "", stringSpinnerNgayBatDau = "", stringBatDau = "NULL";
		if (NgayBatDau.getDate() != null) {
			Date date = NgayBatDau.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			stringNgayBatDau = sdf.format(date);
			
			date = (Date)spinnerNgayBatDau.getValue();
            sdf = new SimpleDateFormat("HH:mm:ss");
            stringSpinnerNgayBatDau = sdf.format(date);
            stringBatDau = "TO_TIMESTAMP('" + stringNgayBatDau + " " + stringSpinnerNgayBatDau + "','DD/MM/YYYY HH24:MI:SS')";
		}
		
		String stringNgayKetThuc = "", stringSpinnerNgayKetThuc = "", stringKetThuc = "NULL";
		if (NgayKetThuc.getDate() != null) {
			Date date = NgayKetThuc.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			stringNgayKetThuc = sdf.format(date);
			
			date = (Date)spinnerNgayKetThuc.getValue();
            sdf = new SimpleDateFormat("HH:mm:ss");
            stringSpinnerNgayKetThuc = sdf.format(date);
            stringKetThuc = "TO_TIMESTAMP('" + stringNgayKetThuc + " " + stringSpinnerNgayKetThuc + "','DD/MM/YYYY HH24:MI:SS')";
		}
		
		String stringHinhThuc = ""; 
		if (bgroupHinhThuc.getSelection() != null) {
			stringHinhThuc = bgroupHinhThuc.getSelection().getActionCommand();
		}
		String query = "INSERT INTO CABENH VALUES ('"
							+ textfieldMaBN.getText() + "' , '"
							+ textfieldMaBS.getText() + "' , '"
							+ textfieldMaBenh.getText() + "' , '"
							+ comboBoxMucDo.getItemAt(comboBoxMucDo.getSelectedIndex()) + "' , '"
							+ stringHinhThuc + "' , "
							+ stringBatDau + " , "
							+ stringKetThuc + " , '"
							+ comboBoxTinhTrang.getItemAt(comboBoxTinhTrang.getSelectedIndex()) + "' , '"
							+ textfieldMaPhong.getText() + "')";
							
							
		System.out.println(query);					

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			int changedrows = statement.executeUpdate(query);
			if (changedrows > 0) {
				JOptionPane.showMessageDialog(null, "Them Moi Thanh Cong", "Thong Bao", JOptionPane.INFORMATION_MESSAGE);
			}
			
			statement.close();
			connection.close();
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		Refresh();
	}
	
	public void Refresh() {
		textfieldMaBN.setText("");
		textfieldMaBS.setText("");
		textfieldMaBenh.setText("");
		textfieldMaPhong.setText("");
		bgroupHinhThuc.clearSelection();
		NgayBatDau.setDate(null);
		NgayKetThuc.setDate(null);
		comboBoxMucDo.setSelectedIndex(0);
		comboBoxTinhTrang.setSelectedIndex(0);
		
		SpinnerDateModel modelNgayBatDau = new SpinnerDateModel();
        modelNgayBatDau.setValue(Calendar.getInstance().getTime());
        spinnerNgayBatDau.setModel(modelNgayBatDau);
        JSpinner.DateEditor editorNgayBatDau = new JSpinner.DateEditor(spinnerNgayBatDau, "HH:mm:ss");
        spinnerNgayBatDau.setEditor(editorNgayBatDau);
        DateFormatter formatterNgayBatDau = (DateFormatter)editorNgayBatDau.getTextField().getFormatter();
        formatterNgayBatDau.setAllowsInvalid(false);
        formatterNgayBatDau.setOverwriteMode(true);
        
        SpinnerDateModel modelNgayKetThuc = new SpinnerDateModel();
        modelNgayKetThuc.setValue(Calendar.getInstance().getTime());
        spinnerNgayKetThuc.setModel(modelNgayKetThuc);
        JSpinner.DateEditor editorNgayKetThuc = new JSpinner.DateEditor(spinnerNgayKetThuc, "HH:mm:ss");
        spinnerNgayKetThuc.setEditor(editorNgayKetThuc);
        DateFormatter formatterNgayKetThuc = (DateFormatter)editorNgayKetThuc.getTextField().getFormatter();
        formatterNgayKetThuc.setAllowsInvalid(false);
        formatterNgayKetThuc.setOverwriteMode(true);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
