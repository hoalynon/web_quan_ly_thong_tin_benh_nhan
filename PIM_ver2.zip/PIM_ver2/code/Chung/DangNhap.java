package Chung;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import BacSi.BSHome;
import BenhNhan.BNHome;
import QuanLy.QLHome;

public class DangNhap implements ActionListener{
	
	private static String DatabaseURL = "jdbc:oracle:thin:@localhost:1521:orcl2";
	private static String DatabaseUsername = "c##PIM";
	private static String DatabasePassword = "mypassword";
	
	private JFrame frame;
	private JPanel panelTitle;
	private JPanel panelContent;
	
	private JButton buttonDangNhap;
	
	private JTextField textfieldTenDangNhap;
	private JTextField textfieldMatKhau;
	
	private JPasswordField passwordfieldMatKhau;
	
	private JButton buttonView;
	private JButton buttonHide;
	
	private JLabel labeltitleName;
	
	
	public DangNhap(){
		
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800,450);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setBackground(Color.decode("#d6e7ef"));
		frame.getContentPane().setLayout(new BorderLayout());
		
		panelTitle = new JPanel();
		panelTitle.setBackground(new Color(128, 255, 255));
		panelTitle.setPreferredSize(new Dimension (50,50));

		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setPreferredSize(new Dimension (100,100));
		panelContent.setLayout(null);
		
		labeltitleName = new JLabel("Dang Nhap", SwingConstants.CENTER);
		labeltitleName.setForeground(Color.decode("#28526a"));
		labeltitleName.setFont(new Font("Bevan", Font.BOLD, 20));
		
		panelTitle.setLayout(new GridLayout());
		panelTitle.add(labeltitleName);
		
		JLabel labelTenDangNhap = new JLabel("Ten Dang Nhap : ");
		labelTenDangNhap.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTenDangNhap.setBounds(50, 30, 115, 20);
		labelTenDangNhap.setHorizontalAlignment(SwingConstants.RIGHT);
		panelContent.add(labelTenDangNhap);
		
		textfieldTenDangNhap = new JTextField();
		textfieldTenDangNhap.setBounds(170, 30, 115, 20);
		textfieldTenDangNhap.setColumns(10);
		panelContent.add(textfieldTenDangNhap);
		
		JLabel labelMatKhau = new JLabel("Mat Khau : ");
		labelMatKhau.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMatKhau.setBounds(50, 70, 115, 20);
		labelMatKhau.setHorizontalAlignment(SwingConstants.RIGHT);
		panelContent.add(labelMatKhau);
		
		textfieldMatKhau = new JTextField();
		textfieldMatKhau.setBounds(170, 70, 115, 20);
		textfieldMatKhau.setFont(new Font("Bevan", Font.PLAIN, 12));
		textfieldMatKhau.setColumns(10);
		textfieldMatKhau.addActionListener(this);
		panelContent.add(textfieldMatKhau);
		
		passwordfieldMatKhau = new JPasswordField();
		passwordfieldMatKhau.setBounds(170, 70, 115, 20);
		passwordfieldMatKhau.setFont(new Font("Bevan", Font.PLAIN, 12));
		passwordfieldMatKhau.setColumns(10);
		passwordfieldMatKhau.addActionListener(this);
		panelContent.add(passwordfieldMatKhau);
		
		buttonDangNhap = new JButton("Dang Nhap");
		buttonDangNhap.setForeground(Color.decode("#28526a"));
		buttonDangNhap.setBackground(Color.decode("#91B6C9"));
		buttonDangNhap.addActionListener(this);
		buttonDangNhap.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonDangNhap.setBorderPainted(false);
		buttonDangNhap.setBounds(170, 110, 115, 20);
		panelContent.add(buttonDangNhap);
		
		buttonView = new JButton(new ImageIcon("picture\\view.png"));
		buttonView.setBackground(Color.decode("#d6e7ef"));
		buttonView.addActionListener(this);
		buttonView.setBorderPainted(false);
		buttonView.setBounds(290, 67, 25, 25);
		panelContent.add(buttonView);
		buttonView.setVisible(false);
		
		buttonHide = new JButton(new ImageIcon("picture\\hide.png"));
		buttonHide.setBackground(Color.decode("#d6e7ef"));
		buttonHide.addActionListener(this);
		buttonHide.setBorderPainted(false);
		buttonHide.setBounds(290, 67, 25, 25);
		panelContent.add(buttonHide);
		
		frame.getContentPane().add(panelTitle,BorderLayout.NORTH);
		frame.getContentPane().add(panelContent,BorderLayout.CENTER);
		frame.setVisible(true);
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonDangNhap) {
			DangNhap();
		}
		if (e.getSource() == buttonView) {
			textfieldMatKhau.setText(passwordfieldMatKhau.getText());
			passwordfieldMatKhau.setVisible(false);
			textfieldMatKhau.setVisible(true);
			buttonHide.setVisible(true);
			buttonView.setVisible(false);
		}
		if (e.getSource() == buttonHide) {
			passwordfieldMatKhau.setText(textfieldMatKhau.getText());
			textfieldMatKhau.setVisible(false);
			passwordfieldMatKhau.setVisible(true);
			buttonView.setVisible(true);
			buttonHide.setVisible(false);
		}
	}
	public void DangNhap() {
		
		String query = "SELECT * FROM TAIKHOAN WHERE TENDANGNHAP = '" + textfieldTenDangNhap.getText() +"'";
		if (textfieldMatKhau.isVisible()) {
			if(textfieldMatKhau.getText().equals("")) {
				query += " AND MATKHAU IS NULL";
			}
			else {
				query += " AND MATKHAU = '" + textfieldMatKhau.getText() + "'";
			}
		}
		else if (passwordfieldMatKhau.isVisible()){
			if(passwordfieldMatKhau.getText().equals("")) {
				query += " AND MATKHAU IS NULL";
			}
			else {
				query += " AND MATKHAU = '" + passwordfieldMatKhau.getText() + "'";
			}
		}
		System.out.println(query);

		try {
			Connection connection = DriverManager.getConnection(DatabaseURL, DatabaseUsername, DatabasePassword);
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			
			if (resultset.next())
			{
				if (textfieldTenDangNhap.getText().substring(0,2).equals("BN")) {
					new BNHome(this);
					frame.dispose();
				}
				else if (textfieldTenDangNhap.getText().substring(0,2).equals("BS")) {
					new BSHome(this);
					frame.dispose();
				}
				else if (textfieldTenDangNhap.getText().substring(0,2).equals("QL")) {
					new QLHome(this);
					frame.dispose();
				}
			}
			else {
				JOptionPane.showMessageDialog(null, "Loi: " + "Thong tin khong hop le !\n\tVui long dang nhap lai.", "Loi", JOptionPane.ERROR_MESSAGE);
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
	
	public String getID() {
		return textfieldTenDangNhap.getText();
	}
	public String getDatabaseURL() {
		return DatabaseURL;
	}
	public String getDatabaseUsername() {
		return DatabaseUsername;
	}
	public String getDatabasePassword() {
		return DatabasePassword;
	}
	public JFrame getFrame() {
		return frame;
	}
	
	public JPanel getPanelContent() {
		return panelContent;
	}

}
	

