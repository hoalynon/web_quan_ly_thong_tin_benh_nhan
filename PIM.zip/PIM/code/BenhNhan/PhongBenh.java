package BenhNhan;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import java.sql.*;
import java.util.*;


public class PhongBenh implements ActionListener{
	
	private BNHome MyHome;
	private JPanel panelContent;
	private JButton buttonTraCuu;
	
	private JRadioButton rbuttonThuongTraCuu;
	private JRadioButton rbuttonVIPTraCuu;
	private JRadioButton rbuttonCachLyTraCuu;
	private ButtonGroup bgroupLoaiTraCuu;
	
	private JTextField textfieldChiTietTraCuu;
	
	private JTable table;
	private JComboBox comboBoxLoaiTraCuu;
	
	private String listLoaiTraCuu[]  = {"Tat Ca","Ma Phong","Loai","Toa","Lau","Suc Chua","Con Trong"}; 

	
	PhongBenh(BNHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (80,80));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.NORTH);
		
		JLabel labelLoaiTraCuu = new JLabel("Loai Tra Cuu : ");
		labelLoaiTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelLoaiTraCuu.setBounds(10, 30, 80, 20);
		labelLoaiTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelLoaiTraCuu);
		
		comboBoxLoaiTraCuu = new JComboBox(listLoaiTraCuu);
		comboBoxLoaiTraCuu.setBounds(90, 30, 80, 20);
		comboBoxLoaiTraCuu.addActionListener(this);
		panel1.add(comboBoxLoaiTraCuu);
		
		JLabel labelChiTietTraCuu = new JLabel("Chi Tiet Tra Cuu : ");
		labelChiTietTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		labelChiTietTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelChiTietTraCuu.setBounds(210, 30, 120, 20);
		panel1.add(labelChiTietTraCuu);
		
		textfieldChiTietTraCuu = new JTextField();
		textfieldChiTietTraCuu.setColumns(10);
		textfieldChiTietTraCuu.setBounds(330, 30, 80, 20);
		panel1.add(textfieldChiTietTraCuu);
		
		rbuttonThuongTraCuu = new JRadioButton("Thuong");
		rbuttonThuongTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonThuongTraCuu.setBounds(330, 30, 50, 20);
		rbuttonThuongTraCuu.setActionCommand("Thuong");
		rbuttonThuongTraCuu.setVisible(false);
		panel1.add(rbuttonThuongTraCuu);
		
		rbuttonVIPTraCuu = new JRadioButton("VIP");
		rbuttonVIPTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonVIPTraCuu.setBounds(380, 30, 50, 20);
		rbuttonVIPTraCuu.setActionCommand("VIP");
		rbuttonVIPTraCuu.setVisible(false);
		panel1.add(rbuttonVIPTraCuu);
		
		rbuttonCachLyTraCuu = new JRadioButton("Cach Ly");
		rbuttonCachLyTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonCachLyTraCuu.setBounds(430, 30, 50, 20);
		rbuttonCachLyTraCuu.setActionCommand("Cach ly");
		rbuttonCachLyTraCuu.setVisible(false);
		panel1.add(rbuttonCachLyTraCuu);
		
		bgroupLoaiTraCuu = new ButtonGroup();
		bgroupLoaiTraCuu.add(rbuttonThuongTraCuu);
		bgroupLoaiTraCuu.add(rbuttonVIPTraCuu);
		bgroupLoaiTraCuu.add(rbuttonCachLyTraCuu);
		
		
		buttonTraCuu = new JButton("Tra Cuu");
		buttonTraCuu.setForeground(Color.decode("#28526a"));
		buttonTraCuu.setBackground(Color.decode("#91B6C9"));
		buttonTraCuu.addActionListener(this);
		buttonTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonTraCuu.setBounds(500, 30, 85, 21);
		buttonTraCuu.setBorderPainted(false);
		panel1.add(buttonTraCuu);
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setPreferredSize(new Dimension (100, 100));
		panelContent.add(scrollPane,BorderLayout.CENTER);
		
		table = new JTable() {
			boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false
				};
			@Override
		    public boolean isCellEditable(int rowIndex, int columnIndex)
		    {
		        return columnEditables[columnIndex];
		    }	};
		table.setBackground(Color.decode("#d6e7ef"));
		table.setFont(new Font("Bevan", Font.PLAIN, 10));
		
		setInformation();
		scrollPane.setViewportView(table);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonTraCuu) {
			TraCuu();
		}
		else if (e.getSource() == comboBoxLoaiTraCuu) {
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Loai")) {
				setVisibleFalseForAllChiTietTraCuu();
				rbuttonThuongTraCuu.setVisible(true);
				rbuttonVIPTraCuu.setVisible(true);
				rbuttonCachLyTraCuu.setVisible(true);
			}
			else
			{
				setVisibleFalseForAllChiTietTraCuu();
				textfieldChiTietTraCuu.setVisible(true);
			}
		}
	}
	

public void setInformation() { 
		
		String query = "SELECT * FROM PHONGBENH ORDER BY MAPHONG ASC";

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma Phong","Loai","Toa","Lau","Suc Chua","Con Trong"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			} 
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
}
	

public void TraCuu() { 
	
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tat Ca")
				|| (!(textfieldChiTietTraCuu.getText().equals("")))
				|| (!(bgroupLoaiTraCuu.getSelection() == null))) {
		
		String query = "SELECT * FROM PHONGBENH WHERE MAPHONG = MAPHONG";
		
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma Phong")) {
			query += " AND MAPHONG = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Toa")) {
			query += " AND TOA = " + textfieldChiTietTraCuu.getText();
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Lau")) {
			query += " AND LAU = " + textfieldChiTietTraCuu.getText();
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Suc Chua")) {
			query += " AND SUCCHUA = " + textfieldChiTietTraCuu.getText();
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Con Trong")) {
			query += " AND CONTRONG = " + textfieldChiTietTraCuu.getText();
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Loai") ) {
			query += " AND LOAI = '" + bgroupLoaiTraCuu.getSelection().getActionCommand() + "'";
		}
		
			query += " ORDER BY MAPHONG ASC";
			
		System.out.println(query);


			try {
				Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
				Statement statement = connection.createStatement();
				ResultSet resultset = statement.executeQuery(query);
				ResultSetMetaData metadata = resultset.getMetaData();
				int columnCount = metadata.getColumnCount();
				DefaultTableModel data = (DefaultTableModel) table.getModel();
				
				data.setColumnIdentifiers(new String[] {"Ma Phong","Loai","Toa","Lau","Suc Chua","Con Trong"});
				data.setRowCount(0);
				
				while(resultset.next()) {
					Vector row = new Vector();
					for (int i = 0; i < columnCount; i++)
						row.add(resultset.getString(i+1));
					data.addRow(row);
				
				}
				
				
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
		}
		 RefreshForTraCuu();
	}

	
	public void RefreshForTraCuu() {
		//comboBoxLoaiTraCuu.setSelectedIndex(0);
		bgroupLoaiTraCuu.clearSelection();
		textfieldChiTietTraCuu.setText("");
	}
	
	public void setVisibleFalseForAllChiTietTraCuu() {
		rbuttonThuongTraCuu.setVisible(false);
		rbuttonVIPTraCuu.setVisible(false);
		rbuttonCachLyTraCuu.setVisible(false);
		textfieldChiTietTraCuu.setVisible(false);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
