package QuanLy;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import com.toedter.calendar.JDateChooser;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ThietBiYTe_Them implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonThem;
	private JButton buttonQuayLai;
	
	private JRadioButton rbutton1Lan;
	private JRadioButton rbuttonTaiSuDung;
	private ButtonGroup bgroupLoaiSD;
	
	private JTextField textfieldMaThietBi;
	private JTextField textfieldTenThietBi;
	private JTextField textfieldCongDung;
	private JTextField textfieldSoLuong;


	ThietBiYTe_Them(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (100,300));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.CENTER);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(null);
		panelContent.add(panel2, BorderLayout.SOUTH);
		
		JLabel labelMaThietBi = new JLabel("Ma Thiet Bi : ");
		labelMaThietBi.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaThietBi.setBounds(10, 10, 80, 20);
		labelMaThietBi.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaThietBi);
		
		textfieldMaThietBi = new JTextField();
		textfieldMaThietBi.setBounds(90, 10, 80, 20);
		textfieldMaThietBi.setColumns(10);
		panel1.add(textfieldMaThietBi);
		
		JLabel labelTenThietBi = new JLabel("Ten Thiet Bi : ");
		labelTenThietBi.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTenThietBi.setBounds(10, 40, 80, 20);
		labelTenThietBi.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelTenThietBi);
		
		textfieldTenThietBi = new JTextField();
		textfieldTenThietBi.setBounds(90, 40, 80, 20);
		textfieldTenThietBi.setColumns(10);
		panel1.add(textfieldTenThietBi);
		
		JLabel labelCongDung = new JLabel("Cong Dung : ");
		labelCongDung.setHorizontalAlignment(SwingConstants.RIGHT);
		labelCongDung.setFont(new Font("Bevan", Font.BOLD, 12));
		labelCongDung.setBounds(10, 70, 80, 20);
		panel1.add(labelCongDung);
		
		textfieldCongDung = new JTextField();
		textfieldCongDung.setColumns(10);
		textfieldCongDung.setBounds(90, 70, 80, 20);
		panel1.add(textfieldCongDung);
		
		JLabel labelSoLuong = new JLabel("So Luong : ");
		labelSoLuong.setHorizontalAlignment(SwingConstants.RIGHT);
		labelSoLuong.setFont(new Font("Bevan", Font.BOLD, 12));
		labelSoLuong.setBounds(10, 100, 80, 20);
		panel1.add(labelSoLuong);
		
		textfieldSoLuong = new JTextField();
		textfieldSoLuong.setColumns(10);
		textfieldSoLuong.setBounds(90, 100, 80, 20);
		panel1.add(textfieldSoLuong);
		
		JLabel labelLoaiSD = new JLabel("Loai SD : ");
		labelLoaiSD.setHorizontalAlignment(SwingConstants.RIGHT);
		labelLoaiSD.setFont(new Font("Bevan", Font.BOLD, 12));
		labelLoaiSD.setBounds(180, 10, 80, 20);
		panel1.add(labelLoaiSD);

		rbutton1Lan = new JRadioButton("1 Lan");
		rbutton1Lan.setBackground(Color.decode("#d6e7ef"));
		rbutton1Lan.setBounds(260, 10, 50, 20);
		rbutton1Lan.setActionCommand("1 lan");
		panel1.add(rbutton1Lan);
		
		rbuttonTaiSuDung = new JRadioButton("Tai Su Dung");
		rbuttonTaiSuDung.setBackground(Color.decode("#d6e7ef"));
		rbuttonTaiSuDung.setBounds(310, 10, 50, 20);
		rbuttonTaiSuDung.setActionCommand("Tai su dung");
		panel1.add(rbuttonTaiSuDung);
		
		bgroupLoaiSD = new ButtonGroup();
		bgroupLoaiSD.add(rbutton1Lan);
		bgroupLoaiSD.add(rbuttonTaiSuDung);
		
		buttonThem = new JButton("Them");
		buttonThem.setForeground(Color.decode("#28526a"));
		buttonThem.setBackground(Color.decode("#91B6C9"));
		buttonThem.addActionListener(this);
		buttonThem.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonThem.setBounds(80, 30, 85, 21);
		buttonThem.setBorderPainted(false);
		panel2.add(buttonThem);
		
		buttonQuayLai = new JButton("Quay Lai");
		buttonQuayLai.addActionListener(this);
		buttonQuayLai.setForeground(Color.decode("#28526a"));
		buttonQuayLai.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonQuayLai.setBackground(Color.decode("#91B6C9"));
		buttonQuayLai.setBounds(450, 30, 85, 21);
		buttonQuayLai.setBorderPainted(false);
		panel2.add(buttonQuayLai);

	}
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == buttonThem) {
			Them();
		}
		else if (e.getSource() == buttonQuayLai) {
			QuayLai();
		}
	}
	
	public void Them() {
		
		if (textfieldSoLuong.getText().equals("")) {
			textfieldSoLuong.setText("null");
		}
		
		String stringLoaiSD = ""; 
		if (bgroupLoaiSD.getSelection() != null) {
			stringLoaiSD = bgroupLoaiSD.getSelection().getActionCommand();
		}
		String query = "INSERT INTO THIETBIYTE VALUES ('"
							+ textfieldMaThietBi.getText() + "' , '"
							+ textfieldTenThietBi.getText() + "' , '"
							+ stringLoaiSD + "' , '"
							+ textfieldCongDung.getText() + "' , "
							+ textfieldSoLuong.getText() + ")";
							
							
		System.out.println(query);					

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			int changedrows = statement.executeUpdate(query);
			if (changedrows > 0) {
				JOptionPane.showMessageDialog(null, "Them Moi Thanh Cong", "Thong Bao", JOptionPane.INFORMATION_MESSAGE);
			}
			
			statement.close();
			connection.close();
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		Refresh();
	}
	
	public void QuayLai() {
		MyHome.getPanelContent().removeAll();
		switch (MyHome.getPreviousClass("ThietBiYTe","Them")) {
		case "ThietBiYTe":
			MyHome.getPanelContent().add(new ThietBiYTe(MyHome).getpanelContent());
			break;
		}
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
	}
	
	public void Refresh() {
		textfieldMaThietBi.setText("");
		textfieldTenThietBi.setText("");
		textfieldCongDung.setText("");
		textfieldSoLuong.setText("");
		bgroupLoaiSD.clearSelection();
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
