package QuanLy;



import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;

import Chung.DangNhap;

public class QLHome implements ActionListener{
	
	private String ID = "";
	private String DatabaseURL = "";
	private String DatabaseUsername = "";
	private String DatabasePassword = "";
	
	private JFrame frame;
	private JPanel panelTitle;
	private JPanel panelMenu;
	private JPanel panelContent;
	
	private JButton buttonBacSi;
	private JButton buttonBenhNhan;
	private JButton buttonBenh;
	private JButton buttonCaBenh;
	private JButton buttonPhongBenh;
	private JButton buttonThietBiYTe;
	private JButton buttonDieuPhoiThietBi;
	private JButton buttonTaiKhoan;
	private JButton buttonDangXuat;
	
	private JLabel labeltitleName;
	private JLabel labeltitleMenu;
	
	private String [][][] previousClass = new String[8][5][2];
	
	public QLHome(DangNhap dangnhap){
		
		this.ID = dangnhap.getID();
		this.DatabaseURL = dangnhap.getDatabaseURL();
		this.DatabaseUsername = dangnhap.getDatabaseUsername();
		this.DatabasePassword = dangnhap.getDatabasePassword();
		
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(dangnhap.getFrame().getSize());
		frame.setLocation(dangnhap.getFrame().getLocation());
		frame.setExtendedState(dangnhap.getFrame().getExtendedState());
		//frame.setLocationRelativeTo(null);
		frame.getContentPane().setBackground(Color.decode("#d6e7ef"));
		frame.getContentPane().setLayout(new BorderLayout());
		
		panelTitle = new JPanel();
		panelTitle.setBackground(new Color(128, 255, 255));
		panelTitle.setPreferredSize(new Dimension (50,50));
		
		panelMenu = new JPanel();
		panelMenu.setBackground(new Color(128, 255, 255));
		panelMenu.setPreferredSize(new Dimension (150,100));
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setPreferredSize(new Dimension (100,100));
		panelContent.setLayout(new BorderLayout());
		
		labeltitleMenu = new JLabel("Trang Chu", SwingConstants.LEFT);
		labeltitleMenu.setForeground(Color.decode("#28526a"));
		labeltitleMenu.setFont(new Font("Bevan", Font.BOLD, 15));
		
		labeltitleName = new JLabel("QUAN LY", SwingConstants.RIGHT);
		labeltitleName.setForeground(Color.decode("#28526a"));
		labeltitleName.setFont(new Font("Bevan", Font.BOLD, 15));
		
		panelTitle.setLayout(new GridLayout());
		panelTitle.add(labeltitleMenu);
		panelTitle.add(labeltitleName);
		
		panelMenu.setLayout(new GridLayout(9,1,0,0));
		
			
		buttonBacSi = new JButton("Bac Si");
		buttonBacSi.setBackground(new Color(128, 255, 255));
		buttonBacSi.setForeground(new Color(0,51,102));
		buttonBacSi.setFont(new Font("Bevan", Font.BOLD, 15));
		buttonBacSi.addActionListener(this);
		buttonBacSi.setBorderPainted(false);
		panelMenu.add(buttonBacSi);
		
		buttonBenhNhan = new JButton("Benh Nhan");
		buttonBenhNhan.setBackground(new Color(128, 255, 255));
		buttonBenhNhan.setForeground(new Color(0,51,102));
		buttonBenhNhan.setFont(new Font("Bevan", Font.BOLD, 15));
		buttonBenhNhan.addActionListener(this);
		buttonBenhNhan.setBorderPainted(false);
		panelMenu.add(buttonBenhNhan);
		
		buttonBenh = new JButton("Benh");
		buttonBenh.setBackground(new Color(128, 255, 255));
		buttonBenh.setForeground(new Color(0,51,102));
		buttonBenh.setFont(new Font("Bevan", Font.BOLD, 15));
		buttonBenh.addActionListener(this);
		buttonBenh.setBorderPainted(false);
		panelMenu.add(buttonBenh);
		
		buttonCaBenh = new JButton("Ca Benh");
		buttonCaBenh.setBackground(new Color(128, 255, 255));
		buttonCaBenh.setForeground(new Color(0,51,102));
		buttonCaBenh.setFont(new Font("Bevan", Font.BOLD, 15));
		buttonCaBenh.addActionListener(this);
		buttonCaBenh.setBorderPainted(false);
		panelMenu.add(buttonCaBenh);
		
		buttonPhongBenh = new JButton("Phong Benh");
		buttonPhongBenh.setBackground(new Color(128, 255, 255));
		buttonPhongBenh.setForeground(new Color(0,51,102));
		buttonPhongBenh.setFont(new Font("Bevan", Font.BOLD, 15));
		buttonPhongBenh.addActionListener(this);
		buttonPhongBenh.setBorderPainted(false);
		panelMenu.add(buttonPhongBenh);
		
		buttonThietBiYTe = new JButton("Thiet Bi Y Te");
		buttonThietBiYTe.setBackground(new Color(128, 255, 255));
		buttonThietBiYTe.setForeground(new Color(0,51,102));
		buttonThietBiYTe.setFont(new Font("Bevan", Font.BOLD, 15));
		buttonThietBiYTe.addActionListener(this);
		buttonThietBiYTe.setBorderPainted(false);
		panelMenu.add(buttonThietBiYTe);
		
		buttonDieuPhoiThietBi = new JButton("Dieu Phoi Thiet Bi");
		buttonDieuPhoiThietBi.setBackground(new Color(128, 255, 255));
		buttonDieuPhoiThietBi.setForeground(new Color(0,51,102));
		buttonDieuPhoiThietBi.setFont(new Font("Bevan", Font.BOLD, 15));
		buttonDieuPhoiThietBi.addActionListener(this);
		buttonDieuPhoiThietBi.setBorderPainted(false);
		panelMenu.add(buttonDieuPhoiThietBi);
		
		buttonTaiKhoan = new JButton("Tai Khoan");
		buttonTaiKhoan.setBackground(new Color(128, 255, 255));
		buttonTaiKhoan.setForeground(new Color(0,51,102));
		buttonTaiKhoan.setFont(new Font("Bevan", Font.BOLD, 15));
		buttonTaiKhoan.addActionListener(this);
		buttonTaiKhoan.setBorderPainted(false);
		panelMenu.add(buttonTaiKhoan);
		
		buttonDangXuat = new JButton("Dang Xuat");
		buttonDangXuat.setBackground(new Color(128, 255, 255));
		buttonDangXuat.setForeground(new Color(0,51,102));
		buttonDangXuat.setFont(new Font("Bevan", Font.BOLD, 15));
		buttonDangXuat.addActionListener(this);
		buttonDangXuat.setBorderPainted(false);
		panelMenu.add(buttonDangXuat);
		
		frame.getContentPane().add(panelTitle,BorderLayout.NORTH);
		frame.getContentPane().add(panelMenu,BorderLayout.WEST);
		frame.getContentPane().add(panelContent,BorderLayout.CENTER);
		
		frame.setVisible(true);
		
		setPreviousClass("init","init","init");
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonBacSi) {
			BacSi();
		}
		else if (e.getSource() == buttonBenhNhan) {
			BenhNhan();
		}
		else if (e.getSource() == buttonBenh) {
			Benh();
		}
		else if (e.getSource() == buttonCaBenh) {
			CaBenh();
		}
		else if (e.getSource() == buttonPhongBenh) {
			PhongBenh();
		}
		else if (e.getSource() == buttonThietBiYTe) {
			ThietBiYTe();
		}
		else if (e.getSource() == buttonDieuPhoiThietBi) {
			DieuPhoiThietBi();
		}
		else if (e.getSource() == buttonTaiKhoan) {
			TaiKhoan();
		}
		else if (e.getSource() == buttonDangXuat) {
			DangNhap dangnhap = new DangNhap();
			dangnhap.getFrame().setSize(frame.getSize());
			dangnhap.getFrame().setLocation(frame.getLocation());
			dangnhap.getFrame().setExtendedState(frame.getExtendedState());
			frame.dispose();
		}
	}
	
	public void BacSi() {
		panelContent.removeAll();
		panelContent.add(new BacSi(this).getpanelContent());
		panelContent.validate();
		panelContent.repaint();
		
		labeltitleMenu.setText("Bac Si");
		RefreshMenuBackground();
		buttonBacSi.setBackground(Color.decode("#d6e7ef"));
	}
	public void BenhNhan() {
		panelContent.removeAll();
		panelContent.add(new BenhNhan(this).getpanelContent());
		panelContent.validate();
		panelContent.repaint();
		
		labeltitleMenu.setText("Benh Nhan");
		RefreshMenuBackground();
		buttonBenhNhan.setBackground(Color.decode("#d6e7ef"));
	}
	public void Benh() {
		panelContent.removeAll();
		panelContent.add(new Benh(this).getpanelContent());
		panelContent.validate();
		panelContent.repaint();
		
		labeltitleMenu.setText("Benh");
		RefreshMenuBackground();
		buttonBenh.setBackground(Color.decode("#d6e7ef"));
	}
	public void CaBenh() {
		panelContent.removeAll();
		panelContent.add(new CaBenh(this).getpanelContent());
		panelContent.validate();
		panelContent.repaint();
		
		labeltitleMenu.setText("Ca Benh");
		RefreshMenuBackground();
		buttonCaBenh.setBackground(Color.decode("#d6e7ef"));
	}
	public void PhongBenh() {
		panelContent.removeAll();
		panelContent.add(new PhongBenh(this).getpanelContent());
		panelContent.validate();
		panelContent.repaint();
		
		labeltitleMenu.setText("Phong Benh");
		RefreshMenuBackground();
		buttonPhongBenh.setBackground(Color.decode("#d6e7ef"));
	}
	public void ThietBiYTe() {
		panelContent.removeAll();
		panelContent.add(new ThietBiYTe(this).getpanelContent());
		panelContent.validate();
		panelContent.repaint();
		
		labeltitleMenu.setText("Thiet Bi Y Te");
		RefreshMenuBackground();
		buttonThietBiYTe.setBackground(Color.decode("#d6e7ef"));
	}
	public void DieuPhoiThietBi() {
		panelContent.removeAll();
		panelContent.add(new DieuPhoiThietBi(this).getpanelContent());
		panelContent.validate();
		panelContent.repaint();
		
		labeltitleMenu.setText("Dieu Phoi Thiet Bi");
		RefreshMenuBackground();
		buttonDieuPhoiThietBi.setBackground(Color.decode("#d6e7ef"));
	}
	public void TaiKhoan() {
		panelContent.removeAll();
		panelContent.add(new TaiKhoan(this).getpanelContent());
		panelContent.validate();
		panelContent.repaint();
		
		labeltitleMenu.setText("Tai Khoan");
		RefreshMenuBackground();
		buttonTaiKhoan.setBackground(Color.decode("#d6e7ef"));
	}
	public String getID() {
		return this.ID;
	}
	public String getDatabaseURL() {
		return DatabaseURL;
	}
	public String getDatabaseUsername() {
		return DatabaseUsername;
	}
	public String getDatabasePassword() {
		return DatabasePassword;
	}
	public JFrame getFrame() {
		return frame;
	}
	
	public JPanel getPanelContent() {
		return panelContent;
	}
	
	public void RefreshMenuBackground() {
		buttonBacSi.setBackground(new Color(128, 255, 255));
		buttonBenhNhan.setBackground(new Color(128, 255, 255));
		buttonBenh.setBackground(new Color(128, 255, 255));
		buttonCaBenh.setBackground(new Color(128, 255, 255));
		buttonPhongBenh.setBackground(new Color(128, 255, 255));
		buttonThietBiYTe.setBackground(new Color(128, 255, 255));
		buttonDieuPhoiThietBi.setBackground(new Color(128, 255, 255));
		buttonTaiKhoan.setBackground(new Color(128, 255, 255));
		buttonDangXuat.setBackground(new Color(128, 255, 255));
	}
	
	public void setPreviousClass(String TypeToSet, String ClassToSet, String value) {
			if (TypeToSet == "init" && ClassToSet == "init" && value == "init") {
				
				previousClass[0][0][0] = "BacSi";
				previousClass[1][0][0] = "BenhNhan";
				previousClass[2][0][0] = "Benh";
				previousClass[3][0][0] = "CaBenh";
				previousClass[4][0][0] = "PhongBenh";
				previousClass[5][0][0] = "ThietBiYTe";
				previousClass[6][0][0] = "DieuPhoiThietBi";
				previousClass[6][0][0] = "TaiKhoan";
				
				for (int y = 0; y < 8; y++) {
				previousClass[y][1][0] = "TraCuu";
				previousClass[y][2][0] = "Them";
				previousClass[y][3][0] = "CapNhat";
				previousClass[y][4][0] = "Xoa";
				}
			}
			
			else {
				for (int y = 0; y < 8; y++) {
					if (previousClass[y][0][0] == TypeToSet) {
						for (int x = 1; x < 5; x++) {
							if (previousClass[y][x][0] == ClassToSet) {
								previousClass[y][x][1] = value;
								break;
							}
						}
						break;
					}
				}
			}
	}
	
	public String getPreviousClass(String TypeToGet, String ClassToGet) {
		for (int y = 0; y < 8; y++) {
			if (previousClass[y][0][0] == TypeToGet) {
				for (int x = 1; x < 5; x++) {
					if (previousClass[y][x][0] == ClassToGet) {
						return previousClass[y][x][1];
					}
				}
			}
		}
		return "";
	}
}
