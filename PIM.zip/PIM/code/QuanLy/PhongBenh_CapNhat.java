package QuanLy;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import java.sql.*;
import java.util.*;

public class PhongBenh_CapNhat implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonTraCuu;
	private JButton buttonCapNhat;
	private JButton buttonQuayLai;
	
	private JRadioButton rbuttonThuong;
	private JRadioButton rbuttonVIP;
	private JRadioButton rbuttonCachLy;
	private ButtonGroup bgroupLoai;
	private JRadioButton rbuttonThuongTraCuu;
	private JRadioButton rbuttonVIPTraCuu;
	private JRadioButton rbuttonCachLyTraCuu;
	private ButtonGroup bgroupLoaiTraCuu;
	
	private JTextField textfieldMaPhong;
	private JTextField textfieldToa;
	private JTextField textfieldLau;
	private JTextField textfieldSucChua;
	private JTextField textfieldConTrong;
	private JTextField textfieldChiTietTraCuu;
	
	private JTable table;
	private JComboBox comboBoxLoaiTraCuu;
	
	private String listLoaiTraCuu[]  = {"Tat Ca","Ma Phong","Loai","Toa","Lau","Suc Chua","Con Trong"}; 
	
	PhongBenh_CapNhat(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (160,160));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.NORTH);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(null);
		panelContent.add(panel2, BorderLayout.SOUTH);

		JLabel labelMaPhong = new JLabel("Ma Phong : ");
		labelMaPhong.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaPhong.setBounds(10, 10, 80, 20);
		labelMaPhong.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaPhong);
		
		textfieldMaPhong = new JTextField();
		textfieldMaPhong.setBounds(90, 10, 80, 20);
		textfieldMaPhong.setColumns(10);
		panel1.add(textfieldMaPhong);
		
		JLabel labelToa = new JLabel("Toa : ");
		labelToa.setFont(new Font("Bevan", Font.BOLD, 12));
		labelToa.setBounds(10, 40, 80, 20);
		labelToa.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelToa);
		
		textfieldToa = new JTextField();
		textfieldToa.setBounds(90, 40, 80, 20);
		textfieldToa.setColumns(10);
		panel1.add(textfieldToa);
		
		JLabel labelLau = new JLabel("Lau : ");
		labelLau.setHorizontalAlignment(SwingConstants.RIGHT);
		labelLau.setFont(new Font("Bevan", Font.BOLD, 12));
		labelLau.setBounds(10, 70, 80, 20);
		panel1.add(labelLau);
		
		textfieldLau = new JTextField();
		textfieldLau.setColumns(10);
		textfieldLau.setBounds(90, 70, 80, 20);
		panel1.add(textfieldLau);
		
		JLabel labelSucChua = new JLabel("Suc Chua : ");
		labelSucChua.setHorizontalAlignment(SwingConstants.RIGHT);
		labelSucChua.setFont(new Font("Bevan", Font.BOLD, 12));
		labelSucChua.setBounds(10, 100, 80, 20);
		panel1.add(labelSucChua);
		
		textfieldSucChua = new JTextField();
		textfieldSucChua.setColumns(10);
		textfieldSucChua.setBounds(90, 100, 80, 20);
		panel1.add(textfieldSucChua);
		
		JLabel labelConTrong = new JLabel("Con Trong : ");
		labelConTrong.setHorizontalAlignment(SwingConstants.RIGHT);
		labelConTrong.setFont(new Font("Bevan", Font.BOLD, 12));
		labelConTrong.setBounds(180, 40, 80, 20);
		panel1.add(labelConTrong);
		
		textfieldConTrong = new JTextField();
		textfieldConTrong.setColumns(10);
		textfieldConTrong.setBounds(260, 40, 80, 20);
		panel1.add(textfieldConTrong);
		
		JLabel labelLoai = new JLabel("Loai : ");
		labelLoai.setHorizontalAlignment(SwingConstants.RIGHT);
		labelLoai.setFont(new Font("Bevan", Font.BOLD, 12));
		labelLoai.setBounds(180, 10, 80, 20);
		panel1.add(labelLoai);

		rbuttonThuong = new JRadioButton("Thuong");
		rbuttonThuong.setBackground(Color.decode("#d6e7ef"));
		rbuttonThuong.setBounds(260, 10, 50, 20);
		rbuttonThuong.setActionCommand("Thuong");
		panel1.add(rbuttonThuong);
		
		rbuttonVIP = new JRadioButton("VIP");
		rbuttonVIP.setBackground(Color.decode("#d6e7ef"));
		rbuttonVIP.setBounds(310, 10, 50, 20);
		rbuttonVIP.setActionCommand("VIP");
		panel1.add(rbuttonVIP);
		
		rbuttonCachLy = new JRadioButton("Cach Ly");
		rbuttonCachLy.setBackground(Color.decode("#d6e7ef"));
		rbuttonCachLy.setBounds(360, 10, 50, 20);
		rbuttonCachLy.setActionCommand("Cach ly");
		panel1.add(rbuttonCachLy);
		
		bgroupLoai = new ButtonGroup();
		bgroupLoai.add(rbuttonThuong);
		bgroupLoai.add(rbuttonVIP);
		bgroupLoai.add(rbuttonCachLy);
	
		//////////////////////////////////////////////////////////
		
		JLabel labelLoaiTraCuu = new JLabel("Loai Tra Cuu : ");
		labelLoaiTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelLoaiTraCuu.setBounds(10, 130, 80, 20);
		labelLoaiTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelLoaiTraCuu);
		
		comboBoxLoaiTraCuu = new JComboBox(listLoaiTraCuu);
		comboBoxLoaiTraCuu.setBounds(90, 130, 80, 20);
		comboBoxLoaiTraCuu.addActionListener(this);
		panel1.add(comboBoxLoaiTraCuu);
		
		JLabel labelChiTietTraCuu = new JLabel("Chi Tiet Tra Cuu : ");
		labelChiTietTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		labelChiTietTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelChiTietTraCuu.setBounds(210, 130, 120, 20);
		panel1.add(labelChiTietTraCuu);
		
		textfieldChiTietTraCuu = new JTextField();
		textfieldChiTietTraCuu.setColumns(10);
		textfieldChiTietTraCuu.setBounds(330, 130, 80, 20);
		panel1.add(textfieldChiTietTraCuu);
		
		rbuttonThuongTraCuu = new JRadioButton("Thuong");
		rbuttonThuongTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonThuongTraCuu.setBounds(330, 130, 50, 20);
		rbuttonThuongTraCuu.setActionCommand("Thuong");
		rbuttonThuongTraCuu.setVisible(false);
		panel1.add(rbuttonThuongTraCuu);
		
		rbuttonVIPTraCuu = new JRadioButton("VIP");
		rbuttonVIPTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonVIPTraCuu.setBounds(380, 130, 50, 20);
		rbuttonVIPTraCuu.setActionCommand("VIP");
		rbuttonVIPTraCuu.setVisible(false);
		panel1.add(rbuttonVIPTraCuu);
		
		rbuttonCachLyTraCuu = new JRadioButton("Cach Ly");
		rbuttonCachLyTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonCachLyTraCuu.setBounds(430, 130, 50, 20);
		rbuttonCachLyTraCuu.setActionCommand("Cach ly");
		rbuttonCachLyTraCuu.setVisible(false);
		panel1.add(rbuttonCachLyTraCuu);
		
		bgroupLoaiTraCuu = new ButtonGroup();
		bgroupLoaiTraCuu.add(rbuttonThuongTraCuu);
		bgroupLoaiTraCuu.add(rbuttonVIPTraCuu);
		bgroupLoaiTraCuu.add(rbuttonCachLyTraCuu);

		buttonTraCuu = new JButton("Tra Cuu");
		buttonTraCuu.setForeground(Color.decode("#28526a"));
		buttonTraCuu.setBackground(Color.decode("#91B6C9"));
		buttonTraCuu.addActionListener(this);
		buttonTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonTraCuu.setBounds(500, 130, 85, 21);
		buttonTraCuu.setBorderPainted(false);
		panel1.add(buttonTraCuu);
		
		buttonCapNhat = new JButton("Cap Nhat");
		buttonCapNhat.setForeground(Color.decode("#28526a"));
		buttonCapNhat.setBackground(Color.decode("#91B6C9"));
		buttonCapNhat.addActionListener(this);
		buttonCapNhat.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonCapNhat.setBounds(80, 30, 85, 21);
		buttonCapNhat.setBorderPainted(false);
		panel2.add(buttonCapNhat);
		
		buttonQuayLai = new JButton("Quay Lai");
		buttonQuayLai.addActionListener(this);
		buttonQuayLai.setForeground(Color.decode("#28526a"));
		buttonQuayLai.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonQuayLai.setBackground(Color.decode("#91B6C9"));
		buttonQuayLai.setBounds(400, 30, 85, 21);
		buttonQuayLai.setBorderPainted(false);
		panel2.add(buttonQuayLai);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setPreferredSize(new Dimension (100, 100));
		panelContent.add(scrollPane,BorderLayout.CENTER);
		table = new JTable() {
			boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false
				};
			@Override
		    public boolean isCellEditable(int rowIndex, int columnIndex)
		    {
		        return columnEditables[columnIndex];
		    }	};
		table.setBackground(Color.decode("#d6e7ef"));
		table.setFont(new Font("Bevan", Font.PLAIN, 10));
		
		setInformation();
		scrollPane.setViewportView(table);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonTraCuu) {
			TraCuu();
		}
		else if (e.getSource() == buttonCapNhat) {
			CapNhat();
			setInformation();
		}
		else if (e.getSource() == buttonQuayLai) {
			QuayLai();
		}
		else if (e.getSource() == comboBoxLoaiTraCuu) {
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Loai")) {
				setVisibleFalseForAllChiTietTraCuu();
				rbuttonThuongTraCuu.setVisible(true);
				rbuttonVIPTraCuu.setVisible(true);
				rbuttonCachLyTraCuu.setVisible(true);
			}
			else
			{
				setVisibleFalseForAllChiTietTraCuu();
				textfieldChiTietTraCuu.setVisible(true);
			}
		}
	}
	


public void setInformation() { 
		
		String query = "SELECT * FROM PHONGBENH ORDER BY MAPHONG ASC";

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma Phong","Loai","Toa","Lau","Suc Chua","Con Trong"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			} 
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
}
	
	

public void TraCuu() { 
	
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tat Ca")
				|| (!(textfieldChiTietTraCuu.getText().equals("")))
				|| (!(bgroupLoaiTraCuu.getSelection() == null))) {
			
		String query = "SELECT * FROM PHONGBENH WHERE MAPHONG = MAPHONG";
		
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma Phong")) {
			query += " AND MAPHONG = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Toa")) {
			query += " AND TOA = " + textfieldChiTietTraCuu.getText();
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Lau")) {
			query += " AND LAU = " + textfieldChiTietTraCuu.getText();
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Suc Chua")) {
			query += " AND SUCCHUA = " + textfieldChiTietTraCuu.getText();
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Con Trong")) {
			query += " AND CONTRONG = " + textfieldChiTietTraCuu.getText();
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Loai") ) {
			query += " AND LOAI = '" + bgroupLoaiTraCuu.getSelection().getActionCommand() + "'";
		}
		
			query += " ORDER BY MAPHONG ASC";
			
		System.out.println(query);


			try {
				Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
				Statement statement = connection.createStatement();
				ResultSet resultset = statement.executeQuery(query);
				ResultSetMetaData metadata = resultset.getMetaData();
				int columnCount = metadata.getColumnCount();
				DefaultTableModel data = (DefaultTableModel) table.getModel();
				
				data.setColumnIdentifiers(new String[] {"Ma Phong","Loai","Toa","Lau","Suc Chua","Con Trong"});
				data.setRowCount(0);
				
				while(resultset.next()) {
					Vector row = new Vector();
					for (int i = 0; i < columnCount; i++)
						row.add(resultset.getString(i+1));
					data.addRow(row);
				
				}
				
				
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
		}
		 RefreshForTraCuu();
	}

		
	
	
	public void CapNhat() {
		
		String query = "UPDATE PHONGBENH SET MAPHONG = MAPHONG";
			if (!(textfieldToa.getText().equals(""))) {
				query += ", TOA = " + textfieldToa.getText();
			}
			else {
				query += ", TOA = NULL";
			}
			if (!(textfieldLau.getText().equals(""))) {
				query += ", LAU = " + textfieldLau.getText();
			}
			else {
				query += ", LAU = NULL";
			}
			if (!(textfieldSucChua.getText().equals(""))) {
				query += ", SUCCHUA = " + textfieldSucChua.getText();
			}
			else {
				query += ", SUCCHUA = NULL";
			}
			if (!(textfieldConTrong.getText().equals(""))) {
				query += ", CONTRONG = " + textfieldConTrong.getText();
			}
			else {
				query += ", CONTRONG = NULL";
			}
			if (bgroupLoai.getSelection() != null) {
				query += ", LOAI = '" + bgroupLoai.getSelection().getActionCommand() + "'";
			}
			else {
				query += ", LOAI = NULL";
			}	
					
			if (!(textfieldMaPhong.getText().equals(""))) {
				query += " WHERE MAPHONG = MAPHONG"; 
			}
			else {
				query += " WHERE MAPHONG = NULL"; 
			}
			if (!(textfieldMaPhong.getText().equals(""))) {
				query += " AND MAPHONG = '" + textfieldMaPhong.getText() + "'"; 
			}
				
				
				System.out.println(query);
				

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			int changedrows = statement.executeUpdate(query);
			if (changedrows > 0) {
				JOptionPane.showMessageDialog(null, "Cap Nhat Thanh Cong", "Thong Bao", JOptionPane.INFORMATION_MESSAGE);
			}
			
			statement.close();
			connection.close();
			
			setInformation();
			
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		//Refresh();
	}
	
	public void QuayLai() {
		MyHome.getPanelContent().removeAll();
		switch (MyHome.getPreviousClass("PhongBenh","CapNhat")) {
		case "PhongBenh":
			MyHome.getPanelContent().add(new PhongBenh(MyHome).getpanelContent());
			break;
		case "TraCuu":
			MyHome.getPanelContent().add(new PhongBenh_TraCuu(MyHome).getpanelContent());
			break;
		}
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
	}
	
	public void Refresh() {
		textfieldMaPhong.setText("");
		textfieldToa.setText("");
		textfieldLau.setText("");
		textfieldSucChua.setText("");
		bgroupLoai.clearSelection();
	}
	
	public void RefreshForTraCuu() {
		//comboBoxLoaiTraCuu.setSelectedIndex(0);
		bgroupLoaiTraCuu.clearSelection();
		textfieldChiTietTraCuu.setText("");
	}
	
	public void setVisibleFalseForAllChiTietTraCuu() {
		rbuttonThuongTraCuu.setVisible(false);
		rbuttonVIPTraCuu.setVisible(false);
		rbuttonCachLyTraCuu.setVisible(false);
		textfieldChiTietTraCuu.setVisible(false);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
