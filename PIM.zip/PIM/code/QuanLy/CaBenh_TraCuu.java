package QuanLy;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import java.sql.*;
import java.util.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import com.toedter.calendar.JDateChooser;


public class CaBenh_TraCuu implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonTraCuu;
	private JButton buttonCapNhat;
	private JButton buttonXoa;
	private JButton buttonQuayLai;
	
	private JRadioButton rbuttonTaiGiaTraCuu;
	private JRadioButton rbuttonNhapVienTraCuu;
	private JRadioButton rbuttonCachLyTraCuu;
	private ButtonGroup bgroupHinhThucTraCuu;
	
	private JTextField textfieldChiTietTraCuu;
	
	private JDateChooser NgayBatDauTraCuu;
	private JDateChooser NgayKetThucTraCuu;
	
	private JTable table;
	
	private JComboBox comboBoxLoaiTraCuu;
	private JComboBox comboBoxMucDoTraCuu;
	private JComboBox comboBoxTinhTrangTraCuu;
	
	private String listLoaiTraCuu[]  = {"Tat Ca","Ma BN","Ma BS","Ma Benh","Muc Do","Hinh Thuc","Ngay Bat Dau","Ngay Ket Thuc","Tinh Trang","Ma Phong"}; 
	private String listMucDo[]  = {"Khong cap cuu","Hoi Suc","Nang","Cham soc dac biet","Cap cuu"}; 
	private String listTinhTrang[]  = {"Hen kham","Dang dieu tri","Thanh cong","That bai"}; 
	
	CaBenh_TraCuu(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (80,80));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.NORTH);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(null);
		panelContent.add(panel2, BorderLayout.SOUTH);
		
		JLabel labelLoaiTraCuu = new JLabel("Loai Tra Cuu : ");
		labelLoaiTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelLoaiTraCuu.setBounds(10, 30, 100, 20);
		labelLoaiTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelLoaiTraCuu);
		
		comboBoxLoaiTraCuu = new JComboBox(listLoaiTraCuu);
		comboBoxLoaiTraCuu.setBounds(110, 30, 80, 20);
		comboBoxLoaiTraCuu.addActionListener(this);
		panel1.add(comboBoxLoaiTraCuu);
		
		JLabel labelChiTietTraCuu = new JLabel("Chi Tiet Tra Cuu : ");
		labelChiTietTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		labelChiTietTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelChiTietTraCuu.setBounds(210, 30, 120, 20);
		panel1.add(labelChiTietTraCuu);
		
		textfieldChiTietTraCuu = new JTextField();
		textfieldChiTietTraCuu.setColumns(10);
		textfieldChiTietTraCuu.setBounds(330, 30, 80, 20);
		panel1.add(textfieldChiTietTraCuu);
		
		NgayBatDauTraCuu = new JDateChooser();
		NgayBatDauTraCuu.setBounds(330, 30, 80, 20);
		NgayBatDauTraCuu.setVisible(false);
		panel1.add(NgayBatDauTraCuu);
		
		NgayKetThucTraCuu = new JDateChooser();
		NgayKetThucTraCuu.setBounds(330, 30, 80, 20);
		NgayKetThucTraCuu.setVisible(false);
		panel1.add(NgayKetThucTraCuu);
		
		rbuttonTaiGiaTraCuu = new JRadioButton("Tai Gia");
		rbuttonTaiGiaTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonTaiGiaTraCuu.setBounds(330, 30, 50, 20);
		rbuttonTaiGiaTraCuu.setActionCommand("Tai gia");
		rbuttonTaiGiaTraCuu.setVisible(false);
		panel1.add(rbuttonTaiGiaTraCuu);
		
		rbuttonNhapVienTraCuu = new JRadioButton("Nhap Vien");
		rbuttonNhapVienTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonNhapVienTraCuu.setBounds(380, 30, 50, 20);
		rbuttonNhapVienTraCuu.setActionCommand("Nhap vien");
		rbuttonNhapVienTraCuu.setVisible(false);
		panel1.add(rbuttonNhapVienTraCuu);
		
		rbuttonCachLyTraCuu = new JRadioButton("Cach Ly");
		rbuttonCachLyTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonCachLyTraCuu.setBounds(430, 30, 50, 20);
		rbuttonCachLyTraCuu.setActionCommand("Cach ly");
		rbuttonCachLyTraCuu.setVisible(false);
		panel1.add(rbuttonCachLyTraCuu);
		
		bgroupHinhThucTraCuu = new ButtonGroup();
		bgroupHinhThucTraCuu.add(rbuttonTaiGiaTraCuu);
		bgroupHinhThucTraCuu.add(rbuttonNhapVienTraCuu);
		bgroupHinhThucTraCuu.add(rbuttonCachLyTraCuu);
		
		comboBoxMucDoTraCuu = new JComboBox(listMucDo);
		comboBoxMucDoTraCuu.setBounds(330, 30, 80, 20);
		comboBoxMucDoTraCuu.setVisible(false);
		panel1.add(comboBoxMucDoTraCuu);
		
		comboBoxTinhTrangTraCuu = new JComboBox(listTinhTrang);
		comboBoxTinhTrangTraCuu.setBounds(330, 30, 80, 20);
		comboBoxTinhTrangTraCuu.setVisible(false);
		panel1.add(comboBoxTinhTrangTraCuu);
		
		
		buttonTraCuu = new JButton("Tra Cuu");
		buttonTraCuu.setForeground(Color.decode("#28526a"));
		buttonTraCuu.setBackground(Color.decode("#91B6C9"));
		buttonTraCuu.addActionListener(this);
		buttonTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonTraCuu.setBounds(500, 30, 85, 21);
		buttonTraCuu.setBorderPainted(false);
		panel1.add(buttonTraCuu);
		
		buttonCapNhat = new JButton("Cap Nhat");
		buttonCapNhat.setForeground(Color.decode("#28526a"));
		buttonCapNhat.setBackground(Color.decode("#91B6C9"));
		buttonCapNhat.addActionListener(this);
		buttonCapNhat.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonCapNhat.setBounds(80, 30, 85, 21);
		buttonCapNhat.setBorderPainted(false);
		panel2.add(buttonCapNhat);
		
		buttonXoa = new JButton("Xoa");
		buttonXoa.setForeground(Color.decode("#28526a"));
		buttonXoa.setBackground(Color.decode("#91B6C9"));
		buttonXoa.addActionListener(this);
		buttonXoa.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonXoa.setBounds(240, 30, 97, 21);
		buttonXoa.setBorderPainted(false);
		panel2.add(buttonXoa);
		
		buttonQuayLai = new JButton("Quay Lai");
		buttonQuayLai.addActionListener(this);
		buttonQuayLai.setForeground(Color.decode("#28526a"));
		buttonQuayLai.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonQuayLai.setBackground(Color.decode("#91B6C9"));
		buttonQuayLai.setBounds(400, 30, 85, 21);
		buttonQuayLai.setBorderPainted(false);
		panel2.add(buttonQuayLai);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setPreferredSize(new Dimension (100, 100));
		panelContent.add(scrollPane,BorderLayout.CENTER);
		
		table = new JTable() {
			boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false, false, false, false
				};
			@Override
		    public boolean isCellEditable(int rowIndex, int columnIndex)
		    {
		        return columnEditables[columnIndex];
		    }	};
		table.setBackground(Color.decode("#d6e7ef"));
		table.setFont(new Font("Bevan", Font.PLAIN, 10));
		
		setInformation();
		scrollPane.setViewportView(table);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonTraCuu) {
			TraCuu();
		}
		else if (e.getSource() == buttonCapNhat) {
			CapNhat();
			setInformation();
		}
		else if (e.getSource() == buttonXoa) {
			Xoa();
			setInformation();
		}
		else if (e.getSource() == buttonQuayLai) {
			QuayLai();
		}
		else if (e.getSource() == comboBoxLoaiTraCuu) {
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Hinh Thuc")) {
				setVisibleFalseForAllChiTietTraCuu();
				rbuttonTaiGiaTraCuu.setVisible(true);
				rbuttonNhapVienTraCuu.setVisible(true);
				rbuttonCachLyTraCuu.setVisible(true);
			}
			else if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Bat Dau")) {
				setVisibleFalseForAllChiTietTraCuu();
				NgayBatDauTraCuu.setVisible(true);
			}
			else if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Ket Thuc")) {
				setVisibleFalseForAllChiTietTraCuu();
				NgayKetThucTraCuu.setVisible(true);
			}
			else if(comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Muc Do")) {
				setVisibleFalseForAllChiTietTraCuu();
				comboBoxMucDoTraCuu.setVisible(true);
			}
			else if(comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tinh Trang")) {
				setVisibleFalseForAllChiTietTraCuu();
				comboBoxTinhTrangTraCuu.setVisible(true);
			}
			else
			{
				setVisibleFalseForAllChiTietTraCuu();
				textfieldChiTietTraCuu.setVisible(true);
			}
		}
	}
	

public void setInformation() { 
		
		String query = "SELECT * FROM CABENH ORDER BY MABN, MABS, MABENH ASC";

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma BN","Ma BS","Ma Benh","Muc Do","Hinh Thuc","Ngay Bat Dau","Ngay Ket Thuc","Tinh Trang","Ma Phong"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			} 
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
}
	

public void TraCuu() { 
	
	if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tat Ca")
			|| (!(textfieldChiTietTraCuu.getText().equals("")))
			|| (!(NgayBatDauTraCuu.getDate() == null))
			|| (!(NgayKetThucTraCuu.getDate() == null))
			|| (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Muc Do"))
			|| (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tinh Trang"))
			|| (!(bgroupHinhThucTraCuu.getSelection() == null))) {
		
		String query = "SELECT * FROM CABENH WHERE MABN = MABN";
		
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma BN")) {
			query += " AND MABN = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma BS")) {
			query += " AND MABS = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma Benh")) {
			query += " AND MABENH = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma Phong")) {
			query += " AND MAPHONG = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Bat Dau")) {
			Date date = NgayBatDauTraCuu.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String dateString = sdf.format(date);
			if (!(dateString.equals(""))) {
				query += " AND NGAYBATDAU = TO_DATE('" + dateString + "','YYYY-MM-DD')";
			}
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Ket Thuc")) {
			Date date = NgayKetThucTraCuu.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String dateString = sdf.format(date);
			if (!(dateString.equals(""))) {
				query += " AND NGAYKETTHUC = TO_DATE('" + dateString + "','YYYY-MM-DD')";
			}
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Muc Do")) {
			query += " AND MUCDO = '" + comboBoxMucDoTraCuu.getItemAt(comboBoxMucDoTraCuu.getSelectedIndex()) + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tinh Trang")) {
			query += " AND TINHTRANG = '" + comboBoxTinhTrangTraCuu.getItemAt(comboBoxTinhTrangTraCuu.getSelectedIndex()) + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Hinh Thuc") ) {
			query += " AND HINHTHUC = '" + bgroupHinhThucTraCuu.getSelection().getActionCommand() + "'";
		}
		
			query += " ORDER BY MABN, MABS, MABENH ASC";
		System.out.println(query);


		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma BN","Ma BS","Ma Benh","Muc Do","Hinh Thuc","Ngay Bat Dau","Ngay Ket Thuc","Tinh Trang","Ma Phong"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			
			}
			
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
	 RefreshForTraCuu();
}

	
	public void CapNhat() {
		
		MyHome.getPanelContent().removeAll();
		MyHome.getPanelContent().add(new CaBenh_CapNhat(MyHome).getpanelContent());
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
		MyHome.setPreviousClass("CaBenh","CapNhat", "TraCuu");
		
	}
	
	public void Xoa() {
		MyHome.getPanelContent().removeAll();
		MyHome.getPanelContent().add(new CaBenh_Xoa(MyHome).getpanelContent());
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
		MyHome.setPreviousClass("CaBenh","Xoa", "TraCuu");
	}
	
	public void QuayLai() {
		MyHome.getPanelContent().removeAll();
		switch (MyHome.getPreviousClass("CaBenh","TraCuu")) {
		case "CaBenh":
			MyHome.getPanelContent().add(new CaBenh(MyHome).getpanelContent());
			break;
		}
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
	}
	
	public void RefreshForTraCuu() {
		//comboBoxLoaiTraCuu.setSelectedIndex(0);
		comboBoxMucDoTraCuu.setSelectedIndex(0);
		comboBoxTinhTrangTraCuu.setSelectedIndex(0);
		bgroupHinhThucTraCuu.clearSelection();
		NgayBatDauTraCuu.setDate(null);
		NgayKetThucTraCuu.setDate(null);
		textfieldChiTietTraCuu.setText("");
	}
	
	public void setVisibleFalseForAllChiTietTraCuu() {
		rbuttonTaiGiaTraCuu.setVisible(false);
		rbuttonNhapVienTraCuu.setVisible(false);
		rbuttonCachLyTraCuu.setVisible(false);
		NgayBatDauTraCuu.setVisible(false);
		NgayKetThucTraCuu.setVisible(false);
		comboBoxMucDoTraCuu.setVisible(false);
		comboBoxTinhTrangTraCuu.setVisible(false);
		textfieldChiTietTraCuu.setVisible(false);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
