package QuanLy;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.sql.*;

public class Benh_Them implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonThem;
	private JButton buttonQuayLai;
	
	private JTextField textfieldMaBenh;
	private JTextField textfieldTenBenh;
	private JTextField textfieldTenKhoa;

	Benh_Them(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (100,300));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.CENTER);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(null);
		panelContent.add(panel2, BorderLayout.SOUTH);
		
		JLabel labelMaBenh = new JLabel("Ma Benh : ");
		labelMaBenh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBenh.setBounds(50, 30, 115, 20);
		labelMaBenh.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBenh);
		
		textfieldMaBenh = new JTextField();
		textfieldMaBenh.setBounds(170, 30, 115, 20);
		textfieldMaBenh.setColumns(10);
		panel1.add(textfieldMaBenh);
		
		JLabel labelTenBenh = new JLabel("Ten Benh : ");
		labelTenBenh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTenBenh.setBounds(320, 30, 115, 20);
		labelTenBenh.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelTenBenh);
		
		textfieldTenBenh = new JTextField();
		textfieldTenBenh.setBounds(440, 30, 115, 20);
		textfieldTenBenh.setColumns(10);
		panel1.add(textfieldTenBenh);

		JLabel labelTenKhoa = new JLabel("Ten Khoa : ");
		labelTenKhoa.setHorizontalAlignment(SwingConstants.RIGHT);
		labelTenKhoa.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTenKhoa.setBounds(320, 190, 115, 20);
		panel1.add(labelTenKhoa);
		
		textfieldTenKhoa = new JTextField();
		textfieldTenKhoa.setColumns(10);
		textfieldTenKhoa.setBounds(440, 190, 115, 20);
		panel1.add(textfieldTenKhoa);
		
		buttonThem = new JButton("Them");
		buttonThem.setForeground(Color.decode("#28526a"));
		buttonThem.setBackground(Color.decode("#91B6C9"));
		buttonThem.addActionListener(this);
		buttonThem.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonThem.setBounds(80, 30, 85, 21);
		buttonThem.setBorderPainted(false);
		panel2.add(buttonThem);
		
		buttonQuayLai = new JButton("Quay Lai");
		buttonQuayLai.addActionListener(this);
		buttonQuayLai.setForeground(Color.decode("#28526a"));
		buttonQuayLai.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonQuayLai.setBackground(Color.decode("#91B6C9"));
		buttonQuayLai.setBounds(450, 30, 85, 21);
		buttonQuayLai.setBorderPainted(false);
		panel2.add(buttonQuayLai);

	}
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == buttonThem) {
			Them();
		}
		else if (e.getSource() == buttonQuayLai) {
			QuayLai();
		}
	}
	
	public void Them() {
		
		
		String query = "INSERT INTO BENH VALUES ('"
							+ textfieldMaBenh.getText() + "' , '"
							+ textfieldTenBenh.getText() + "' , '"
							+ textfieldTenKhoa.getText() + "')";
							
		System.out.println(query);

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			int changedrows = statement.executeUpdate(query);
			if (changedrows > 0) {
				JOptionPane.showMessageDialog(null, "Them Moi Thanh Cong", "Thong Bao", JOptionPane.INFORMATION_MESSAGE);
			}
			
			statement.close();
			connection.close();
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		Refresh();
	}
	
	public void QuayLai() {
		MyHome.getPanelContent().removeAll();
		switch (MyHome.getPreviousClass("Benh","Them")) {
		case "Benh":
			MyHome.getPanelContent().add(new Benh(MyHome).getpanelContent());
			break;
		}
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
	}
	
	public void Refresh() {
		textfieldMaBenh.setText("");
		textfieldTenBenh.setText("");
		textfieldTenKhoa.setText("");
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
