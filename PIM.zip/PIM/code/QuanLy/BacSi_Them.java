package QuanLy;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import com.toedter.calendar.JDateChooser;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BacSi_Them implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonThem;
	private JButton buttonQuayLai;
	private JRadioButton rbuttonNam;
	private JRadioButton rbuttonNu;
	private ButtonGroup bgroupGioiTinh;
	
	private JTextField textfieldMaBS;
	private JTextField textfieldHoTen;
	private JTextField textfieldQueQuan;
	private JTextField textfieldNoiOHienTai;
	private JTextField textfieldTenKhoa;
	private JTextField textfieldNamPhucVu;
	
	private JDateChooser NgaySinh;

	BacSi_Them(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (100,300));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.CENTER);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(null);
		panelContent.add(panel2, BorderLayout.SOUTH);
		
		JLabel labelMaBS = new JLabel("Ma BS : ");
		labelMaBS.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBS.setBounds(50, 30, 115, 20);
		labelMaBS.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBS);
		
		textfieldMaBS = new JTextField();
		textfieldMaBS.setBounds(170, 30, 115, 20);
		textfieldMaBS.setColumns(10);
		panel1.add(textfieldMaBS);
		
		JLabel labelHoTen = new JLabel("Ho Ten : ");
		labelHoTen.setFont(new Font("Bevan", Font.BOLD, 12));
		labelHoTen.setBounds(320, 30, 115, 20);
		labelHoTen.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelHoTen);
		
		textfieldHoTen = new JTextField();
		textfieldHoTen.setBounds(440, 30, 115, 20);
		textfieldHoTen.setColumns(10);
		panel1.add(textfieldHoTen);
		
		JLabel labelGioiTinh = new JLabel("Gioi Tinh : ");
		labelGioiTinh.setHorizontalAlignment(SwingConstants.RIGHT);
		labelGioiTinh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelGioiTinh.setBounds(50, 70, 115, 20);
		panel1.add(labelGioiTinh);

		rbuttonNam = new JRadioButton("Nam");
		rbuttonNam.setBackground(Color.decode("#d6e7ef"));
		rbuttonNam.setBounds(170, 70, 50, 20);
		rbuttonNam.setActionCommand("Nam");
		panel1.add(rbuttonNam);
		
		rbuttonNu = new JRadioButton("Nu");
		rbuttonNu.setBackground(Color.decode("#d6e7ef"));
		rbuttonNu.setBounds(220, 70, 50, 20);
		rbuttonNu.setActionCommand("Nu");
		panel1.add(rbuttonNu);
		
		bgroupGioiTinh = new ButtonGroup();
		bgroupGioiTinh.add(rbuttonNam);
		bgroupGioiTinh.add(rbuttonNu);
		
		JLabel labelNgaySinh = new JLabel("Ngay Sinh : ");
		labelNgaySinh.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgaySinh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgaySinh.setBounds(320, 70, 115, 20);
		panel1.add(labelNgaySinh);
		
		NgaySinh = new JDateChooser();
		NgaySinh.setBounds(440, 70, 115, 20);
		panel1.add(NgaySinh);
		
		JLabel labelQueQuan = new JLabel("Que Quan : ");
		labelQueQuan.setHorizontalAlignment(SwingConstants.RIGHT);
		labelQueQuan.setFont(new Font("Bevan", Font.BOLD, 12));
		labelQueQuan.setBounds(50, 150, 115, 20);
		panel1.add(labelQueQuan);
		
		textfieldQueQuan = new JTextField();
		textfieldQueQuan.setColumns(10);
		textfieldQueQuan.setBounds(170, 150, 115, 20);
		panel1.add(textfieldQueQuan);
		
		JLabel labelNoiOHienTai = new JLabel("Noi O : ");
		labelNoiOHienTai.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNoiOHienTai.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNoiOHienTai.setBounds(320, 150, 115, 20);
		panel1.add(labelNoiOHienTai);
		
		textfieldNoiOHienTai = new JTextField();
		textfieldNoiOHienTai.setColumns(10);
		textfieldNoiOHienTai.setBounds(440, 150, 115, 20);
		panel1.add(textfieldNoiOHienTai);
		
		JLabel labelTenKhoa = new JLabel("Ten Khoa : ");
		labelTenKhoa.setHorizontalAlignment(SwingConstants.RIGHT);
		labelTenKhoa.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTenKhoa.setBounds(320, 190, 115, 20);
		panel1.add(labelTenKhoa);
		
		textfieldTenKhoa = new JTextField();
		textfieldTenKhoa.setColumns(10);
		textfieldTenKhoa.setBounds(440, 190, 115, 20);
		panel1.add(textfieldTenKhoa);
		
		JLabel labelNamPhucVu = new JLabel("Nam Phuc Vu : ");
		labelNamPhucVu.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNamPhucVu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNamPhucVu.setBounds(320, 230, 115, 20);
		panel1.add(labelNamPhucVu);
		
		textfieldNamPhucVu = new JTextField();
		textfieldNamPhucVu.setColumns(10);
		textfieldNamPhucVu.setBounds(440, 230, 115, 20);
		panel1.add(textfieldNamPhucVu);
		
		buttonThem = new JButton("Them");
		buttonThem.setForeground(Color.decode("#28526a"));
		buttonThem.setBackground(Color.decode("#91B6C9"));
		buttonThem.addActionListener(this);
		buttonThem.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonThem.setBounds(80, 30, 85, 21);
		buttonThem.setBorderPainted(false);
		panel2.add(buttonThem);
		
		buttonQuayLai = new JButton("Quay Lai");
		buttonQuayLai.addActionListener(this);
		buttonQuayLai.setForeground(Color.decode("#28526a"));
		buttonQuayLai.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonQuayLai.setBackground(Color.decode("#91B6C9"));
		buttonQuayLai.setBounds(450, 30, 85, 21);
		buttonQuayLai.setBorderPainted(false);
		panel2.add(buttonQuayLai);

	}
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == buttonThem) {
			Them();
		}
		else if (e.getSource() == buttonQuayLai) {
			QuayLai();
		}
	}
	
	public void Them() {
		
		if (textfieldNamPhucVu.getText().equals("")) {
			textfieldNamPhucVu.setText("null");
		}
		
		String stringNgaySinh = "";
		if (NgaySinh.getDate() != null) {
			Date date = NgaySinh.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			stringNgaySinh = sdf.format(date);
		}
		
		String stringGioiTinh = ""; 
		if (bgroupGioiTinh.getSelection() != null) {
			stringGioiTinh = bgroupGioiTinh.getSelection().getActionCommand();
		}
		String query = "INSERT INTO BACSI VALUES ('"
							+ textfieldMaBS.getText() + "' , '"
							+ textfieldHoTen.getText() + "' , '"
							+ stringGioiTinh + "' , "
							+ "TO_DATE('" + stringNgaySinh + "','YYYY-MM-DD') , '"
							+ textfieldQueQuan.getText() + "' , '"
							+ textfieldNoiOHienTai.getText() + "' , '"
							+ textfieldTenKhoa.getText() + "' , "
							+ textfieldNamPhucVu.getText() + ")";
							
		System.out.println(query);		

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			int changedrows = statement.executeUpdate(query);
			if (changedrows > 0) {
				JOptionPane.showMessageDialog(null, "Them Moi Thanh Cong", "Thong Bao", JOptionPane.INFORMATION_MESSAGE);
			}
			
			statement.close();
			connection.close();
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		Refresh();
	}
	
	public void QuayLai() {
		MyHome.getPanelContent().removeAll();
		switch (MyHome.getPreviousClass("BacSi","Them")) {
		case "BacSi":
			MyHome.getPanelContent().add(new BacSi(MyHome).getpanelContent());
			break;
		}
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
	}
	
	public void Refresh() {
		textfieldMaBS.setText("");
		textfieldHoTen.setText("");
		textfieldQueQuan.setText("");
		textfieldNoiOHienTai.setText("");
		textfieldTenKhoa.setText("");
		textfieldNamPhucVu.setText("");
		bgroupGioiTinh.clearSelection();
		NgaySinh.setDate(null);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
