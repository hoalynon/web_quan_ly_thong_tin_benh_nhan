package QuanLy;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import com.toedter.calendar.JDateChooser;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CaBenh_Them implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonThem;
	private JButton buttonQuayLai;
	private JRadioButton rbuttonTaiGia;
	private JRadioButton rbuttonNhapVien;
	private JRadioButton rbuttonCachLy;
	private ButtonGroup bgroupHinhThuc;
	
	private JTextField textfieldMaBN;
	private JTextField textfieldMaBS;
	private JTextField textfieldMaBenh;
	private JTextField textfieldMaPhong;
	
	private JDateChooser NgayBatDau;
	private JDateChooser NgayKetThuc;
	
	private JComboBox comboBoxMucDo;
	private JComboBox comboBoxTinhTrang;
	
	private String listMucDo[]  = {"Khong cap cuu","Hoi Suc","Nang","Cham soc dac biet","Cap cuu"}; 
	private String listTinhTrang[]  = {"Hen kham","Dang dieu tri","Thanh cong","That bai"}; 


	CaBenh_Them(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (100,300));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.CENTER);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(null);
		panelContent.add(panel2, BorderLayout.SOUTH);
		
		JLabel labelMaBN = new JLabel("Ma BN : ");
		labelMaBN.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBN.setBounds(10, 10, 80, 20);
		labelMaBN.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBN);
		
		textfieldMaBN = new JTextField();
		textfieldMaBN.setBounds(90, 10, 80, 20);
		textfieldMaBN.setColumns(10);
		panel1.add(textfieldMaBN);
		
		JLabel labelMaBS = new JLabel("Ma BS : ");
		labelMaBS.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBS.setBounds(10, 40, 80, 20);
		labelMaBS.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBS);
		
		textfieldMaBS = new JTextField();
		textfieldMaBS.setBounds(90, 40, 80, 20);
		textfieldMaBS.setColumns(10);
		panel1.add(textfieldMaBS);
		
		JLabel labelMaBenh = new JLabel("Ma Benh : ");
		labelMaBenh.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMaBenh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBenh.setBounds(10, 70, 80, 20);
		panel1.add(labelMaBenh);
		
		textfieldMaBenh = new JTextField();
		textfieldMaBenh.setColumns(10);
		textfieldMaBenh.setBounds(90, 70, 80, 20);
		panel1.add(textfieldMaBenh);
		
		JLabel labelMaPhong = new JLabel("Ma Phong : ");
		labelMaPhong.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMaPhong.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaPhong.setBounds(10, 100, 80, 20);
		panel1.add(labelMaPhong);
		
		textfieldMaPhong = new JTextField();
		textfieldMaPhong.setColumns(10);
		textfieldMaPhong.setBounds(90, 100, 80, 20);
		panel1.add(textfieldMaPhong);
		
		JLabel labelHinhThuc = new JLabel("Hinh Thuc : ");
		labelHinhThuc.setHorizontalAlignment(SwingConstants.RIGHT);
		labelHinhThuc.setFont(new Font("Bevan", Font.BOLD, 12));
		labelHinhThuc.setBounds(180, 10, 80, 20);
		panel1.add(labelHinhThuc);

		rbuttonTaiGia = new JRadioButton("Tai Gia");
		rbuttonTaiGia.setBackground(Color.decode("#d6e7ef"));
		rbuttonTaiGia.setBounds(260, 10, 50, 20);
		rbuttonTaiGia.setActionCommand("Tai gia");
		panel1.add(rbuttonTaiGia);
		
		rbuttonNhapVien = new JRadioButton("Nhap Vien");
		rbuttonNhapVien.setBackground(Color.decode("#d6e7ef"));
		rbuttonNhapVien.setBounds(310, 10, 50, 20);
		rbuttonNhapVien.setActionCommand("Nhap Vien");
		panel1.add(rbuttonNhapVien);
		
		rbuttonCachLy = new JRadioButton("Cach Ly");
		rbuttonCachLy.setBackground(Color.decode("#d6e7ef"));
		rbuttonCachLy.setBounds(360, 10, 50, 20);
		rbuttonCachLy.setActionCommand("Cach ly");
		panel1.add(rbuttonCachLy);
		
		bgroupHinhThuc = new ButtonGroup();
		bgroupHinhThuc.add(rbuttonTaiGia);
		bgroupHinhThuc.add(rbuttonNhapVien);
		bgroupHinhThuc.add(rbuttonCachLy);
		
		JLabel labelNgayBatDau = new JLabel("Ngay Bat Dau: ");
		labelNgayBatDau.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgayBatDau.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgayBatDau.setBounds(180, 40, 80, 20);
		panel1.add(labelNgayBatDau);
		
		NgayBatDau = new JDateChooser();
		NgayBatDau.setBounds(260, 40, 80, 20);
		panel1.add(NgayBatDau);
		
		JLabel labelNgayKetThuc = new JLabel("Ngay Ket Thuc: ");
		labelNgayKetThuc.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgayKetThuc.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgayKetThuc.setBounds(180, 70, 80, 20);
		panel1.add(labelNgayKetThuc);
		
		NgayKetThuc = new JDateChooser();
		NgayKetThuc.setBounds(260, 70, 80, 20);
		panel1.add(NgayKetThuc);
		
		JLabel labelMucDo = new JLabel("Muc Do : ");
		labelMucDo.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMucDo.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMucDo.setBounds(420, 40, 80, 20);
		panel1.add(labelMucDo);
		
		comboBoxMucDo = new JComboBox(listMucDo);
		comboBoxMucDo.setBounds(500, 40, 80, 20);
		panel1.add(comboBoxMucDo);
		
		JLabel labelTinhTrang = new JLabel("Tinh Trang : ");
		labelTinhTrang.setHorizontalAlignment(SwingConstants.RIGHT);
		labelTinhTrang.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTinhTrang.setBounds(420, 70, 80, 20);
		panel1.add(labelTinhTrang);
		
		comboBoxTinhTrang = new JComboBox(listTinhTrang);
		comboBoxTinhTrang.setBounds(500, 70, 80, 20);
		panel1.add(comboBoxTinhTrang);
		
		buttonThem = new JButton("Them");
		buttonThem.setForeground(Color.decode("#28526a"));
		buttonThem.setBackground(Color.decode("#91B6C9"));
		buttonThem.addActionListener(this);
		buttonThem.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonThem.setBounds(80, 30, 85, 21);
		buttonThem.setBorderPainted(false);
		panel2.add(buttonThem);
		
		buttonQuayLai = new JButton("Quay Lai");
		buttonQuayLai.addActionListener(this);
		buttonQuayLai.setForeground(Color.decode("#28526a"));
		buttonQuayLai.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonQuayLai.setBackground(Color.decode("#91B6C9"));
		buttonQuayLai.setBounds(450, 30, 85, 21);
		buttonQuayLai.setBorderPainted(false);
		panel2.add(buttonQuayLai);

	}
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == buttonThem) {
			Them();
		}
		else if (e.getSource() == buttonQuayLai) {
			QuayLai();
		}
	}
	
	public void Them() {
		
		String stringNgayBatDau = "";
		if (NgayBatDau.getDate() != null) {
			Date date = NgayBatDau.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			stringNgayBatDau = sdf.format(date);
		}
		
		String stringNgayKetThuc = "";
		if (NgayKetThuc.getDate() != null) {
			Date date = NgayKetThuc.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			stringNgayKetThuc = sdf.format(date);
		}
		
		String stringHinhThuc = ""; 
		if (bgroupHinhThuc.getSelection() != null) {
			stringHinhThuc = bgroupHinhThuc.getSelection().getActionCommand();
		}
		String query = "INSERT INTO CABENH VALUES ('"
							+ textfieldMaBN.getText() + "' , '"
							+ textfieldMaBS.getText() + "' , '"
							+ textfieldMaBenh.getText() + "' , '"
							+ comboBoxMucDo.getItemAt(comboBoxMucDo.getSelectedIndex()) + "' , '"
							+ stringHinhThuc + "' , "
							+ "TO_DATE('" + stringNgayBatDau + "','YYYY-MM-DD') , "
							+ "TO_DATE('" + stringNgayKetThuc + "','YYYY-MM-DD') , '"
							+ comboBoxTinhTrang.getItemAt(comboBoxTinhTrang.getSelectedIndex()) + "' , '"
							+ textfieldMaPhong.getText() + "')";
							
							
		System.out.println(query);					

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			int changedrows = statement.executeUpdate(query);
			if (changedrows > 0) {
				JOptionPane.showMessageDialog(null, "Them Moi Thanh Cong", "Thong Bao", JOptionPane.INFORMATION_MESSAGE);
			}
			
			statement.close();
			connection.close();
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		Refresh();
	}
	
	public void QuayLai() {
		MyHome.getPanelContent().removeAll();
		switch (MyHome.getPreviousClass("CaBenh","Them")) {
		case "CaBenh":
			MyHome.getPanelContent().add(new CaBenh(MyHome).getpanelContent());
			break;
		}
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
	}
	
	public void Refresh() {
		textfieldMaBN.setText("");
		textfieldMaBS.setText("");
		textfieldMaBenh.setText("");
		textfieldMaPhong.setText("");
		bgroupHinhThuc.clearSelection();
		NgayBatDau.setDate(null);
		NgayKetThuc.setDate(null);
		comboBoxMucDo.setSelectedIndex(0);
		comboBoxTinhTrang.setSelectedIndex(0);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
