package QuanLy;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

public class CaBenh_CapNhat implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonTraCuu;
	private JButton buttonCapNhat;
	private JButton buttonQuayLai;
	
	private JRadioButton rbuttonTaiGia;
	private JRadioButton rbuttonNhapVien;
	private JRadioButton rbuttonCachLy;
	private ButtonGroup bgroupHinhThuc;
	private JRadioButton rbuttonTaiGiaTraCuu;
	private JRadioButton rbuttonNhapVienTraCuu;
	private JRadioButton rbuttonCachLyTraCuu;
	private ButtonGroup bgroupHinhThucTraCuu;
	
	private JTextField textfieldMaBN;
	private JTextField textfieldMaBS;
	private JTextField textfieldMaBenh;
	private JTextField textfieldMaPhong;
	private JTextField textfieldChiTietTraCuu;
	
	private JDateChooser NgayBatDau;
	private JDateChooser NgayKetThuc;
	private JDateChooser NgayBatDauTraCuu;
	private JDateChooser NgayKetThucTraCuu;
	
	private JTable table;
	private JComboBox comboBoxLoaiTraCuu;
	private JComboBox comboBoxMucDo;
	private JComboBox comboBoxTinhTrang;
	private JComboBox comboBoxMucDoTraCuu;
	private JComboBox comboBoxTinhTrangTraCuu;
	
	private String listLoaiTraCuu[]  = {"Tat Ca","Ma BN","Ma BS","Ma Benh","Muc Do","Hinh Thuc","Ngay Bat Dau","Ngay Ket Thuc","Tinh Trang","Ma Phong"}; 
	private String listMucDo[]  = {"Khong cap cuu","Hoi Suc","Nang","Cham soc dac biet","Cap cuu"}; 
	private String listTinhTrang[]  = {"Hen kham","Dang dieu tri","Thanh cong","That bai"}; 
	
	CaBenh_CapNhat(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (160,160));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.NORTH);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(null);
		panelContent.add(panel2, BorderLayout.SOUTH);

		JLabel labelMaBN = new JLabel("Ma BN : ");
		labelMaBN.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBN.setBounds(10, 10, 80, 20);
		labelMaBN.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBN);
		
		textfieldMaBN = new JTextField();
		textfieldMaBN.setBounds(90, 10, 80, 20);
		textfieldMaBN.setColumns(10);
		panel1.add(textfieldMaBN);
		
		JLabel labelMaBS = new JLabel("Ma BS : ");
		labelMaBS.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBS.setBounds(10, 40, 80, 20);
		labelMaBS.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBS);
		
		textfieldMaBS = new JTextField();
		textfieldMaBS.setBounds(90, 40, 80, 20);
		textfieldMaBS.setColumns(10);
		panel1.add(textfieldMaBS);
		
		JLabel labelMaBenh = new JLabel("Ma Benh : ");
		labelMaBenh.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMaBenh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBenh.setBounds(10, 70, 80, 20);
		panel1.add(labelMaBenh);
		
		textfieldMaBenh = new JTextField();
		textfieldMaBenh.setColumns(10);
		textfieldMaBenh.setBounds(90, 70, 80, 20);
		panel1.add(textfieldMaBenh);
		
		JLabel labelMaPhong = new JLabel("Ma Phong : ");
		labelMaPhong.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMaPhong.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaPhong.setBounds(10, 100, 80, 20);
		panel1.add(labelMaPhong);
		
		textfieldMaPhong = new JTextField();
		textfieldMaPhong.setColumns(10);
		textfieldMaPhong.setBounds(90, 100, 80, 20);
		panel1.add(textfieldMaPhong);
		
		JLabel labelHinhThuc = new JLabel("Hinh Thuc : ");
		labelHinhThuc.setHorizontalAlignment(SwingConstants.RIGHT);
		labelHinhThuc.setFont(new Font("Bevan", Font.BOLD, 12));
		labelHinhThuc.setBounds(180, 10, 80, 20);
		panel1.add(labelHinhThuc);

		rbuttonTaiGia = new JRadioButton("Tai Gia");
		rbuttonTaiGia.setBackground(Color.decode("#d6e7ef"));
		rbuttonTaiGia.setBounds(260, 10, 50, 20);
		rbuttonTaiGia.setActionCommand("Tai gia");
		panel1.add(rbuttonTaiGia);
		
		rbuttonNhapVien = new JRadioButton("Nhap Vien");
		rbuttonNhapVien.setBackground(Color.decode("#d6e7ef"));
		rbuttonNhapVien.setBounds(310, 10, 50, 20);
		rbuttonNhapVien.setActionCommand("Nhap Vien");
		panel1.add(rbuttonNhapVien);
		
		rbuttonCachLy = new JRadioButton("Cach Ly");
		rbuttonCachLy.setBackground(Color.decode("#d6e7ef"));
		rbuttonCachLy.setBounds(360, 10, 50, 20);
		rbuttonCachLy.setActionCommand("Cach ly");
		panel1.add(rbuttonCachLy);
		
		bgroupHinhThuc = new ButtonGroup();
		bgroupHinhThuc.add(rbuttonTaiGia);
		bgroupHinhThuc.add(rbuttonNhapVien);
		bgroupHinhThuc.add(rbuttonCachLy);
		
		JLabel labelNgayBatDau = new JLabel("Ngay Bat Dau: ");
		labelNgayBatDau.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgayBatDau.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgayBatDau.setBounds(180, 40, 80, 20);
		panel1.add(labelNgayBatDau);
		
		NgayBatDau = new JDateChooser();
		NgayBatDau.setBounds(260, 40, 80, 20);
		panel1.add(NgayBatDau);
		
		JLabel labelNgayKetThuc = new JLabel("Ngay Ket Thuc: ");
		labelNgayKetThuc.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgayKetThuc.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgayKetThuc.setBounds(180, 70, 80, 20);
		panel1.add(labelNgayKetThuc);
		
		NgayKetThuc = new JDateChooser();
		NgayKetThuc.setBounds(260, 70, 80, 20);
		panel1.add(NgayKetThuc);
		
		JLabel labelMucDo = new JLabel("Muc Do : ");
		labelMucDo.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMucDo.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMucDo.setBounds(420, 40, 80, 20);
		panel1.add(labelMucDo);
		
		comboBoxMucDo = new JComboBox(listMucDo);
		comboBoxMucDo.setBounds(500, 40, 80, 20);
		panel1.add(comboBoxMucDo);
		
		JLabel labelTinhTrang = new JLabel("Tinh Trang : ");
		labelTinhTrang.setHorizontalAlignment(SwingConstants.RIGHT);
		labelTinhTrang.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTinhTrang.setBounds(420, 70, 80, 20);
		panel1.add(labelTinhTrang);
		
		comboBoxTinhTrang = new JComboBox(listTinhTrang);
		comboBoxTinhTrang.setBounds(500, 70, 80, 20);
		panel1.add(comboBoxTinhTrang);
	
		//////////////////////////////////////////////////////////
		
		JLabel labelLoaiTraCuu = new JLabel("Loai Tra Cuu : ");
		labelLoaiTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelLoaiTraCuu.setBounds(10, 130, 80, 20);
		labelLoaiTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelLoaiTraCuu);
		
		comboBoxLoaiTraCuu = new JComboBox(listLoaiTraCuu);
		comboBoxLoaiTraCuu.setBounds(90, 130, 80, 20);
		comboBoxLoaiTraCuu.addActionListener(this);
		panel1.add(comboBoxLoaiTraCuu);
		
		JLabel labelChiTietTraCuu = new JLabel("Chi Tiet Tra Cuu : ");
		labelChiTietTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		labelChiTietTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelChiTietTraCuu.setBounds(210, 130, 120, 20);
		panel1.add(labelChiTietTraCuu);
		
		textfieldChiTietTraCuu = new JTextField();
		textfieldChiTietTraCuu.setColumns(10);
		textfieldChiTietTraCuu.setBounds(330, 130, 80, 20);
		panel1.add(textfieldChiTietTraCuu);
		
		NgayBatDauTraCuu = new JDateChooser();
		NgayBatDauTraCuu.setBounds(330, 130, 80, 20);
		NgayBatDauTraCuu.setVisible(false);
		panel1.add(NgayBatDauTraCuu);
		
		NgayKetThucTraCuu = new JDateChooser();
		NgayKetThucTraCuu.setBounds(330, 130, 80, 20);
		NgayKetThucTraCuu.setVisible(false);
		panel1.add(NgayKetThucTraCuu);
		
		rbuttonTaiGiaTraCuu = new JRadioButton("Tai Gia");
		rbuttonTaiGiaTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonTaiGiaTraCuu.setBounds(330, 130, 50, 20);
		rbuttonTaiGiaTraCuu.setActionCommand("Tai gia");
		rbuttonTaiGiaTraCuu.setVisible(false);
		panel1.add(rbuttonTaiGiaTraCuu);
		
		rbuttonNhapVienTraCuu = new JRadioButton("Nhap Vien");
		rbuttonNhapVienTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonNhapVienTraCuu.setBounds(380, 130, 50, 20);
		rbuttonNhapVienTraCuu.setActionCommand("Nhap vien");
		rbuttonNhapVienTraCuu.setVisible(false);
		panel1.add(rbuttonNhapVienTraCuu);
		
		rbuttonCachLyTraCuu = new JRadioButton("Cach Ly");
		rbuttonCachLyTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonCachLyTraCuu.setBounds(430, 130, 50, 20);
		rbuttonCachLyTraCuu.setActionCommand("Cach ly");
		rbuttonCachLyTraCuu.setVisible(false);
		panel1.add(rbuttonCachLyTraCuu);
		
		bgroupHinhThucTraCuu = new ButtonGroup();
		bgroupHinhThucTraCuu.add(rbuttonTaiGiaTraCuu);
		bgroupHinhThucTraCuu.add(rbuttonNhapVienTraCuu);
		bgroupHinhThucTraCuu.add(rbuttonCachLyTraCuu);
		
		comboBoxMucDoTraCuu = new JComboBox(listMucDo);
		comboBoxMucDoTraCuu.setBounds(330, 130, 80, 20);
		comboBoxMucDoTraCuu.setVisible(false);
		panel1.add(comboBoxMucDoTraCuu);
		
		comboBoxTinhTrangTraCuu = new JComboBox(listTinhTrang);
		comboBoxTinhTrangTraCuu.setBounds(330, 130, 80, 20);
		comboBoxTinhTrangTraCuu.setVisible(false);
		panel1.add(comboBoxTinhTrangTraCuu);
		

		buttonTraCuu = new JButton("Tra Cuu");
		buttonTraCuu.setForeground(Color.decode("#28526a"));
		buttonTraCuu.setBackground(Color.decode("#91B6C9"));
		buttonTraCuu.addActionListener(this);
		buttonTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonTraCuu.setBounds(500, 130, 85, 21);
		buttonTraCuu.setBorderPainted(false);
		panel1.add(buttonTraCuu);
		
		buttonCapNhat = new JButton("Cap Nhat");
		buttonCapNhat.setForeground(Color.decode("#28526a"));
		buttonCapNhat.setBackground(Color.decode("#91B6C9"));
		buttonCapNhat.addActionListener(this);
		buttonCapNhat.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonCapNhat.setBounds(80, 30, 85, 21);
		buttonCapNhat.setBorderPainted(false);
		panel2.add(buttonCapNhat);
		
		buttonQuayLai = new JButton("Quay Lai");
		buttonQuayLai.addActionListener(this);
		buttonQuayLai.setForeground(Color.decode("#28526a"));
		buttonQuayLai.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonQuayLai.setBackground(Color.decode("#91B6C9"));
		buttonQuayLai.setBounds(400, 30, 85, 21);
		buttonQuayLai.setBorderPainted(false);
		panel2.add(buttonQuayLai);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setPreferredSize(new Dimension (100, 100));
		panelContent.add(scrollPane,BorderLayout.CENTER);
		table = new JTable() {
			boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false, false, false, false
				};
			@Override
		    public boolean isCellEditable(int rowIndex, int columnIndex)
		    {
		        return columnEditables[columnIndex];
		    }	};
		table.setBackground(Color.decode("#d6e7ef"));
		table.setFont(new Font("Bevan", Font.PLAIN, 10));
		
		setInformation();
		scrollPane.setViewportView(table);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonTraCuu) {
			TraCuu();
		}
		else if (e.getSource() == buttonCapNhat) {
			CapNhat();
			setInformation();
		}
		else if (e.getSource() == buttonQuayLai) {
			QuayLai();
		}
		else if (e.getSource() == comboBoxLoaiTraCuu) {
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Hinh Thuc")) {
				setVisibleFalseForAllChiTietTraCuu();
				rbuttonTaiGiaTraCuu.setVisible(true);
				rbuttonNhapVienTraCuu.setVisible(true);
				rbuttonCachLyTraCuu.setVisible(true);
			}
			else if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Bat Dau")) {
				setVisibleFalseForAllChiTietTraCuu();
				NgayBatDauTraCuu.setVisible(true);
			}
			else if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Ket Thuc")) {
				setVisibleFalseForAllChiTietTraCuu();
				NgayKetThucTraCuu.setVisible(true);
			}
			else if(comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Muc Do")) {
				setVisibleFalseForAllChiTietTraCuu();
				comboBoxMucDoTraCuu.setVisible(true);
			}
			else if(comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tinh Trang")) {
				setVisibleFalseForAllChiTietTraCuu();
				comboBoxTinhTrangTraCuu.setVisible(true);
			}
			else
			{
				setVisibleFalseForAllChiTietTraCuu();
				textfieldChiTietTraCuu.setVisible(true);
			}
		}
	}
	


public void setInformation() { 
		
		String query = "SELECT * FROM CABENH ORDER BY MABN, MABS, MABENH ASC";

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma BN","Ma BS","Ma Benh","Muc Do","Hinh Thuc","Ngay Bat Dau","Ngay Ket Thuc","Tinh Trang","Ma Phong"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			} 
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
}
	
	

public void TraCuu() { 
	
	if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tat Ca")
			|| (!(textfieldChiTietTraCuu.getText().equals("")))
			|| (!(NgayBatDauTraCuu.getDate() == null))
			|| (!(NgayKetThucTraCuu.getDate() == null))
			|| (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Muc Do"))
			|| (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tinh Trang"))
			|| (!(bgroupHinhThucTraCuu.getSelection() == null))) {
		
		String query = "SELECT * FROM CABENH WHERE MABN = MABN";
		
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma BN")) {
			query += " AND MABN = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma BS")) {
			query += " AND MABS = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma Benh")) {
			query += " AND MABENH = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma Phong")) {
			query += " AND MAPHONG = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Bat Dau")) {
			Date date = NgayBatDauTraCuu.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String dateString = sdf.format(date);
			if (!(dateString.equals(""))) {
				query += " AND NGAYBATDAU = TO_DATE('" + dateString + "','YYYY-MM-DD')";
			}
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Ket Thuc")) {
			Date date = NgayKetThucTraCuu.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String dateString = sdf.format(date);
			if (!(dateString.equals(""))) {
				query += " AND NGAYKETTHUC = TO_DATE('" + dateString + "','YYYY-MM-DD')";
			}
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Muc Do")) {
			query += " AND MUCDO = '" + comboBoxMucDoTraCuu.getItemAt(comboBoxMucDoTraCuu.getSelectedIndex()) + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tinh Trang")) {
			query += " AND TRINHTRANG = '" + comboBoxTinhTrangTraCuu.getItemAt(comboBoxTinhTrangTraCuu.getSelectedIndex()) + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Hinh Thuc") ) {
			query += " AND HINHTHUC = '" + bgroupHinhThucTraCuu.getSelection().getActionCommand() + "'";
		}
		
			query += " ORDER BY MABN, MABS, MABENH ASC";
			
		System.out.println(query);


			try {
				Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
				Statement statement = connection.createStatement();
				ResultSet resultset = statement.executeQuery(query);
				ResultSetMetaData metadata = resultset.getMetaData();
				int columnCount = metadata.getColumnCount();
				DefaultTableModel data = (DefaultTableModel) table.getModel();
				
				data.setColumnIdentifiers(new String[] {"Ma BN","Ma BS","Ma Benh","Muc Do","Hinh Thuc","Ngay Bat Dau","Ngay Ket Thuc","Tinh Trang","Ma Phong"});
				data.setRowCount(0);
				
				while(resultset.next()) {
					Vector row = new Vector();
					for (int i = 0; i < columnCount; i++)
						row.add(resultset.getString(i+1));
					data.addRow(row);
				
				}
				
				
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
		}
		 RefreshForTraCuu();
	}

		
	
	
	public void CapNhat() {
		
		String query = "UPDATE CABENH SET MABN = MABN";
			if (!(textfieldMaPhong.getText().equals(""))) {
				query += ", MAPHONG = '" + textfieldMaPhong.getText() + "'";
			}
			else {
				query += ", MAPHONG = NULL";
			}
			if (bgroupHinhThuc.getSelection() != null) {
				query += ", HINHTHUC = '" + bgroupHinhThuc.getSelection().getActionCommand() + "'";
			}
			else {
				query += ", HINHTHUC = NULL";
			}	
			if (NgayKetThuc.getDate() != null) {
				Date date = NgayKetThuc.getDate();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String dateString = sdf.format(date);
				query += ", NGAYKETTHUC = TO_DATE('" + dateString + "','YYYY-MM-DD')";
			}
			else {
				query += ", NGAYKETTHUC = NULL";
			}		
			if (!(comboBoxMucDo.getItemAt(comboBoxMucDo.getSelectedIndex()).equals(""))) {
				query += ", MUCDO = '" + comboBoxMucDo.getItemAt(comboBoxMucDo.getSelectedIndex()) + "'";
			}
			else {
				query += ", MUCDO = NULL";
			}
			if (!(comboBoxTinhTrang.getItemAt(comboBoxTinhTrang.getSelectedIndex()).equals(""))) {
				query += ", TINHTRANG = '" + comboBoxTinhTrang.getItemAt(comboBoxTinhTrang.getSelectedIndex()) + "'";
			}
			else {
				query += ", TINHTRANG = NULL";
			}
				
			if (!(textfieldMaBN.getText().equals("")) || !(textfieldMaBS.getText().equals("")) || !(textfieldMaBenh.getText().equals("")) || NgayBatDau.getDate() != null) {
				query += " WHERE MABN = MABN";
			}
			else {
				query += " WHERE MABN = NULL";
			}
			if (!(textfieldMaBN.getText().equals(""))) {
				query += " AND MABN = '" + textfieldMaBN.getText() + "'";
			}
			if (!(textfieldMaBS.getText().equals(""))) {
				query += " AND MABS = '" + textfieldMaBS.getText() + "'";
			}
			if (!(textfieldMaBenh.getText().equals(""))) {
				query += " AND MABENH = '" + textfieldMaBenh.getText() + "'";
			}		
			if (NgayBatDau.getDate() != null) {
				Date date = NgayBatDau.getDate();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String dateString = sdf.format(date);
				query += " AND NGAYBATDAU = TO_DATE('" + dateString + "','YYYY-MM-DD')";
			}	
				
				System.out.println(query);
				

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			int changedrows = statement.executeUpdate(query);
			if (changedrows > 0) {
				JOptionPane.showMessageDialog(null, "Cap Nhat Thanh Cong", "Thong Bao", JOptionPane.INFORMATION_MESSAGE);
			}
			
			statement.close();
			connection.close();
			
			setInformation();
			
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		//Refresh();
	}
	
	public void QuayLai() {
		MyHome.getPanelContent().removeAll();
		switch (MyHome.getPreviousClass("CaBenh","CapNhat")) {
		case "CaBenh":
			MyHome.getPanelContent().add(new CaBenh(MyHome).getpanelContent());
			break;
		case "TraCuu":
			MyHome.getPanelContent().add(new CaBenh_TraCuu(MyHome).getpanelContent());
			break;
		}
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
	}
	
	public void Refresh() {
		textfieldMaBN.setText("");
		textfieldMaBS.setText("");
		textfieldMaBenh.setText("");
		textfieldMaPhong.setText("");
		bgroupHinhThuc.clearSelection();
		NgayBatDau.setDate(null);
		NgayKetThuc.setDate(null);
		comboBoxMucDo.setSelectedIndex(0);
		comboBoxTinhTrang.setSelectedIndex(0);
	}
	
	public void RefreshForTraCuu() {
		//comboBoxLoaiTraCuu.setSelectedIndex(0);
		comboBoxMucDoTraCuu.setSelectedIndex(0);
		comboBoxTinhTrangTraCuu.setSelectedIndex(0);
		bgroupHinhThucTraCuu.clearSelection();
		NgayBatDauTraCuu.setDate(null);
		NgayKetThucTraCuu.setDate(null);
		textfieldChiTietTraCuu.setText("");
	}
	
	public void setVisibleFalseForAllChiTietTraCuu() {
		rbuttonTaiGiaTraCuu.setVisible(false);
		rbuttonNhapVienTraCuu.setVisible(false);
		rbuttonCachLyTraCuu.setVisible(false);
		NgayBatDauTraCuu.setVisible(false);
		NgayKetThucTraCuu.setVisible(false);
		comboBoxMucDoTraCuu.setVisible(false);
		comboBoxTinhTrangTraCuu.setVisible(false);
		textfieldChiTietTraCuu.setVisible(false);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
