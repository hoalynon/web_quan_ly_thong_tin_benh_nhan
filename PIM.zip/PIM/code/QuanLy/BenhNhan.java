package QuanLy;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import java.sql.*;
import java.util.*;

public class BenhNhan implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonTraCuu;
	private JButton buttonThem;
	private JButton buttonCapNhat;
	private JButton buttonXoa;
	
	private JTable table;
	
	BenhNhan(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (80,50));
		panelContent.add(panel1,BorderLayout.NORTH);
		
		JLabel title = new JLabel("Danh Sach Benh Nhan"); 
		title.setForeground(Color.decode("#28526a"));
		title.setBackground(Color.decode("#d6e7ef"));
		title.setFont(new Font("Bevan", Font.BOLD, 16));
		title.setHorizontalAlignment(JLabel.CENTER);
		panel1.setLayout(new GridBagLayout());
		GridBagConstraints gbc_title = new GridBagConstraints();
		gbc_title.gridx = 0;
		panel1.add(title, gbc_title);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(null);
		panelContent.add(panel2, BorderLayout.SOUTH);
		
		buttonTraCuu = new JButton("Tra Cuu");
		buttonTraCuu.setForeground(Color.decode("#28526a"));
		buttonTraCuu.setBackground(Color.decode("#91B6C9"));
		buttonTraCuu.addActionListener(this);
		buttonTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonTraCuu.setBounds(50, 30, 85, 21);
		buttonTraCuu.setBorderPainted(false);
		panel2.add(buttonTraCuu);
		
		buttonThem = new JButton("Them");
		buttonThem.setForeground(Color.decode("#28526a"));
		buttonThem.setBackground(Color.decode("#91B6C9"));
		buttonThem.addActionListener(this);
		buttonThem.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonThem.setBounds(180, 30, 85, 21);
		buttonThem.setBorderPainted(false);
		panel2.add(buttonThem);
		
		buttonCapNhat = new JButton("Cap Nhat");
		buttonCapNhat.setForeground(Color.decode("#28526a"));
		buttonCapNhat.setBackground(Color.decode("#91B6C9"));
		buttonCapNhat.addActionListener(this);
		buttonCapNhat.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonCapNhat.setBounds(310, 30, 85, 21);
		buttonCapNhat.setBorderPainted(false);
		panel2.add(buttonCapNhat);
		
		buttonXoa = new JButton("Xoa");
		buttonXoa.setForeground(Color.decode("#28526a"));
		buttonXoa.setBackground(Color.decode("#91B6C9"));
		buttonXoa.addActionListener(this);
		buttonXoa.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonXoa.setBounds(440, 30, 97, 21);
		buttonXoa.setBorderPainted(false);
		panel2.add(buttonXoa);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setPreferredSize(new Dimension (100, 100));
		panelContent.add(scrollPane,BorderLayout.CENTER);
		
		table = new JTable() {
			boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false
				};
			@Override
		    public boolean isCellEditable(int rowIndex, int columnIndex)
		    {
		        return columnEditables[columnIndex];
		    }	};
		table.setBackground(Color.decode("#d6e7ef"));
		table.setFont(new Font("Bevan", Font.PLAIN, 10));
		
		setInformation();
		scrollPane.setViewportView(table);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonTraCuu) {
			TraCuu();
		}
		else if (e.getSource() == buttonThem) {
			Them();
		}
		else if (e.getSource() == buttonCapNhat) {
			CapNhat();
		}
		else if (e.getSource() == buttonXoa) {
			Xoa();
		}
	}
	

	public void setInformation() { 
		
		String query = "SELECT * FROM BENHNHAN ORDER BY MABN ASC";

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma BN", "Ho Ten", "Gioi Tinh", "Ngay Sinh", "Que Quan", "Noi O Hien Tai"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			} 
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
	}
	
	public void TraCuu() {
		MyHome.getPanelContent().removeAll();
		MyHome.getPanelContent().add(new BenhNhan_TraCuu(MyHome).getpanelContent());
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
		MyHome.setPreviousClass("BenhNhan","TraCuu", "BenhNhan");
	}
	
	public void Them() {
		MyHome.getPanelContent().removeAll();
		MyHome.getPanelContent().add(new BenhNhan_Them(MyHome).getpanelContent());
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
		MyHome.setPreviousClass("BenhNhan","Them", "BenhNhan");
	}
	
	public void CapNhat() {
		MyHome.getPanelContent().removeAll();
		MyHome.getPanelContent().add(new BenhNhan_CapNhat(MyHome).getpanelContent());
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
		MyHome.setPreviousClass("BenhNhan","CapNhat", "BenhNhan");
	}
	
	public void Xoa() {
		MyHome.getPanelContent().removeAll();
		MyHome.getPanelContent().add(new BenhNhan_Xoa(MyHome).getpanelContent());
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
		MyHome.setPreviousClass("BenhNhan","Xoa", "BenhNhan");
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
