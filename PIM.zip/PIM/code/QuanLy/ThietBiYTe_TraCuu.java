package QuanLy;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import java.sql.*;
import java.util.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import com.toedter.calendar.JDateChooser;


public class ThietBiYTe_TraCuu implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonTraCuu;
	private JButton buttonCapNhat;
	private JButton buttonXoa;
	private JButton buttonQuayLai;
	
	private JRadioButton rbutton1LanTraCuu;
	private JRadioButton rbuttonTaiSuDungTraCuu;
	private ButtonGroup bgroupLoaiSDTraCuu;
	
	private JTextField textfieldChiTietTraCuu;
	
	private JTable table;
	private JComboBox comboBoxLoaiTraCuu;
	
	private String listLoaiTraCuu[]  = {"Tat Ca","Ma Thiet Bi","Ten Thiet Bi","Loai SD","Cong Dung","So Luong"}; 
	
	ThietBiYTe_TraCuu(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (80,80));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.NORTH);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(null);
		panelContent.add(panel2, BorderLayout.SOUTH);
		
		JLabel labelLoaiTraCuu = new JLabel("Loai Tra Cuu : ");
		labelLoaiTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelLoaiTraCuu.setBounds(10, 30, 80, 20);
		labelLoaiTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelLoaiTraCuu);
		
		comboBoxLoaiTraCuu = new JComboBox(listLoaiTraCuu);
		comboBoxLoaiTraCuu.setBounds(90, 30, 80, 20);
		comboBoxLoaiTraCuu.addActionListener(this);
		panel1.add(comboBoxLoaiTraCuu);
		
		JLabel labelChiTietTraCuu = new JLabel("Chi Tiet Tra Cuu : ");
		labelChiTietTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		labelChiTietTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelChiTietTraCuu.setBounds(210, 30, 120, 20);
		panel1.add(labelChiTietTraCuu);
		
		textfieldChiTietTraCuu = new JTextField();
		textfieldChiTietTraCuu.setColumns(10);
		textfieldChiTietTraCuu.setBounds(330, 30, 80, 20);
		panel1.add(textfieldChiTietTraCuu);
		
		rbutton1LanTraCuu = new JRadioButton("1 Lan");
		rbutton1LanTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbutton1LanTraCuu.setBounds(330, 30, 50, 20);
		rbutton1LanTraCuu.setActionCommand("1 lan");
		rbutton1LanTraCuu.setVisible(false);
		panel1.add(rbutton1LanTraCuu);
		
		rbuttonTaiSuDungTraCuu = new JRadioButton("Tai Su Dung");
		rbuttonTaiSuDungTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonTaiSuDungTraCuu.setBounds(380, 30, 50, 20);
		rbuttonTaiSuDungTraCuu.setActionCommand("Tai su dung");
		rbuttonTaiSuDungTraCuu.setVisible(false);
		panel1.add(rbuttonTaiSuDungTraCuu);
		
		bgroupLoaiSDTraCuu = new ButtonGroup();
		bgroupLoaiSDTraCuu.add(rbutton1LanTraCuu);
		bgroupLoaiSDTraCuu.add(rbuttonTaiSuDungTraCuu);
		
		buttonTraCuu = new JButton("Tra Cuu");
		buttonTraCuu.setForeground(Color.decode("#28526a"));
		buttonTraCuu.setBackground(Color.decode("#91B6C9"));
		buttonTraCuu.addActionListener(this);
		buttonTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonTraCuu.setBounds(500, 30, 85, 21);
		buttonTraCuu.setBorderPainted(false);
		panel1.add(buttonTraCuu);
		
		buttonCapNhat = new JButton("Cap Nhat");
		buttonCapNhat.setForeground(Color.decode("#28526a"));
		buttonCapNhat.setBackground(Color.decode("#91B6C9"));
		buttonCapNhat.addActionListener(this);
		buttonCapNhat.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonCapNhat.setBounds(80, 30, 85, 21);
		buttonCapNhat.setBorderPainted(false);
		panel2.add(buttonCapNhat);
		
		buttonXoa = new JButton("Xoa");
		buttonXoa.setForeground(Color.decode("#28526a"));
		buttonXoa.setBackground(Color.decode("#91B6C9"));
		buttonXoa.addActionListener(this);
		buttonXoa.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonXoa.setBounds(240, 30, 97, 21);
		buttonXoa.setBorderPainted(false);
		panel2.add(buttonXoa);
		
		buttonQuayLai = new JButton("Quay Lai");
		buttonQuayLai.addActionListener(this);
		buttonQuayLai.setForeground(Color.decode("#28526a"));
		buttonQuayLai.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonQuayLai.setBackground(Color.decode("#91B6C9"));
		buttonQuayLai.setBounds(400, 30, 85, 21);
		buttonQuayLai.setBorderPainted(false);
		panel2.add(buttonQuayLai);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setPreferredSize(new Dimension (100, 100));
		panelContent.add(scrollPane,BorderLayout.CENTER);
		
		table = new JTable() {
			boolean[] columnEditables = new boolean[] {
					false, false, false, false, false
				};
			@Override
		    public boolean isCellEditable(int rowIndex, int columnIndex)
		    {
		        return columnEditables[columnIndex];
		    }	};
		table.setBackground(Color.decode("#d6e7ef"));
		table.setFont(new Font("Bevan", Font.PLAIN, 10));
		
		setInformation();
		scrollPane.setViewportView(table);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonTraCuu) {
			TraCuu();
		}
		else if (e.getSource() == buttonCapNhat) {
			CapNhat();
			setInformation();
		}
		else if (e.getSource() == buttonXoa) {
			Xoa();
			setInformation();
		}
		else if (e.getSource() == buttonQuayLai) {
			QuayLai();
		}
		else if (e.getSource() == comboBoxLoaiTraCuu) {
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Loai SD")) {
				setVisibleFalseForAllChiTietTraCuu();
				rbutton1LanTraCuu.setVisible(true);
				rbuttonTaiSuDungTraCuu.setVisible(true);
			}
			else
			{
				setVisibleFalseForAllChiTietTraCuu();
				textfieldChiTietTraCuu.setVisible(true);
			}
		}
	}
	

public void setInformation() { 
		
		String query = "SELECT * FROM THIETBIYTE ORDER BY MATHIETBI ASC";

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma Thiet Bi","Ten Thiet Bi","Loai SD","Cong Dung","So Luong"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			} 
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
}
	
	

public void TraCuu() { 
	
	if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tat Ca")
			|| (!(textfieldChiTietTraCuu.getText().equals("")))
			|| (!(bgroupLoaiSDTraCuu.getSelection() == null))) {
		
		String query = "SELECT * FROM THIETBIYTE WHERE MATHIETBI = MATHIETBI";
		
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma Thiet Bi")) {
			query += " AND MATHIETBI = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ten Thiet Bi")) {
			query += " AND TENTHIETBI = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Cong Dung")) {
			query += " AND CONGDUNG = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("So Luong")) {
			query += " AND SOLUONG = " + textfieldChiTietTraCuu.getText();
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Loai SD") ) {
			query += " AND LOAISD = '" + bgroupLoaiSDTraCuu.getSelection().getActionCommand() + "'";
		}
			query += " ORDER BY MATHIETBI ASC";
			
		System.out.println(query);


			try {
				Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
				Statement statement = connection.createStatement();
				ResultSet resultset = statement.executeQuery(query);
				ResultSetMetaData metadata = resultset.getMetaData();
				int columnCount = metadata.getColumnCount();
				DefaultTableModel data = (DefaultTableModel) table.getModel();
				
				data.setColumnIdentifiers(new String[] {"Ma Thiet Bi","Ten Thiet Bi","Loai SD","Cong Dung","So Luong"});
				data.setRowCount(0);
				
				while(resultset.next()) {
					Vector row = new Vector();
					for (int i = 0; i < columnCount; i++)
						row.add(resultset.getString(i+1));
					data.addRow(row);
				
				}
				
				
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
		}
		 RefreshForTraCuu();
	}

	
	public void CapNhat() {
		
		MyHome.getPanelContent().removeAll();
		MyHome.getPanelContent().add(new ThietBiYTe_CapNhat(MyHome).getpanelContent());
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
		MyHome.setPreviousClass("ThietBiYTe","CapNhat", "TraCuu");
		
	}
	
	public void Xoa() {
		MyHome.getPanelContent().removeAll();
		MyHome.getPanelContent().add(new ThietBiYTe_Xoa(MyHome).getpanelContent());
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
		MyHome.setPreviousClass("ThietBiYTe","Xoa", "TraCuu");
	}
	
	public void QuayLai() {
		MyHome.getPanelContent().removeAll();
		switch (MyHome.getPreviousClass("ThietBiYTe","TraCuu")) {
		case "ThietBiYTe":
			MyHome.getPanelContent().add(new ThietBiYTe(MyHome).getpanelContent());
			break;
		}
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
	}
	
	public void RefreshForTraCuu() {
		//comboBoxLoaiTraCuu.setSelectedIndex(0);
		bgroupLoaiSDTraCuu.clearSelection();
		textfieldChiTietTraCuu.setText("");
	}
	
	public void setVisibleFalseForAllChiTietTraCuu() {
		rbutton1LanTraCuu.setVisible(false);
		rbuttonTaiSuDungTraCuu.setVisible(false);
		textfieldChiTietTraCuu.setVisible(false);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
