package QuanLy;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import java.sql.*;
import java.util.*;


public class Benh_TraCuu implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonTraCuu;
	private JButton buttonCapNhat;
	private JButton buttonXoa;
	private JButton buttonQuayLai;
	
	private JTextField textfieldChiTietTraCuu;
	
	private JTable table;
	private JComboBox comboBoxLoaiTraCuu;
	
	private String listLoaiTraCuu[]  = {"Tat Ca","Ma Benh","Ten Benh","Ten Khoa"}; 
	
	Benh_TraCuu(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (80,80));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.NORTH);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(null);
		panelContent.add(panel2, BorderLayout.SOUTH);
		
		JLabel labelLoaiTraCuu = new JLabel("Loai Tra Cuu : ");
		labelLoaiTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelLoaiTraCuu.setBounds(10, 30, 100, 20);
		labelLoaiTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelLoaiTraCuu);
		
		comboBoxLoaiTraCuu = new JComboBox(listLoaiTraCuu);
		comboBoxLoaiTraCuu.setBounds(110, 30, 80, 20);
		comboBoxLoaiTraCuu.addActionListener(this);
		panel1.add(comboBoxLoaiTraCuu);
		
		JLabel labelChiTietTraCuu = new JLabel("Chi Tiet Tra Cuu : ");
		labelChiTietTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		labelChiTietTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelChiTietTraCuu.setBounds(210, 30, 120, 20);
		panel1.add(labelChiTietTraCuu);
		
		textfieldChiTietTraCuu = new JTextField();
		textfieldChiTietTraCuu.setColumns(10);
		textfieldChiTietTraCuu.setBounds(330, 30, 80, 20);
		panel1.add(textfieldChiTietTraCuu);
		
		buttonTraCuu = new JButton("Tra Cuu");
		buttonTraCuu.setForeground(Color.decode("#28526a"));
		buttonTraCuu.setBackground(Color.decode("#91B6C9"));
		buttonTraCuu.addActionListener(this);
		buttonTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonTraCuu.setBounds(500, 30, 85, 21);
		buttonTraCuu.setBorderPainted(false);
		panel1.add(buttonTraCuu);
		
		buttonCapNhat = new JButton("Cap Nhat");
		buttonCapNhat.setForeground(Color.decode("#28526a"));
		buttonCapNhat.setBackground(Color.decode("#91B6C9"));
		buttonCapNhat.addActionListener(this);
		buttonCapNhat.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonCapNhat.setBounds(80, 30, 85, 21);
		buttonCapNhat.setBorderPainted(false);
		panel2.add(buttonCapNhat);
		
		buttonXoa = new JButton("Xoa");
		buttonXoa.setForeground(Color.decode("#28526a"));
		buttonXoa.setBackground(Color.decode("#91B6C9"));
		buttonXoa.addActionListener(this);
		buttonXoa.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonXoa.setBounds(240, 30, 97, 21);
		buttonXoa.setBorderPainted(false);
		panel2.add(buttonXoa);
		
		buttonQuayLai = new JButton("Quay Lai");
		buttonQuayLai.addActionListener(this);
		buttonQuayLai.setForeground(Color.decode("#28526a"));
		buttonQuayLai.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonQuayLai.setBackground(Color.decode("#91B6C9"));
		buttonQuayLai.setBounds(400, 30, 85, 21);
		buttonQuayLai.setBorderPainted(false);
		panel2.add(buttonQuayLai);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setPreferredSize(new Dimension (100, 100));
		panelContent.add(scrollPane,BorderLayout.CENTER);
		
		table = new JTable() {
			boolean[] columnEditables = new boolean[] {
					false, false, false
				};
			@Override
		    public boolean isCellEditable(int rowIndex, int columnIndex)
		    {
		        return columnEditables[columnIndex];
		    }	};
		table.setBackground(Color.decode("#d6e7ef"));
		table.setFont(new Font("Bevan", Font.PLAIN, 10));
		
		setInformation();
		scrollPane.setViewportView(table);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonTraCuu) {
			TraCuu();
		}
		else if (e.getSource() == buttonCapNhat) {
			CapNhat();
			setInformation();
		}
		else if (e.getSource() == buttonXoa) {
			Xoa();
			setInformation();
		}
		else if (e.getSource() == buttonQuayLai) {
			QuayLai();
		}
		else if (e.getSource() == comboBoxLoaiTraCuu) {
			if (false) {}
			else
			{
				setVisibleFalseForAllChiTietTraCuu();
				textfieldChiTietTraCuu.setVisible(true);
			}
		}
	}
	

public void setInformation() { 
		
		String query = "SELECT * FROM BENH ORDER BY MABENH ASC";

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma Benh","Ten Benh","Ten Khoa"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			} 
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
}
	

public void TraCuu() { 
	
	if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tat Ca")
			|| (!(textfieldChiTietTraCuu.getText().equals("")))
			) {
		
		String query = "SELECT * FROM BENH WHERE MABENH = MABENH";
		
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma Benh")) {
			query += " AND MABENH = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ten Benh")) {
			query += " AND TENBENH = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ten Khoa")) {
			query += " AND TENKHOA = '" + textfieldChiTietTraCuu.getText() + "'";
		}
			query += " ORDER BY MABENH ASC";
		System.out.println(query);


		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma Benh","Ten Benh","Ten Khoa"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			
			}
			
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
	 RefreshForTraCuu();
}

	
	public void CapNhat() {
		
		MyHome.getPanelContent().removeAll();
		MyHome.getPanelContent().add(new Benh_CapNhat(MyHome).getpanelContent());
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
		MyHome.setPreviousClass("Benh","CapNhat", "TraCuu");
		
	}
	
	public void Xoa() {
		MyHome.getPanelContent().removeAll();
		MyHome.getPanelContent().add(new Benh_Xoa(MyHome).getpanelContent());
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
		MyHome.setPreviousClass("Benh","Xoa", "TraCuu");
	}
	
	public void QuayLai() {
		MyHome.getPanelContent().removeAll();
		switch (MyHome.getPreviousClass("Benh","TraCuu")) {
		case "Benh":
			MyHome.getPanelContent().add(new Benh(MyHome).getpanelContent());
			break;
		}
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
	}
	
	public void RefreshForTraCuu() {
		//comboBoxLoaiTraCuu.setSelectedIndex(0);
		textfieldChiTietTraCuu.setText("");
	}
	
	public void setVisibleFalseForAllChiTietTraCuu() {
		textfieldChiTietTraCuu.setVisible(false);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
