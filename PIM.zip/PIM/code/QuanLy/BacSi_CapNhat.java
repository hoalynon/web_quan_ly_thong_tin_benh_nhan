package QuanLy;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

public class BacSi_CapNhat implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonTraCuu;
	private JButton buttonCapNhat;
	private JButton buttonQuayLai;
	
	private JRadioButton rbuttonNam;
	private JRadioButton rbuttonNu;
	private ButtonGroup bgroupGioiTinh;
	private JRadioButton rbuttonNamTraCuu;
	private JRadioButton rbuttonNuTraCuu;
	private ButtonGroup bgroupGioiTinhTraCuu;
	
	private JTextField textfieldMaBS;
	private JTextField textfieldHoTen;
	private JTextField textfieldQueQuan;
	private JTextField textfieldNoiOHienTai;
	private JTextField textfieldTenKhoa;
	private JTextField textfieldNamPhucVu;
	private JTextField textfieldChiTietTraCuu;
	
	private JDateChooser NgaySinh;
	private JDateChooser NgaySinhTraCuu;
	
	private JTable table;
	private JComboBox comboBoxLoaiTraCuu;
	
	private String listLoaiTraCuu[]  = {"Tat Ca","Ma BS","Ho Ten","Gioi Tinh","Ngay Sinh","Que Quan","Noi O Hien Tai","Ten Khoa","Nam Phuc Vu"}; 
	
	BacSi_CapNhat(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (160,160));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.NORTH);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(null);
		panelContent.add(panel2, BorderLayout.SOUTH);

		JLabel labelMaBS = new JLabel("Ma BS : ");
		labelMaBS.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBS.setBounds(10, 10, 80, 20);
		labelMaBS.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBS);
		
		textfieldMaBS = new JTextField();
		textfieldMaBS.setBounds(90, 10, 80, 20);
		textfieldMaBS.setColumns(10);
		panel1.add(textfieldMaBS);
		
		JLabel labelHoTen = new JLabel("Ho Ten : ");
		labelHoTen.setFont(new Font("Bevan", Font.BOLD, 12));
		labelHoTen.setBounds(250, 10, 80, 20);
		labelHoTen.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelHoTen);
		
		textfieldHoTen = new JTextField();
		textfieldHoTen.setBounds(330, 10, 80, 20);
		textfieldHoTen.setColumns(10);
		panel1.add(textfieldHoTen);
		
		JLabel labelGioiTinh = new JLabel("Gioi Tinh : ");
		labelGioiTinh.setHorizontalAlignment(SwingConstants.RIGHT);
		labelGioiTinh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelGioiTinh.setBounds(10, 40, 80, 20);
		panel1.add(labelGioiTinh);

		rbuttonNam = new JRadioButton("Nam");
		rbuttonNam.setBackground(Color.decode("#d6e7ef"));
		rbuttonNam.setBounds(90, 40, 50, 20);
		rbuttonNam.setActionCommand("Nam");
		panel1.add(rbuttonNam);
		
		rbuttonNu = new JRadioButton("Nu");
		rbuttonNu.setBackground(Color.decode("#d6e7ef"));
		rbuttonNu.setBounds(140, 40, 50, 20);
		rbuttonNu.setActionCommand("Nu");
		panel1.add(rbuttonNu);
		
		bgroupGioiTinh = new ButtonGroup();
		bgroupGioiTinh.add(rbuttonNam);
		bgroupGioiTinh.add(rbuttonNu);
		
		JLabel labelNgaySinh = new JLabel("Ngay Sinh: ");
		labelNgaySinh.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgaySinh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgaySinh.setBounds(250, 40, 80, 20);
		panel1.add(labelNgaySinh);
		
		NgaySinh = new JDateChooser();
		NgaySinh.setBounds(330, 40, 80, 20);
		panel1.add(NgaySinh);
		
		JLabel labelQueQuan = new JLabel("Que Quan : ");
		labelQueQuan.setHorizontalAlignment(SwingConstants.RIGHT);
		labelQueQuan.setFont(new Font("Bevan", Font.BOLD, 12));
		labelQueQuan.setBounds(10, 70, 80, 20);
		panel1.add(labelQueQuan);
		
		textfieldQueQuan = new JTextField();
		textfieldQueQuan.setColumns(10);
		textfieldQueQuan.setBounds(90, 70, 80, 20);
		panel1.add(textfieldQueQuan);
		
		JLabel labelNoiOHienTai = new JLabel("Noi O : ");
		labelNoiOHienTai.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNoiOHienTai.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNoiOHienTai.setBounds(250, 70, 80, 20);
		panel1.add(labelNoiOHienTai);
		
		textfieldNoiOHienTai = new JTextField();
		textfieldNoiOHienTai.setColumns(10);
		textfieldNoiOHienTai.setBounds(330, 70, 80, 20);
		panel1.add(textfieldNoiOHienTai);
		
		JLabel labelTenKhoa = new JLabel("Ten Khoa : ");
		labelTenKhoa.setHorizontalAlignment(SwingConstants.RIGHT);
		labelTenKhoa.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTenKhoa.setBounds(420, 10, 80, 20);
		panel1.add(labelTenKhoa);
		
		textfieldTenKhoa = new JTextField();
		textfieldTenKhoa.setColumns(10);
		textfieldTenKhoa.setBounds(500, 10, 80, 20);
		panel1.add(textfieldTenKhoa);
		
		JLabel labelNamPhucVu = new JLabel("Nam Phuc Vu : ");
		labelNamPhucVu.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNamPhucVu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNamPhucVu.setBounds(420, 40, 80, 20);
		panel1.add(labelNamPhucVu);
		
		textfieldNamPhucVu = new JTextField();
		textfieldNamPhucVu.setColumns(10);
		textfieldNamPhucVu.setBounds(500, 40, 80, 20);
		panel1.add(textfieldNamPhucVu);
	
		//////////////////////////////////////////////////////////
		
		JLabel labelLoaiTraCuu = new JLabel("Loai Tra Cuu : ");
		labelLoaiTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelLoaiTraCuu.setBounds(10, 130, 80, 20);
		labelLoaiTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelLoaiTraCuu);
		
		comboBoxLoaiTraCuu = new JComboBox(listLoaiTraCuu);
		comboBoxLoaiTraCuu.setBounds(90, 130, 80, 20);
		comboBoxLoaiTraCuu.addActionListener(this);
		panel1.add(comboBoxLoaiTraCuu);
		
		JLabel labelChiTietTraCuu = new JLabel("Chi Tiet Tra Cuu : ");
		labelChiTietTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		labelChiTietTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelChiTietTraCuu.setBounds(210, 130, 120, 20);
		panel1.add(labelChiTietTraCuu);
		
		textfieldChiTietTraCuu = new JTextField();
		textfieldChiTietTraCuu.setColumns(10);
		textfieldChiTietTraCuu.setBounds(330, 130, 80, 20);
		panel1.add(textfieldChiTietTraCuu);
		
		NgaySinhTraCuu = new JDateChooser();
		NgaySinhTraCuu.setBounds(330, 130, 80, 20);
		NgaySinhTraCuu.setVisible(false);
		panel1.add(NgaySinhTraCuu);
		
		rbuttonNamTraCuu = new JRadioButton("Nam");
		rbuttonNamTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonNamTraCuu.setBounds(330, 130, 50, 20);
		rbuttonNamTraCuu.setActionCommand("Nam");
		rbuttonNamTraCuu.setVisible(false);
		panel1.add(rbuttonNamTraCuu);
		
		rbuttonNuTraCuu = new JRadioButton("Nu");
		rbuttonNuTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonNuTraCuu.setBounds(380, 130, 50, 20);
		rbuttonNuTraCuu.setActionCommand("Nu");
		rbuttonNuTraCuu.setVisible(false);
		panel1.add(rbuttonNuTraCuu);
		
		bgroupGioiTinhTraCuu = new ButtonGroup();
		bgroupGioiTinhTraCuu.add(rbuttonNamTraCuu);
		bgroupGioiTinhTraCuu.add(rbuttonNuTraCuu);

		buttonTraCuu = new JButton("Tra Cuu");
		buttonTraCuu.setForeground(Color.decode("#28526a"));
		buttonTraCuu.setBackground(Color.decode("#91B6C9"));
		buttonTraCuu.addActionListener(this);
		buttonTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonTraCuu.setBounds(500, 130, 85, 21);
		buttonTraCuu.setBorderPainted(false);
		panel1.add(buttonTraCuu);
		
		buttonCapNhat = new JButton("Cap Nhat");
		buttonCapNhat.setForeground(Color.decode("#28526a"));
		buttonCapNhat.setBackground(Color.decode("#91B6C9"));
		buttonCapNhat.addActionListener(this);
		buttonCapNhat.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonCapNhat.setBounds(80, 30, 85, 21);
		buttonCapNhat.setBorderPainted(false);
		panel2.add(buttonCapNhat);
		
		buttonQuayLai = new JButton("Quay Lai");
		buttonQuayLai.addActionListener(this);
		buttonQuayLai.setForeground(Color.decode("#28526a"));
		buttonQuayLai.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonQuayLai.setBackground(Color.decode("#91B6C9"));
		buttonQuayLai.setBounds(400, 30, 85, 21);
		buttonQuayLai.setBorderPainted(false);
		panel2.add(buttonQuayLai);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setPreferredSize(new Dimension (100, 100));
		panelContent.add(scrollPane,BorderLayout.CENTER);
		table = new JTable() {
			boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false, false, false
				};
			@Override
		    public boolean isCellEditable(int rowIndex, int columnIndex)
		    {
		        return columnEditables[columnIndex];
		    }	};
		table.setBackground(Color.decode("#d6e7ef"));
		table.setFont(new Font("Bevan", Font.PLAIN, 10));
		
		setInformation();
		scrollPane.setViewportView(table);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonTraCuu) {
			TraCuu();
		}
		else if (e.getSource() == buttonCapNhat) {
			CapNhat();
			setInformation();
		}
		else if (e.getSource() == buttonQuayLai) {
			QuayLai();
		}
		else if (e.getSource() == comboBoxLoaiTraCuu) {
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Gioi Tinh")) {
				setVisibleFalseForAllChiTietTraCuu();
				rbuttonNamTraCuu.setVisible(true);
				rbuttonNuTraCuu.setVisible(true);
			}
			else if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Sinh")) {
				setVisibleFalseForAllChiTietTraCuu();
				NgaySinhTraCuu.setVisible(true);
			}
			else
			{
				setVisibleFalseForAllChiTietTraCuu();
				textfieldChiTietTraCuu.setVisible(true);
			}
		}
	}
	


public void setInformation() { 
		
		String query = "SELECT * FROM BACSI ORDER BY MABS ASC";

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma BS","Ho Ten","Gioi Tinh","Ngay Sinh","Que Quan","Noi O Hien Tai","Ten Khoa","Nam Phuc Vu"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			} 
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
}
	
	
	public void TraCuu() { 
		
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tat Ca")
				|| (!(textfieldChiTietTraCuu.getText().equals("")))
				|| (!(NgaySinhTraCuu.getDate() == null))
				|| (!(bgroupGioiTinhTraCuu.getSelection() == null))) {
			
			String query = "SELECT * FROM BACSI WHERE MABS = MABS";
			
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma BS")) {
				query += " AND MABS = '" + textfieldChiTietTraCuu.getText() + "'";
			}
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ho Ten")) {
				query += " AND HOTEN = '" + textfieldChiTietTraCuu.getText() + "'";
			}
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Que Quan")) {
				query += " AND QUEQUAN = '" + textfieldChiTietTraCuu.getText() + "'";
			}
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Noi O Hien Tai")) {
				query += " AND NOIOHIENTAI = '" + textfieldChiTietTraCuu.getText() + "'";
			}
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ten Khoa")) {
				query += " AND TENKHOA = '" + textfieldChiTietTraCuu.getText() + "'";
			}
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Nam Phuc Vu") 
					&& !(textfieldChiTietTraCuu.getText().equals(""))) {
				query += " AND NAMPHUCVU = " + textfieldChiTietTraCuu.getText();
			}
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Sinh")) {
				Date date = NgaySinhTraCuu.getDate();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String dateString = sdf.format(date);
				if (!(dateString.equals(""))) {
					query += " AND NGAYSINH = TO_DATE('" + dateString + "','YYYY-MM-DD')";
				}
			}
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Gioi Tinh") ) {
				query += " AND GIOITINH = '" + bgroupGioiTinhTraCuu.getSelection().getActionCommand() + "'";
			}
			
				query += " ORDER BY MABS ASC";
			
			System.out.println(query);


			try {
				Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
				Statement statement = connection.createStatement();
				ResultSet resultset = statement.executeQuery(query);
				ResultSetMetaData metadata = resultset.getMetaData();
				int columnCount = metadata.getColumnCount();
				DefaultTableModel data = (DefaultTableModel) table.getModel();
				
				data.setColumnIdentifiers(new String[] {"Ma BS","Ho Ten","Gioi Tinh","Ngay Sinh","Que Quan","Noi O Hien Tai","Ten Khoa","Nam Phuc Vu"});
				data.setRowCount(0);
				
				while(resultset.next()) {
					Vector row = new Vector();
					for (int i = 0; i < columnCount; i++)
						row.add(resultset.getString(i+1));
					data.addRow(row);
				
				}
				
				
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
		}
		 RefreshForTraCuu();
	}

		
	
	
	public void CapNhat() {
		
		String query = "UPDATE BACSI SET MABS = MABS";
			if (!(textfieldHoTen.getText().equals(""))) {
				query += ", HOTEN = '" + textfieldHoTen.getText() + "'";
			}
			else {
				query += ", HOTEN = NULL";
			}
			if (!(textfieldNoiOHienTai.getText().equals(""))) {
				query += ", NOIOHIENTAI = '" + textfieldNoiOHienTai.getText() + "'";
			}
			else {
				query += ", NOIOHIENTAI = NULL";
			}
			if (!(textfieldTenKhoa.getText().equals(""))) {
				query += ", TENKHOA = '" + textfieldTenKhoa.getText() + "'";
			}
			else {
				query += ", TENKHOA = NULL";
			}
			if (!(textfieldNamPhucVu.getText().equals(""))) {
				query += ", NAMPHUCVU = " + textfieldNamPhucVu.getText();
			}
			else {
				query += ", NAMPHUCVU = NULL";
			}
			if (!(textfieldQueQuan.getText().equals(""))) {
				query += ", QUEQUAN = '" + textfieldQueQuan.getText() + "'";
			}
			else {
				query += ", QUEQUAN = NULL";
			}
			if (bgroupGioiTinh.getSelection() != null) {
				query += ", GIOITINH = '" + bgroupGioiTinh.getSelection().getActionCommand() + "'";
			}
			else {
				query += ", GIOITINH = NULL";
			}
			if (NgaySinh.getDate() != null) {
				Date date = NgaySinh.getDate();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String dateString = sdf.format(date);
				query += ", NGAYSINH = TO_DATE('" + dateString + "','YYYY-MM-DD')";
			}
			else {
				query += ", NGAYSINH = NULL";
			}		
					
			if (!(textfieldMaBS.getText().equals(""))) {
				query += " WHERE MABS = MABS";
			}	
			else {
				query += " WHERE MABS = NULL";
			}
			if (!(textfieldMaBS.getText().equals(""))) {
				query += " AND MABS = '" + textfieldMaBS.getText() + "'";
			}
				
			System.out.println(query);
				

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			int changedrows = statement.executeUpdate(query);
			if (changedrows > 0) {
				JOptionPane.showMessageDialog(null, "Cap Nhat Thanh Cong", "Thong Bao", JOptionPane.INFORMATION_MESSAGE);
			}
			
			statement.close();
			connection.close();
			
			setInformation();
			
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		//Refresh();
	}
	
	public void QuayLai() {
		MyHome.getPanelContent().removeAll();
		switch (MyHome.getPreviousClass("BacSi","CapNhat")) {
		case "BacSi":
			MyHome.getPanelContent().add(new BacSi(MyHome).getpanelContent());
			break;
		case "TraCuu":
			MyHome.getPanelContent().add(new BacSi_TraCuu(MyHome).getpanelContent());
			break;
		}
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
	}
	
	public void Refresh() {
		textfieldMaBS.setText("");
		textfieldHoTen.setText("");
		textfieldQueQuan.setText("");
		textfieldNoiOHienTai.setText("");
		textfieldTenKhoa.setText("");
		textfieldNamPhucVu.setText("");
		bgroupGioiTinh.clearSelection();
		NgaySinh.setDate(null);
	}
	
	public void RefreshForTraCuu() {
		//comboBoxLoaiTraCuu.setSelectedIndex(0);
		bgroupGioiTinhTraCuu.clearSelection();
		NgaySinhTraCuu.setDate(null);
		textfieldChiTietTraCuu.setText("");
	}
	
	public void setVisibleFalseForAllChiTietTraCuu() {
		rbuttonNamTraCuu.setVisible(false);
		rbuttonNuTraCuu.setVisible(false);
		NgaySinhTraCuu.setVisible(false);
		textfieldChiTietTraCuu.setVisible(false);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
