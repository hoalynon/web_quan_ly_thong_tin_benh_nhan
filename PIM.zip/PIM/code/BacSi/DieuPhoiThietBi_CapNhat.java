package BacSi;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

public class DieuPhoiThietBi_CapNhat implements ActionListener{
	
	private BSHome MyHome;
	private JPanel panelContent;
	private JButton buttonTraCuu;
	private JButton buttonCapNhat;
	private JButton buttonQuayLai;
	
	private JTextField textfieldMaBN;
	private JTextField textfieldMaThietBi;
	private JTextField textfieldSoLuong;
	private JTextField textfieldSLDu;
	private JTextField textfieldChiTietTraCuu;
	
	private JDateChooser NgayDieuPhoi;
	private JDateChooser NgayKetThuc;
	private JDateChooser NgayDieuPhoiTraCuu;
	private JDateChooser NgayKetThucTraCuu;
	
	private JTable table;
	private JComboBox comboBoxLoaiTraCuu;
	
	private String listLoaiTraCuu[]  = {"Tat Ca","Ma BN","Ma Thiet Bi","So Luong","Ngay Dieu Phoi","Ngay Ket Thuc","SL Du"}; 
	
	DieuPhoiThietBi_CapNhat(BSHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (160,160));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.NORTH);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(null);
		panelContent.add(panel2, BorderLayout.SOUTH);

		JLabel labelMaBN = new JLabel("Ma BN : ");
		labelMaBN.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBN.setBounds(10, 10, 80, 20);
		labelMaBN.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBN);
		
		textfieldMaBN = new JTextField();
		textfieldMaBN.setBounds(90, 10, 80, 20);
		textfieldMaBN.setColumns(10);
		panel1.add(textfieldMaBN);
		
		JLabel labelMaThietBi = new JLabel("Ma Thiet Bi : ");
		labelMaThietBi.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaThietBi.setBounds(10, 40, 80, 20);
		labelMaThietBi.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaThietBi);
		
		textfieldMaThietBi = new JTextField();
		textfieldMaThietBi.setBounds(90, 40, 80, 20);
		textfieldMaThietBi.setColumns(10);
		panel1.add(textfieldMaThietBi);
		
		JLabel labelSoLuong = new JLabel("So Luong : ");
		labelSoLuong.setHorizontalAlignment(SwingConstants.RIGHT);
		labelSoLuong.setFont(new Font("Bevan", Font.BOLD, 12));
		labelSoLuong.setBounds(10, 70, 80, 20);
		panel1.add(labelSoLuong);
		
		textfieldSoLuong = new JTextField();
		textfieldSoLuong.setColumns(10);
		textfieldSoLuong.setBounds(90, 70, 80, 20);
		panel1.add(textfieldSoLuong);
		
		JLabel labelSLDu = new JLabel("SL Du : ");
		labelSLDu.setHorizontalAlignment(SwingConstants.RIGHT);
		labelSLDu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelSLDu.setBounds(10, 100, 80, 20);
		panel1.add(labelSLDu);
		
		textfieldSLDu = new JTextField();
		textfieldSLDu.setColumns(10);
		textfieldSLDu.setBounds(90, 100, 80, 20);
		panel1.add(textfieldSLDu);
		
		JLabel labelNgayDieuPhoi = new JLabel("Ngay Dieu Phoi: ");
		labelNgayDieuPhoi.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgayDieuPhoi.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgayDieuPhoi.setBounds(180, 40, 80, 20);
		panel1.add(labelNgayDieuPhoi);
		
		NgayDieuPhoi = new JDateChooser();
		NgayDieuPhoi.setBounds(260, 40, 80, 20);
		panel1.add(NgayDieuPhoi);
		
		JLabel labelNgayKetThuc = new JLabel("Ngay Ket Thuc: ");
		labelNgayKetThuc.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgayKetThuc.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgayKetThuc.setBounds(180, 70, 80, 20);
		panel1.add(labelNgayKetThuc);
		
		NgayKetThuc = new JDateChooser();
		NgayKetThuc.setBounds(260, 70, 80, 20);
		panel1.add(NgayKetThuc);
		
	
		//////////////////////////////////////////////////////////
		
		JLabel labelLoaiTraCuu = new JLabel("Loai Tra Cuu : ");
		labelLoaiTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelLoaiTraCuu.setBounds(10, 130, 80, 20);
		labelLoaiTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelLoaiTraCuu);
		
		comboBoxLoaiTraCuu = new JComboBox(listLoaiTraCuu);
		comboBoxLoaiTraCuu.setBounds(90, 130, 80, 20);
		comboBoxLoaiTraCuu.addActionListener(this);
		panel1.add(comboBoxLoaiTraCuu);
		
		JLabel labelChiTietTraCuu = new JLabel("Chi Tiet Tra Cuu : ");
		labelChiTietTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		labelChiTietTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelChiTietTraCuu.setBounds(210, 130, 120, 20);
		panel1.add(labelChiTietTraCuu);
		
		textfieldChiTietTraCuu = new JTextField();
		textfieldChiTietTraCuu.setColumns(10);
		textfieldChiTietTraCuu.setBounds(330, 130, 80, 20);
		panel1.add(textfieldChiTietTraCuu);
		
		NgayDieuPhoiTraCuu = new JDateChooser();
		NgayDieuPhoiTraCuu.setBounds(330, 130, 80, 20);
		NgayDieuPhoiTraCuu.setVisible(false);
		panel1.add(NgayDieuPhoiTraCuu);
		
		NgayKetThucTraCuu = new JDateChooser();
		NgayKetThucTraCuu.setBounds(330, 130, 80, 20);
		NgayKetThucTraCuu.setVisible(false);
		panel1.add(NgayKetThucTraCuu);
		

		buttonTraCuu = new JButton("Tra Cuu");
		buttonTraCuu.setForeground(Color.decode("#28526a"));
		buttonTraCuu.setBackground(Color.decode("#91B6C9"));
		buttonTraCuu.addActionListener(this);
		buttonTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonTraCuu.setBounds(500, 130, 85, 21);
		buttonTraCuu.setBorderPainted(false);
		panel1.add(buttonTraCuu);
		
		buttonCapNhat = new JButton("Cap Nhat");
		buttonCapNhat.setForeground(Color.decode("#28526a"));
		buttonCapNhat.setBackground(Color.decode("#91B6C9"));
		buttonCapNhat.addActionListener(this);
		buttonCapNhat.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonCapNhat.setBounds(80, 30, 85, 21);
		buttonCapNhat.setBorderPainted(false);
		panel2.add(buttonCapNhat);
		
		buttonQuayLai = new JButton("Quay Lai");
		buttonQuayLai.addActionListener(this);
		buttonQuayLai.setForeground(Color.decode("#28526a"));
		buttonQuayLai.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonQuayLai.setBackground(Color.decode("#91B6C9"));
		buttonQuayLai.setBounds(400, 30, 85, 21);
		buttonQuayLai.setBorderPainted(false);
		panel2.add(buttonQuayLai);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setPreferredSize(new Dimension (100, 100));
		panelContent.add(scrollPane,BorderLayout.CENTER);
		table = new JTable() {
			boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false
				};
			@Override
		    public boolean isCellEditable(int rowIndex, int columnIndex)
		    {
		        return columnEditables[columnIndex];
		    }	};
		table.setBackground(Color.decode("#d6e7ef"));
		table.setFont(new Font("Bevan", Font.PLAIN, 10));
		
		setInformation();
		scrollPane.setViewportView(table);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonTraCuu) {
			TraCuu();
		}
		else if (e.getSource() == buttonCapNhat) {
			CapNhat();
			setInformation();
		}
		else if (e.getSource() == buttonQuayLai) {
			QuayLai();
		}
		else if (e.getSource() == comboBoxLoaiTraCuu) {
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Dieu Phoi")) {
				setVisibleFalseForAllChiTietTraCuu();
				NgayDieuPhoiTraCuu.setVisible(true);
			}
			else if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Ket Thuc")) {
				setVisibleFalseForAllChiTietTraCuu();
				NgayKetThucTraCuu.setVisible(true);
			}
			else
			{
				setVisibleFalseForAllChiTietTraCuu();
				textfieldChiTietTraCuu.setVisible(true);
			}
		}
	}
	


public void setInformation() { 
		
		String query = "SELECT DP.* FROM DIEUPHOITHIETBI DP, CABENH CB WHERE CB.MABS = '" + MyHome.getID() + "' AND CB.MABN = DP.MABN ORDER BY DP.MABN, DP.MATHIETBI ASC";

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma BN","Ma Thiet Bi","So Luong","Ngay Dieu Phoi","Ngay Ket Thuc","SL Du"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			} 
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
}
	

public void TraCuu() { 
	
	if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tat Ca")
			|| (!(textfieldChiTietTraCuu.getText().equals("")))
			|| (!(NgayDieuPhoiTraCuu.getDate() == null))
			|| (!(NgayKetThucTraCuu.getDate() == null))){
		
		String query = "SELECT DP.* FROM DIEUPHOITHIETBI DP, CABENH CB WHERE CB.MABS = '" + MyHome.getID() + "' AND CB.MABN = DP.MABN";
		
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma BN")) {
			query += " AND DP.MABN = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma Thiet Bi")) {
			query += " AND DP.MATHIETBI = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("So Luong")) {
			query += " AND DP.SOLUONG = " + textfieldChiTietTraCuu.getText();
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("SL Du")) {
			query += " AND DP.SLDU = " + textfieldChiTietTraCuu.getText();
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Dieu Phoi")) {
			Date date = NgayDieuPhoiTraCuu.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String dateString = sdf.format(date);
			if (!(dateString.equals(""))) {
				query += " AND DP.NGAYDIEUPHOI = TO_DATE('" + dateString + "','YYYY-MM-DD')";
			}
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Ket Thuc")) {
			Date date = NgayKetThucTraCuu.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String dateString = sdf.format(date);
			if (!(dateString.equals(""))) {
				query += " AND DP.NGAYKETTHUC = TO_DATE('" + dateString + "','YYYY-MM-DD')";
			}
		}
		
			query += " ORDER BY DP.MABN, DP.MATHIETBI ASC";
			
		System.out.println(query);


			try {
				Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
				Statement statement = connection.createStatement();
				ResultSet resultset = statement.executeQuery(query);
				ResultSetMetaData metadata = resultset.getMetaData();
				int columnCount = metadata.getColumnCount();
				DefaultTableModel data = (DefaultTableModel) table.getModel();
				
				data.setColumnIdentifiers(new String[] {"Ma BN","Ma Thiet Bi","So Luong","Ngay Dieu Phoi","Ngay Ket Thuc","SL Du"});
				data.setRowCount(0);
				
				while(resultset.next()) {
					Vector row = new Vector();
					for (int i = 0; i < columnCount; i++)
						row.add(resultset.getString(i+1));
					data.addRow(row);
				
				}
				
				
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
		}
		 RefreshForTraCuu();
	}

		
	
	
	public void CapNhat() {
		
		String query = "UPDATE DIEUPHOITHIETBI DP SET DP.MABN = DP.MABN";
			if (!(textfieldSoLuong.getText().equals(""))) {
				query += ", DP.SOLUONG = " + textfieldSoLuong.getText();
			}
			else {
				query += ", DP.SOLUONG = NULL";
			}
			if (!(textfieldSLDu.getText().equals(""))) {
				query += ", DP.SLDU = " + textfieldSLDu.getText();
			}
			else {
				query += ", DP.SLDU = NULL";
			}
			if (NgayDieuPhoi.getDate() != null) {
				Date date = NgayDieuPhoi.getDate();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String dateString = sdf.format(date);
				query += ", DP.NGAYDIEUPHOI = TO_DATE('" + dateString + "','YYYY-MM-DD')";
			}
			else {
				query += ", DP.NGAYDIEUPHOI = NULL";
			}
			if (NgayKetThuc.getDate() != null) {
				Date date = NgayKetThuc.getDate();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String dateString = sdf.format(date);
				query += ", DP.NGAYKETTHUC = TO_DATE('" + dateString + "','YYYY-MM-DD')";
			}
			else {
				query += ", DP.NGAYKETTHUC = NULL";
			}		
			if (!(textfieldMaBN.getText().equals("")) || !(textfieldMaThietBi.getText().equals(""))) {
				query += " WHERE EXISTS (SELECT CB.* FROM CABENH CB WHERE CB.MABS = '" + MyHome.getID() + "' AND CB.MABN = DP.MABN)"; 
			}
			else {
				query += " WHERE DP.MABN = NULL"; 
			}
			if (!(textfieldMaBN.getText().equals(""))) {
				query += " AND DP.MABN = '" + textfieldMaBN.getText() + "'"; 
			}
			if (!(textfieldMaThietBi.getText().equals(""))) {
				query += " AND DP.MATHIETBI = '" + textfieldMaThietBi.getText() + "'"; 
			}
					
				System.out.println(query);
				

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			int changedrows = statement.executeUpdate(query);
			if (changedrows > 0) {
				JOptionPane.showMessageDialog(null, "Cap Nhat Thanh Cong", "Thong Bao", JOptionPane.INFORMATION_MESSAGE);
			}
			
			statement.close();
			connection.close();
			
			setInformation();
			
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		//Refresh();
	}
	
	public void QuayLai() {
		MyHome.getPanelContent().removeAll();
		switch (MyHome.getPreviousClass("DieuPhoiThietBi","CapNhat")) {
		case "DieuPhoiThietBi":
			MyHome.getPanelContent().add(new DieuPhoiThietBi(MyHome).getpanelContent());
			break;
		case "TraCuu":
			MyHome.getPanelContent().add(new DieuPhoiThietBi_TraCuu(MyHome).getpanelContent());
			break;
		}
		MyHome.getPanelContent().validate();
		MyHome.getPanelContent().repaint();
	}
	
	public void Refresh() {
		textfieldMaBN.setText("");
		textfieldMaThietBi.setText("");
		textfieldSoLuong.setText("");
		textfieldSLDu.setText("");
		NgayDieuPhoi.setDate(null);
		NgayKetThuc.setDate(null);
	}
	
	public void RefreshForTraCuu() {
		//comboBoxLoaiTraCuu.setSelectedIndex(0);
		NgayDieuPhoiTraCuu.setDate(null);
		NgayKetThucTraCuu.setDate(null);
		textfieldChiTietTraCuu.setText("");
	}
	
	public void setVisibleFalseForAllChiTietTraCuu() {
		NgayDieuPhoiTraCuu.setVisible(false);
		NgayKetThucTraCuu.setVisible(false);
		textfieldChiTietTraCuu.setVisible(false);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
