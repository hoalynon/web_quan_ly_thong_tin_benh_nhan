package BacSi;



import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import java.sql.*;
import java.util.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import com.toedter.calendar.JDateChooser;


public class BenhNhan implements ActionListener{
	
	private BSHome MyHome;
	private JPanel panelContent;
	private JButton buttonTraCuu;
	
	private JRadioButton rbuttonNamTraCuu;
	private JRadioButton rbuttonNuTraCuu;
	private ButtonGroup bgroupGioiTinhTraCuu;
	
	private JTextField textfieldChiTietTraCuu;
	
	private JDateChooser NgaySinhTraCuu;
	
	private JTable table;
	private JComboBox comboBoxLoaiTraCuu;
	
	private String listLoaiTraCuu[]  = {"Tat Ca","Ma BN","Ho Ten","Gioi Tinh","Ngay Sinh","Que Quan","Noi O Hien Tai"}; 
	
	BenhNhan(BSHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (80,80));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.NORTH);
		
		JLabel labelLoaiTraCuu = new JLabel("Loai Tra Cuu : ");
		labelLoaiTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelLoaiTraCuu.setBounds(10, 30, 100, 20);
		labelLoaiTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelLoaiTraCuu);
		
		comboBoxLoaiTraCuu = new JComboBox(listLoaiTraCuu);
		comboBoxLoaiTraCuu.setBounds(110, 30, 80, 20);
		comboBoxLoaiTraCuu.addActionListener(this);
		panel1.add(comboBoxLoaiTraCuu);
		
		JLabel labelChiTietTraCuu = new JLabel("Chi Tiet Tra Cuu : ");
		labelChiTietTraCuu.setHorizontalAlignment(SwingConstants.RIGHT);
		labelChiTietTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		labelChiTietTraCuu.setBounds(210, 30, 120, 20);
		panel1.add(labelChiTietTraCuu);
		
		textfieldChiTietTraCuu = new JTextField();
		textfieldChiTietTraCuu.setColumns(10);
		textfieldChiTietTraCuu.setBounds(330, 30, 80, 20);
		panel1.add(textfieldChiTietTraCuu);
		
		NgaySinhTraCuu = new JDateChooser();
		NgaySinhTraCuu.setBounds(330, 30, 80, 20);
		NgaySinhTraCuu.setVisible(false);
		panel1.add(NgaySinhTraCuu);
		
		rbuttonNamTraCuu = new JRadioButton("Nam");
		rbuttonNamTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonNamTraCuu.setBounds(330, 30, 50, 20);
		rbuttonNamTraCuu.setActionCommand("Nam");
		rbuttonNamTraCuu.setVisible(false);
		panel1.add(rbuttonNamTraCuu);
		
		rbuttonNuTraCuu = new JRadioButton("Nu");
		rbuttonNuTraCuu.setBackground(Color.decode("#d6e7ef"));
		rbuttonNuTraCuu.setBounds(380, 30, 50, 20);
		rbuttonNuTraCuu.setActionCommand("Nu");
		rbuttonNuTraCuu.setVisible(false);
		panel1.add(rbuttonNuTraCuu);
		
		bgroupGioiTinhTraCuu = new ButtonGroup();
		bgroupGioiTinhTraCuu.add(rbuttonNamTraCuu);
		bgroupGioiTinhTraCuu.add(rbuttonNuTraCuu);
		
		buttonTraCuu = new JButton("Tra Cuu");
		buttonTraCuu.setForeground(Color.decode("#28526a"));
		buttonTraCuu.setBackground(Color.decode("#91B6C9"));
		buttonTraCuu.addActionListener(this);
		buttonTraCuu.setFont(new Font("Bevan", Font.BOLD, 12));
		buttonTraCuu.setBounds(500, 30, 85, 21);
		buttonTraCuu.setBorderPainted(false);
		panel1.add(buttonTraCuu);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setPreferredSize(new Dimension (100, 100));
		panelContent.add(scrollPane,BorderLayout.CENTER);
		
		table = new JTable() {
			boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false
				};
			@Override
		    public boolean isCellEditable(int rowIndex, int columnIndex)
		    {
		        return columnEditables[columnIndex];
		    }	};
		table.setBackground(Color.decode("#d6e7ef"));
		table.setFont(new Font("Bevan", Font.PLAIN, 10));
		
		setInformation();
		scrollPane.setViewportView(table);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonTraCuu) {
			TraCuu();
		}
		else if (e.getSource() == comboBoxLoaiTraCuu) {
			if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Gioi Tinh")) {
				setVisibleFalseForAllChiTietTraCuu();
				rbuttonNamTraCuu.setVisible(true);
				rbuttonNuTraCuu.setVisible(true);
			}
			else if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Sinh")) {
				setVisibleFalseForAllChiTietTraCuu();
				NgaySinhTraCuu.setVisible(true);
			}
			else
			{
				setVisibleFalseForAllChiTietTraCuu();
				textfieldChiTietTraCuu.setVisible(true);
			}
		}
	}
	

public void setInformation() { 
		
		String query = "SELECT * FROM BENHNHAN ORDER BY MABN ASC";

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma BN","Ho Ten","Gioi Tinh","Ngay Sinh","Que Quan","Noi O Hien Tai"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			} 
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
}
	

public void TraCuu() { 
	
	if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Tat Ca")
			|| (!(textfieldChiTietTraCuu.getText().equals("")))
			|| (!(NgaySinhTraCuu.getDate() == null))
			|| (!(bgroupGioiTinhTraCuu.getSelection() == null))) {
		
		String query = "SELECT * FROM BENHNHAN WHERE MABN = MABN";
		
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ma BN")) {
			query += " AND MABN = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ho Ten")) {
			query += " AND HOTEN = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Que Quan")) {
			query += " AND QUEQUAN = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Noi O Hien Tai")) {
			query += " AND NOIOHIENTAI = '" + textfieldChiTietTraCuu.getText() + "'";
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Ngay Sinh")) {
			Date date = NgaySinhTraCuu.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String dateString = sdf.format(date);
			if (!(dateString.equals(""))) {
				query += " AND NGAYSINH = TO_DATE('" + dateString + "','YYYY-MM-DD')";
			}
		}
		if (comboBoxLoaiTraCuu.getItemAt(comboBoxLoaiTraCuu.getSelectedIndex()).equals("Gioi Tinh") ) {
			query += " AND GIOITINH = '" + bgroupGioiTinhTraCuu.getSelection().getActionCommand() + "'";
		}
		
			query += " ORDER BY MABN ASC";
		System.out.println(query);


		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			ResultSet resultset = statement.executeQuery(query);
			ResultSetMetaData metadata = resultset.getMetaData();
			int columnCount = metadata.getColumnCount();
			DefaultTableModel data = (DefaultTableModel) table.getModel();
			
			data.setColumnIdentifiers(new String[] {"Ma BN","Ho Ten","Gioi Tinh","Ngay Sinh","Que Quan","Noi O Hien Tai"});
			data.setRowCount(0);
			
			while(resultset.next()) {
				Vector row = new Vector();
				for (int i = 0; i < columnCount; i++)
					row.add(resultset.getString(i+1));
				data.addRow(row);
			
			}
			
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
	 RefreshForTraCuu();
}

	public void RefreshForTraCuu() {
		//comboBoxLoaiTraCuu.setSelectedIndex(0);
		bgroupGioiTinhTraCuu.clearSelection();
		NgaySinhTraCuu.setDate(null);
		textfieldChiTietTraCuu.setText("");
	}
	
	public void setVisibleFalseForAllChiTietTraCuu() {
		rbuttonNamTraCuu.setVisible(false);
		rbuttonNuTraCuu.setVisible(false);
		NgaySinhTraCuu.setVisible(false);
		textfieldChiTietTraCuu.setVisible(false);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
