package QuanLy;



import java.awt.*;
import javax.swing.*;

import oracle.jdbc.OracleTypes;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.sql.*;

public class Benh_Them implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonThem;
	
	private JTextField textfieldMaBenh;
	private JTextField textfieldTenBenh;
	private JTextField textfieldTenKhoa;

	private int maxRow;
	
	Benh_Them(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel0 = new JPanel();
		panel0.setBackground(Color.decode("#d6e7ef"));
		panel0.setPreferredSize(new Dimension (160,60));
		panel0.setLayout(new BorderLayout());
		panelContent.add(panel0,BorderLayout.NORTH);
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (100,260));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.CENTER);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(new FlowLayout(FlowLayout.TRAILING,50,20));
		panelContent.add(panel2, BorderLayout.SOUTH);
		
		JLabel labelHeading = new JLabel("THEM MOI BENH");
        labelHeading.setFont(new Font("Bevan", Font.BOLD, 16));
        labelHeading.setForeground(new Color(40, 82, 106));
        labelHeading.setHorizontalAlignment(SwingConstants.CENTER);
        panel0.add(labelHeading, BorderLayout.CENTER);
		
		JLabel labelMaBenh = new JLabel("Ma Benh : ");
		labelMaBenh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBenh.setBounds(30, 30, 115, 20);
		labelMaBenh.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBenh);
		
		textfieldMaBenh = new JTextField();
		textfieldMaBenh.setBounds(150, 30, 115, 20);
		textfieldMaBenh.setColumns(10);
		panel1.add(textfieldMaBenh);
		maxRow = getMaxRow();
		textfieldMaBenh.setText("BE0" + Integer.toString(maxRow));
        textfieldMaBenh.setBackground(new Color (210, 210, 210));
        textfieldMaBenh.setEditable(false);
		
		JLabel labelTenBenh = new JLabel("Ten Benh : ");
		labelTenBenh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTenBenh.setBounds(30, 70, 115, 20);
		labelTenBenh.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelTenBenh);
		
		textfieldTenBenh = new JTextField();
		textfieldTenBenh.setBounds(150, 70, 115, 20);
		textfieldTenBenh.setColumns(10);
		panel1.add(textfieldTenBenh);

		JLabel labelTenKhoa = new JLabel("Ten Khoa : ");
		labelTenKhoa.setHorizontalAlignment(SwingConstants.RIGHT);
		labelTenKhoa.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTenKhoa.setBounds(30, 110, 115, 20);
		panel1.add(labelTenKhoa);
		
		textfieldTenKhoa = new JTextField();
		textfieldTenKhoa.setColumns(10);
		textfieldTenKhoa.setBounds(150, 110, 115, 20);
		panel1.add(textfieldTenKhoa);
		
		buttonThem = new JButton("    Them    ");
		buttonThem.setForeground(Color.decode("#28526a"));
		buttonThem.setBackground(Color.decode("#91B6C9"));
		buttonThem.addActionListener(this);
		buttonThem.setFont(new Font("Bevan", Font.BOLD, 12));
		//buttonThem.setBounds(80, 30, 85, 21);
		buttonThem.setBorderPainted(false);
		panel2.add(buttonThem);
		

	}
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == buttonThem) {
			Them();
		}
	}
	
	public void Them() {

		try {
			Connection connection = MyHome.getDatabase().getConnection();
			CallableStatement statement = connection.prepareCall("{ call proc_benh_them1benh (?,?,?,?) }");
			statement.setString(1,textfieldMaBenh.getText());
			statement.setString(2,textfieldTenBenh.getText());
			statement.setString(3,textfieldTenKhoa.getText());
			statement.registerOutParameter(4,Types.INTEGER);
			
			statement.execute();
			
			int changedrows = (int) statement.getObject(4);
			if (changedrows > 0) {
				JOptionPane.showMessageDialog(null, "Them Moi Thanh Cong", "Thong Bao", JOptionPane.INFORMATION_MESSAGE);
				textfieldMaBenh.setText("BE0" + Integer.toString(++maxRow));
			}
			
			statement.close();
			
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		//Refresh();
	}
	
	public int getMaxRow(){
        int maxRow = -1, compareNum;

		try {
			Connection connection = MyHome.getDatabase().getConnection();
			CallableStatement statement = connection.prepareCall("{ call proc_benh_laybenh (?) }");
			statement.registerOutParameter(1, OracleTypes.CURSOR);
			statement.execute();
			ResultSet resultset = (ResultSet) statement.getObject(1);
			while(resultset.next()) {
	                        compareNum = Integer.parseInt(resultset.getString("MABENH").substring(2));
	                        if(compareNum > maxRow){
	                            maxRow = compareNum;
	                        }
			} 
			statement.close();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
        return (maxRow + 1);
    }
	
	public void Refresh() {
		textfieldMaBenh.setText("");
		textfieldTenBenh.setText("");
		textfieldTenKhoa.setText("");
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
