package QuanLy;



import java.awt.*;
import javax.swing.*;
import javax.swing.JSpinner.DefaultEditor;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.DateFormatter;

import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JTextFieldDateEditor;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

public class CaBenh_CapNhat implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;

	private JButton buttonCapNhat;
	
	private JRadioButton rbuttonTaiGia;
	private JRadioButton rbuttonNhapVien;
	private JRadioButton rbuttonCachLy;
	private ButtonGroup bgroupHinhThuc;
	
	private JTextField textfieldMaCa;
	private JTextField textfieldMaBN;
	private JTextField textfieldMaBS;
	private JTextField textfieldMaBenh;
	private JTextField textfieldMaPhong;
	
	private JDateChooser NgayBatDau;
	private JDateChooser NgayKetThuc;
	
	private JSpinner spinnerNgayBatDau;
	private JSpinner spinnerNgayKetThuc;
	
	private JTable table;
	private JComboBox comboBoxMucDo;
	private JComboBox comboBoxTinhTrang;
	
	private String listMucDo[]  = {"Khong cap cuu","Hoi Suc","Nang","Cham soc dac biet","Cap cuu"}; 
	private String listTinhTrang[]  = {"Trieu chung","Chuan doan","Dieu tri","Giam sat","Cham soc","Da ket thuc"}; 
	
	CaBenh_CapNhat(QLHome MyHome, JTable table){
		
		this.MyHome = MyHome;
		this.table = table;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel0 = new JPanel();
		panel0.setBackground(Color.decode("#d6e7ef"));
		panel0.setPreferredSize(new Dimension (160,60));
		panel0.setLayout(new BorderLayout());
		panelContent.add(panel0,BorderLayout.NORTH);
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (160,260));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.CENTER);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(new FlowLayout(FlowLayout.TRAILING,50,20));
		panelContent.add(panel2, BorderLayout.SOUTH);

		JLabel labelHeading = new JLabel("CAP NHAT CA BENH");
        labelHeading.setFont(new Font("Bevan", Font.BOLD, 16));
        labelHeading.setForeground(new Color(40, 82, 106));
        labelHeading.setHorizontalAlignment(SwingConstants.CENTER);
        panel0.add(labelHeading, BorderLayout.CENTER);
        
        JLabel labelMaCa = new JLabel("Ma Ca : ");
		labelMaCa.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaCa.setBounds(30, 0, 115, 20);
		labelMaCa.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaCa);
		
		textfieldMaCa = new JTextField();
		textfieldMaCa.setBounds(150, 0, 115, 20);
		textfieldMaCa.setColumns(10);
		panel1.add(textfieldMaCa);
		
        JLabel labelMaBN = new JLabel("Ma BN : ");
		labelMaBN.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBN.setBounds(30, 40, 115, 20);
		labelMaBN.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBN);
		
		textfieldMaBN = new JTextField();
		textfieldMaBN.setBounds(150, 40, 115, 20);
		textfieldMaBN.setColumns(10);
		panel1.add(textfieldMaBN);
		
		JLabel labelMaBS = new JLabel("Ma BS : ");
		labelMaBS.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBS.setBounds(30, 80, 115, 20);
		labelMaBS.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBS);
		
		textfieldMaBS = new JTextField();
		textfieldMaBS.setBounds(150, 80, 115, 20);
		textfieldMaBS.setColumns(10);
		panel1.add(textfieldMaBS);
		
		JLabel labelMaBenh = new JLabel("Ma Benh : ");
		labelMaBenh.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMaBenh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBenh.setBounds(30, 120, 115, 20);
		panel1.add(labelMaBenh);
		
		textfieldMaBenh = new JTextField();
		textfieldMaBenh.setColumns(10);
		textfieldMaBenh.setBounds(150, 120, 115, 20);
		panel1.add(textfieldMaBenh);
		
		JLabel labelMaPhong = new JLabel("Ma Phong : ");
		labelMaPhong.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMaPhong.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaPhong.setBounds(30, 160, 115, 20);
		panel1.add(labelMaPhong);
		
		textfieldMaPhong = new JTextField();
		textfieldMaPhong.setColumns(10);
		textfieldMaPhong.setBounds(150, 160, 115, 20);
		panel1.add(textfieldMaPhong);
		
		JLabel labelHinhThuc = new JLabel("Hinh Thuc : ");
		labelHinhThuc.setHorizontalAlignment(SwingConstants.RIGHT);
		labelHinhThuc.setFont(new Font("Bevan", Font.BOLD, 12));
		labelHinhThuc.setBounds(30, 200, 115, 20);
		panel1.add(labelHinhThuc);

		rbuttonTaiGia = new JRadioButton("Tai Gia");
		rbuttonTaiGia.setBackground(Color.decode("#d6e7ef"));
		rbuttonTaiGia.setBounds(150, 200, 70, 20);
		rbuttonTaiGia.setActionCommand("Tai gia");
		panel1.add(rbuttonTaiGia);
		
		rbuttonNhapVien = new JRadioButton("Nhap Vien");
		rbuttonNhapVien.setBackground(Color.decode("#d6e7ef"));
		rbuttonNhapVien.setBounds(220, 200, 90, 20);
		rbuttonNhapVien.setActionCommand("Nhap Vien");
		panel1.add(rbuttonNhapVien);
		
		rbuttonCachLy = new JRadioButton("Cach Ly");
		rbuttonCachLy.setBackground(Color.decode("#d6e7ef"));
		rbuttonCachLy.setBounds(310, 200, 70, 20);
		rbuttonCachLy.setActionCommand("Cach ly");
		panel1.add(rbuttonCachLy);
		
		bgroupHinhThuc = new ButtonGroup();
		bgroupHinhThuc.add(rbuttonTaiGia);
		bgroupHinhThuc.add(rbuttonNhapVien);
		bgroupHinhThuc.add(rbuttonCachLy);

		JLabel labelMucDo = new JLabel("Muc Do : ");
		labelMucDo.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMucDo.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMucDo.setBounds(300, 40, 115, 20);
		panel1.add(labelMucDo);
		
		comboBoxMucDo = new JComboBox(listMucDo);
		comboBoxMucDo.setBounds(420, 40, 115, 20);
		panel1.add(comboBoxMucDo);
		
		JLabel labelTinhTrang = new JLabel("Tinh Trang : ");
		labelTinhTrang.setHorizontalAlignment(SwingConstants.RIGHT);
		labelTinhTrang.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTinhTrang.setBounds(300, 80, 115, 20);
		panel1.add(labelTinhTrang);
		
		comboBoxTinhTrang = new JComboBox(listTinhTrang);
		comboBoxTinhTrang.setBounds(420, 80, 115, 20);
		panel1.add(comboBoxTinhTrang);
		
		JLabel labelNgayBatDau = new JLabel("Bat Dau: ");
		labelNgayBatDau.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgayBatDau.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgayBatDau.setBounds(300, 120, 115, 20);
		panel1.add(labelNgayBatDau);
		
		NgayBatDau = new JDateChooser();
		NgayBatDau.setBounds(420, 120, 115, 20);
		NgayBatDau.setFont(new Font("Bevan", Font.PLAIN, 12));
		NgayBatDau.setDateFormatString("dd/MM/yyyy");
		NgayBatDau.setDate(Calendar.getInstance().getTime());
		panel1.add(NgayBatDau);
		
		SpinnerDateModel modelNgayBatDau = new SpinnerDateModel();
        modelNgayBatDau.setValue(Calendar.getInstance().getTime());
        spinnerNgayBatDau = new JSpinner(modelNgayBatDau);
        JSpinner.DateEditor editorNgayBatDau = new JSpinner.DateEditor(spinnerNgayBatDau, "HH:mm:ss");
        spinnerNgayBatDau.setEditor(editorNgayBatDau);
        spinnerNgayBatDau.setBounds(540, 120, 80, 20);
        panel1.add(spinnerNgayBatDau);
        DateFormatter formatterNgayBatDau = (DateFormatter)editorNgayBatDau.getTextField().getFormatter();
        formatterNgayBatDau.setAllowsInvalid(false);
        formatterNgayBatDau.setOverwriteMode(true);
		
		JLabel labelNgayKetThuc = new JLabel("Ket Thuc: ");
		labelNgayKetThuc.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgayKetThuc.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgayKetThuc.setBounds(300, 160, 115, 20);
		panel1.add(labelNgayKetThuc);
		
		NgayKetThuc = new JDateChooser();
		NgayKetThuc.setBounds(420, 160, 115, 20);
		NgayKetThuc.setFont(new Font("Bevan", Font.PLAIN, 12));
		NgayKetThuc.setDateFormatString("dd/MM/yyyy");
		NgayKetThuc.setDate(Calendar.getInstance().getTime());
		panel1.add(NgayKetThuc);
		
		SpinnerDateModel modelNgayKetThuc = new SpinnerDateModel();
        modelNgayKetThuc.setValue(Calendar.getInstance().getTime());
        spinnerNgayKetThuc = new JSpinner(modelNgayKetThuc);
        JSpinner.DateEditor editorNgayKetThuc = new JSpinner.DateEditor(spinnerNgayKetThuc, "HH:mm:ss");
        spinnerNgayKetThuc.setEditor(editorNgayKetThuc);
        spinnerNgayKetThuc.setBounds(540, 160, 80, 20);
        panel1.add(spinnerNgayKetThuc);
        DateFormatter formatterNgayKetThuc = (DateFormatter)editorNgayKetThuc.getTextField().getFormatter();
        formatterNgayKetThuc.setAllowsInvalid(false);
        formatterNgayKetThuc.setOverwriteMode(true);
		
		buttonCapNhat = new JButton("  Cap Nhat  ");
		buttonCapNhat.setForeground(Color.decode("#28526a"));
		buttonCapNhat.setBackground(Color.decode("#91B6C9"));
		buttonCapNhat.addActionListener(this);
		buttonCapNhat.setFont(new Font("Bevan", Font.BOLD, 12));
		//buttonCapNhat.setBounds(80, 30, 85, 21);
		buttonCapNhat.setBorderPainted(false);
		panel2.add(buttonCapNhat);
		
		if (table != null && table.getSelectedRowCount() == 1) {
			setInformation(table.getSelectedRow());
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttonCapNhat) {
			CapNhat();
		}
	}
	
	
	public void setInformation(int SelectedRow) {
    
	    int [] mapping = getMapping();
	    
	    textfieldMaCa.setText((String)table.getValueAt(SelectedRow,mapping[0]));
		textfieldMaBN.setText((String)table.getValueAt(SelectedRow,mapping[1]));
		textfieldMaBS.setText((String)table.getValueAt(SelectedRow,mapping[2]));
		textfieldMaBenh.setText((String)table.getValueAt(SelectedRow,mapping[3]));
		textfieldMaPhong.setText((String)table.getValueAt(SelectedRow,mapping[9]));
		
		for (int i = 0; i < listMucDo.length; i++) {
			if (table.getValueAt(SelectedRow, mapping[4]) != null && ((String)table.getValueAt(SelectedRow, mapping[4])).equals(listMucDo[i])){
				comboBoxMucDo.setSelectedIndex(i);
				break;
			}
		}
		for (int i = 0; i < listTinhTrang.length; i++) {
			if (table.getValueAt(SelectedRow, mapping[8]) != null && ((String)table.getValueAt(SelectedRow, mapping[8])).equals(listTinhTrang[i])){
				comboBoxTinhTrang.setSelectedIndex(i);
				break;
			}
		}
		if ((String)table.getValueAt(SelectedRow,mapping[5]) != null) {
			switch ((String)table.getValueAt(SelectedRow,mapping[5])) {
			case "Tai gia":
				rbuttonTaiGia.setSelected(true);
				break;
			case "Nhap vien":
				rbuttonNhapVien.setSelected(true);
				break;
			case "Cach ly":
				rbuttonCachLy.setSelected(true);
				break;
			}
		}
		else {
			bgroupHinhThuc.clearSelection();
		}
		if (table.getValueAt(SelectedRow, mapping[6]) != null) {
			try {
				NgayBatDau.setDate(new SimpleDateFormat("dd/MM/yyyy").parse((String)table.getValueAt(SelectedRow, mapping[6])));
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			SpinnerDateModel modelNgayBatDau = new SpinnerDateModel();
            try {
            	modelNgayBatDau.setValue(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse((String)table.getValueAt(SelectedRow, mapping[6])));
            } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
            }
	            spinnerNgayBatDau.setModel(modelNgayBatDau);
	            JSpinner.DateEditor editorNgayBatDau = new JSpinner.DateEditor(spinnerNgayBatDau, "HH:mm:ss");
	            spinnerNgayBatDau.setEditor(editorNgayBatDau);
	            DateFormatter formatterNgayBatDau = (DateFormatter)editorNgayBatDau.getTextField().getFormatter();
	            formatterNgayBatDau.setAllowsInvalid(false);
	            formatterNgayBatDau.setOverwriteMode(true);
			}
		if (table.getValueAt(SelectedRow, mapping[7]) != null) {
			try {
				NgayKetThuc.setDate(new SimpleDateFormat("dd/MM/yyyy").parse((String)table.getValueAt(SelectedRow, mapping[7])));
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			SpinnerDateModel modelNgayKetThuc = new SpinnerDateModel();
			try {
				modelNgayKetThuc.setValue(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse((String)table.getValueAt(SelectedRow, mapping[7])));
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			spinnerNgayKetThuc.setModel(modelNgayKetThuc);
            JSpinner.DateEditor editorNgayKetThuc = new JSpinner.DateEditor(spinnerNgayKetThuc, "HH:mm:ss");
            spinnerNgayKetThuc.setEditor(editorNgayKetThuc);
            DateFormatter formatterNgayKetThuc = (DateFormatter)editorNgayKetThuc.getTextField().getFormatter();
            formatterNgayKetThuc.setAllowsInvalid(false);
            formatterNgayKetThuc.setOverwriteMode(true);
		}
		 	textfieldMaCa.setBackground(new Color(210, 210, 210));
		    textfieldMaCa.setEditable(false);
		    textfieldMaBN.setBackground(new Color(210, 210, 210));
		    textfieldMaBN.setEditable(false);
		    textfieldMaBS.setBackground(new Color(210, 210, 210));
		    textfieldMaBS.setEditable(false);
		    textfieldMaBenh.setBackground(new Color(210, 210, 210));
		    textfieldMaBenh.setEditable(false);
		    NgayBatDau.setBackground(new Color(210, 210, 210));
	        ((JTextFieldDateEditor) NgayBatDau.getDateEditor()).setEditable(false);
	        NgayBatDau.getCalendarButton().setEnabled(false);
	        spinnerNgayBatDau.getComponent(0).setEnabled(false);
	        spinnerNgayBatDau.getComponent(1).setEnabled(false);
	        ((DefaultEditor) spinnerNgayBatDau.getEditor()).getTextField().setEditable(false);
	        

	}

	
	
	public void CapNhat() {
		
		String query = "UPDATE CABENH SET MABN = MABN";
			if (!(textfieldMaPhong.getText().equals(""))) {
				query += ", MAPHONG = '" + textfieldMaPhong.getText() + "'";
			}
			else {
				query += ", MAPHONG = NULL";
			}
			if (bgroupHinhThuc.getSelection() != null) {
				query += ", HINHTHUC = '" + bgroupHinhThuc.getSelection().getActionCommand() + "'";
			}
			else {
				query += ", HINHTHUC = NULL";
			}	
			if (NgayKetThuc.getDate() != null) {
				Date date = NgayKetThuc.getDate();
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				String dateString = sdf.format(date);
				
				date = (Date)spinnerNgayKetThuc.getValue();
                sdf = new SimpleDateFormat("HH:mm:ss");
                String stringSpinnerNgayKetThuc = sdf.format(date);
                
				query += ", NGAYKETTHUC = TO_TIMESTAMP('" + dateString + " " + stringSpinnerNgayKetThuc+ "','DD/MM/YYYY HH24:MI:SS')";
			}
			else {
				query += ", NGAYKETTHUC = NULL";
			}		
			if (!(comboBoxMucDo.getItemAt(comboBoxMucDo.getSelectedIndex()).equals(""))) {
				query += ", MUCDO = '" + comboBoxMucDo.getItemAt(comboBoxMucDo.getSelectedIndex()) + "'";
			}
			else {
				query += ", MUCDO = NULL";
			}
			if (!(comboBoxTinhTrang.getItemAt(comboBoxTinhTrang.getSelectedIndex()).equals(""))) {
				query += ", TINHTRANG = '" + comboBoxTinhTrang.getItemAt(comboBoxTinhTrang.getSelectedIndex()) + "'";
			}
			else {
				query += ", TINHTRANG = NULL";
			}
				
			if (!(textfieldMaBN.getText().equals("")) || !(textfieldMaBS.getText().equals("")) || !(textfieldMaBenh.getText().equals("")) || NgayBatDau.getDate() != null) {
				query += " WHERE MACA = MACA";
			}
			else {
				query += " WHERE MACA = NULL";
			}
			if (!(textfieldMaBN.getText().equals(""))) {
				query += " AND MACA = '" + textfieldMaCa.getText() + "'";
			}
			/*if (!(textfieldMaBN.getText().equals(""))) {
				query += " AND MABN = '" + textfieldMaBN.getText() + "'";
			}
			if (!(textfieldMaBS.getText().equals(""))) {
				query += " AND MABS = '" + textfieldMaBS.getText() + "'";
			}
			if (!(textfieldMaBenh.getText().equals(""))) {
				query += " AND MABENH = '" + textfieldMaBenh.getText() + "'";
			}		
			if (NgayBatDau.getDate() != null) {
				Date date = NgayBatDau.getDate();
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				String dateString = sdf.format(date);
				
				date = (Date)spinnerNgayBatDau.getValue();
                sdf = new SimpleDateFormat("HH:mm:ss");
                String stringSpinnerNgayBatDau = sdf.format(date);
                
				query += " AND NGAYBATDAU = TO_TIMESTAMP('" + dateString + " " + stringSpinnerNgayBatDau + "','DD/MM/YYYY HH24:MI:SS')";
			}	*/
				
				System.out.println(query);
				

		try {
			Connection connection = DriverManager.getConnection(MyHome.getDatabaseURL(), MyHome.getDatabaseUsername(), MyHome.getDatabasePassword());
			Statement statement = connection.createStatement();
			int changedrows = statement.executeUpdate(query);
			if (changedrows > 0) {
				JOptionPane.showMessageDialog(null, "Cap Nhat Thanh Cong", "Thong Bao", JOptionPane.INFORMATION_MESSAGE);
			}
			
			statement.close();
			connection.close();
			
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		//Refresh();
	}
	
	public void Refresh() {
		textfieldMaCa.setText("");
		textfieldMaBN.setText("");
		textfieldMaBS.setText("");
		textfieldMaBenh.setText("");
		textfieldMaPhong.setText("");
		bgroupHinhThuc.clearSelection();
		NgayBatDau.setDate(Calendar.getInstance().getTime());
		NgayKetThuc.setDate(Calendar.getInstance().getTime());
		comboBoxMucDo.setSelectedIndex(0);
		comboBoxTinhTrang.setSelectedIndex(0);
		
		SpinnerDateModel modelNgayBatDau = new SpinnerDateModel();
        modelNgayBatDau.setValue(Calendar.getInstance().getTime());
        spinnerNgayBatDau.setModel(modelNgayBatDau);
        JSpinner.DateEditor editorNgayBatDau = new JSpinner.DateEditor(spinnerNgayBatDau, "HH:mm:ss");
        spinnerNgayBatDau.setEditor(editorNgayBatDau);
        DateFormatter formatterNgayBatDau = (DateFormatter)editorNgayBatDau.getTextField().getFormatter();
        formatterNgayBatDau.setAllowsInvalid(false);
        formatterNgayBatDau.setOverwriteMode(true);
        
        SpinnerDateModel modelNgayKetThuc = new SpinnerDateModel();
        modelNgayKetThuc.setValue(Calendar.getInstance().getTime());
        spinnerNgayKetThuc.setModel(modelNgayKetThuc);
        JSpinner.DateEditor editorNgayKetThuc = new JSpinner.DateEditor(spinnerNgayKetThuc, "HH:mm:ss");
        spinnerNgayKetThuc.setEditor(editorNgayKetThuc);
        DateFormatter formatterNgayKetThuc = (DateFormatter)editorNgayKetThuc.getTextField().getFormatter();
        formatterNgayKetThuc.setAllowsInvalid(false);
        formatterNgayKetThuc.setOverwriteMode(true);
	}
	
	public int[] getMapping(){
        int[] mapping = new int[table.getColumnCount()];
        for (int i = 0; i < table.getColumnCount(); i++){
            switch(table.getColumnName(i)){
	            case "Ma Ca":
	                mapping[0] = i;
	                break;
                case "Ma BN":
                    mapping[1] = i;
                    break;
                case "Ma BS":
                    mapping[2] = i;
                    break;
                case "Ma Benh":
                    mapping[3] = i;
                    break;
                case "Muc Do":
                    mapping[4] = i;
                    break;
                case "Hinh Thuc":
                    mapping[5] = i;
                    break;
                case "Bat Dau":
                    mapping[6] = i;
                    break;
                case "Ket Thuc":
                    mapping[7] = i;
                    break;
                case "Tinh Trang":
                    mapping[8] = i;
                    break;
                case "Ma Phong":
                    mapping[9] = i;
                    break;
            }
        }
	return mapping;
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
