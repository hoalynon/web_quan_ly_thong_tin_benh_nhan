package QuanLy;



import java.awt.*;
import javax.swing.*;
import javax.swing.text.DateFormatter;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import com.toedter.calendar.JDateChooser;

import oracle.jdbc.OracleTypes;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CaBenh_Them implements ActionListener{
	
	private QLHome MyHome;
	private JPanel panelContent;
	private JButton buttonThem;

	private JRadioButton rbuttonTaiGia;
	private JRadioButton rbuttonNhapVien;
	private JRadioButton rbuttonCachLy;
	private ButtonGroup bgroupHinhThuc;
	
	private JTextField textfieldMaCa;
	private JTextField textfieldMaBN;
	private JTextField textfieldMaBS;
	private JTextField textfieldMaBenh;
	private JTextField textfieldMaPhong;
	
	private JDateChooser NgayBatDau;
	private JDateChooser NgayKetThuc;
	
	private JSpinner spinnerNgayBatDau;
	private JSpinner spinnerNgayKetThuc;
	
	private JComboBox comboBoxMucDo;
	private JComboBox comboBoxTinhTrang;
	
	private String listMucDo[]  = {"Khong cap cuu","Hoi suc","Nang","Cham soc dac biet","Cap cuu"}; 
	private String listTinhTrang[]  = {"Trieu chung","Chuan doan","Dieu tri","Giam sat","Cham soc"}; 

	private int maxRow;

	CaBenh_Them(QLHome MyHome){
		
		this.MyHome = MyHome;
		
		panelContent = new JPanel();
		panelContent.setBackground(Color.decode("#d6e7ef"));
		panelContent.setLayout(new BorderLayout());
		
		JPanel panel0 = new JPanel();
		panel0.setBackground(Color.decode("#d6e7ef"));
		panel0.setPreferredSize(new Dimension (160,60));
		panel0.setLayout(new BorderLayout());
		panelContent.add(panel0,BorderLayout.NORTH);
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.decode("#d6e7ef"));
		panel1.setPreferredSize(new Dimension (100,260));
		panel1.setLayout(null);
		panelContent.add(panel1,BorderLayout.CENTER);
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.decode("#d6e7ef"));
		panel2.setPreferredSize(new Dimension (80,80));
		panel2.setLayout(new FlowLayout(FlowLayout.TRAILING,50,20));
		panelContent.add(panel2, BorderLayout.SOUTH);
		
		JLabel labelHeading = new JLabel("THEM MOI CA BENH");
        labelHeading.setFont(new Font("Bevan", Font.BOLD, 16));
        labelHeading.setForeground(new Color(40, 82, 106));
        labelHeading.setHorizontalAlignment(SwingConstants.CENTER);
        panel0.add(labelHeading, BorderLayout.CENTER);
		
        JLabel labelMaCa = new JLabel("Ma Ca : ");
		labelMaCa.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaCa.setBounds(30, 0, 115, 20);
		labelMaCa.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaCa);
		
		textfieldMaCa = new JTextField();
		textfieldMaCa.setBounds(150, 0, 115, 20);
		textfieldMaCa.setColumns(10);
		panel1.add(textfieldMaCa);
		maxRow = getMaxRow();
		textfieldMaCa.setText("CA0" + Integer.toString(maxRow));
        textfieldMaCa.setBackground(new Color (210, 210, 210));
        textfieldMaCa.setEditable(false);
        
		JLabel labelMaBN = new JLabel("Ma BN : ");
		labelMaBN.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBN.setBounds(30, 40, 115, 20);
		labelMaBN.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBN);
		
		textfieldMaBN = new JTextField();
		textfieldMaBN.setBounds(150, 40, 115, 20);
		textfieldMaBN.setColumns(10);
		panel1.add(textfieldMaBN);
		
		JLabel labelMaBS = new JLabel("Ma BS : ");
		labelMaBS.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBS.setBounds(30, 80, 115, 20);
		labelMaBS.setHorizontalAlignment(SwingConstants.RIGHT);
		panel1.add(labelMaBS);
		
		textfieldMaBS = new JTextField();
		textfieldMaBS.setBounds(150, 80, 115, 20);
		textfieldMaBS.setColumns(10);
		panel1.add(textfieldMaBS);
		
		JLabel labelMaBenh = new JLabel("Ma Benh : ");
		labelMaBenh.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMaBenh.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaBenh.setBounds(30, 120, 115, 20);
		panel1.add(labelMaBenh);
		
		textfieldMaBenh = new JTextField();
		textfieldMaBenh.setColumns(10);
		textfieldMaBenh.setBounds(150, 120, 115, 20);
		panel1.add(textfieldMaBenh);
		
		JLabel labelMaPhong = new JLabel("Ma Phong : ");
		labelMaPhong.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMaPhong.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMaPhong.setBounds(30, 160, 115, 20);
		panel1.add(labelMaPhong);
		
		textfieldMaPhong = new JTextField();
		textfieldMaPhong.setColumns(10);
		textfieldMaPhong.setBounds(150, 160, 115, 20);
		panel1.add(textfieldMaPhong);
		
		JLabel labelHinhThuc = new JLabel("Hinh Thuc : ");
		labelHinhThuc.setHorizontalAlignment(SwingConstants.RIGHT);
		labelHinhThuc.setFont(new Font("Bevan", Font.BOLD, 12));
		labelHinhThuc.setBounds(30, 200, 115, 20);
		panel1.add(labelHinhThuc);

		rbuttonTaiGia = new JRadioButton("Tai gia");
		rbuttonTaiGia.setBackground(Color.decode("#d6e7ef"));
		rbuttonTaiGia.setBounds(150, 200, 70, 20);
		rbuttonTaiGia.setActionCommand("Tai gia");
		panel1.add(rbuttonTaiGia);
		
		rbuttonNhapVien = new JRadioButton("Nhap vien");
		rbuttonNhapVien.setBackground(Color.decode("#d6e7ef"));
		rbuttonNhapVien.setBounds(220, 200, 90, 20);
		rbuttonNhapVien.setActionCommand("Nhap vien");
		panel1.add(rbuttonNhapVien);
		
		rbuttonCachLy = new JRadioButton("Cach ly");
		rbuttonCachLy.setBackground(Color.decode("#d6e7ef"));
		rbuttonCachLy.setBounds(310, 200, 70, 20);
		rbuttonCachLy.setActionCommand("Cach ly");
		panel1.add(rbuttonCachLy);
		
		bgroupHinhThuc = new ButtonGroup();
		bgroupHinhThuc.add(rbuttonTaiGia);
		bgroupHinhThuc.add(rbuttonNhapVien);
		bgroupHinhThuc.add(rbuttonCachLy);

		JLabel labelMucDo = new JLabel("Muc Do : ");
		labelMucDo.setHorizontalAlignment(SwingConstants.RIGHT);
		labelMucDo.setFont(new Font("Bevan", Font.BOLD, 12));
		labelMucDo.setBounds(300, 40, 115, 20);
		panel1.add(labelMucDo);
		
		comboBoxMucDo = new JComboBox(listMucDo);
		comboBoxMucDo.setBounds(420, 40, 115, 20);
		panel1.add(comboBoxMucDo);
		
		JLabel labelTinhTrang = new JLabel("Tinh Trang : ");
		labelTinhTrang.setHorizontalAlignment(SwingConstants.RIGHT);
		labelTinhTrang.setFont(new Font("Bevan", Font.BOLD, 12));
		labelTinhTrang.setBounds(300, 80, 115, 20);
		panel1.add(labelTinhTrang);
		
		comboBoxTinhTrang = new JComboBox(listTinhTrang);
		comboBoxTinhTrang.setBounds(420, 80, 115, 20);
		panel1.add(comboBoxTinhTrang);
		
		JLabel labelNgayBatDau = new JLabel("Bat Dau: ");
		labelNgayBatDau.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgayBatDau.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgayBatDau.setBounds(300, 120, 115, 20);
		panel1.add(labelNgayBatDau);
		
		NgayBatDau = new JDateChooser();
		NgayBatDau.setBounds(420, 120, 115, 20);
		NgayBatDau.setFont(new Font("Bevan", Font.PLAIN, 12));
		NgayBatDau.setDateFormatString("dd/MM/yyyy");
		NgayBatDau.setDate(Calendar.getInstance().getTime());
		panel1.add(NgayBatDau);
		
		SpinnerDateModel modelNgayBatDau = new SpinnerDateModel();
        modelNgayBatDau.setValue(Calendar.getInstance().getTime());
        spinnerNgayBatDau = new JSpinner(modelNgayBatDau);
        JSpinner.DateEditor editorNgayBatDau = new JSpinner.DateEditor(spinnerNgayBatDau, "HH:mm:ss");
        spinnerNgayBatDau.setEditor(editorNgayBatDau);
        spinnerNgayBatDau.setBounds(540, 120, 80, 20);
        panel1.add(spinnerNgayBatDau);
        DateFormatter formatterNgayBatDau = (DateFormatter)editorNgayBatDau.getTextField().getFormatter();
        formatterNgayBatDau.setAllowsInvalid(false);
        formatterNgayBatDau.setOverwriteMode(true);
		
		JLabel labelNgayKetThuc = new JLabel("Ket Thuc: ");
		labelNgayKetThuc.setHorizontalAlignment(SwingConstants.RIGHT);
		labelNgayKetThuc.setFont(new Font("Bevan", Font.BOLD, 12));
		labelNgayKetThuc.setBounds(300, 160, 115, 20);
		panel1.add(labelNgayKetThuc);
		
		NgayKetThuc = new JDateChooser();
		NgayKetThuc.setBounds(420, 160, 115, 20);
		NgayKetThuc.setFont(new Font("Bevan", Font.PLAIN, 12));
		NgayKetThuc.setDateFormatString("dd/MM/yyyy");
		NgayKetThuc.setDate(Calendar.getInstance().getTime());
		panel1.add(NgayKetThuc);
		
		SpinnerDateModel modelNgayKetThuc = new SpinnerDateModel();
        modelNgayKetThuc.setValue(Calendar.getInstance().getTime());
        spinnerNgayKetThuc = new JSpinner(modelNgayKetThuc);
        JSpinner.DateEditor editorNgayKetThuc = new JSpinner.DateEditor(spinnerNgayKetThuc, "HH:mm:ss");
        spinnerNgayKetThuc.setEditor(editorNgayKetThuc);
        spinnerNgayKetThuc.setBounds(540, 160, 80, 20);
        panel1.add(spinnerNgayKetThuc);
        DateFormatter formatterNgayKetThuc = (DateFormatter)editorNgayKetThuc.getTextField().getFormatter();
        formatterNgayKetThuc.setAllowsInvalid(false);
        formatterNgayKetThuc.setOverwriteMode(true);
		
		buttonThem = new JButton("    Them    ");
		buttonThem.setForeground(Color.decode("#28526a"));
		buttonThem.setBackground(Color.decode("#91B6C9"));
		buttonThem.addActionListener(this);
		buttonThem.setFont(new Font("Bevan", Font.BOLD, 12));
		//buttonThem.setBounds(80, 30, 85, 21);
		buttonThem.setBorderPainted(false);
		panel2.add(buttonThem);
	
	}
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == buttonThem) {
			Them();
		}
	}
	
	public void Them() {
		
		String stringNgayBatDau = "", stringSpinnerNgayBatDau = "", stringBatDau = "NULL";
		if (NgayBatDau.getDate() != null) {
			Date date = NgayBatDau.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			stringNgayBatDau = sdf.format(date);
			
			date = (Date)spinnerNgayBatDau.getValue();
            sdf = new SimpleDateFormat("HH:mm:ss");
            stringSpinnerNgayBatDau = sdf.format(date);
            stringBatDau = stringNgayBatDau + " " + stringSpinnerNgayBatDau;
		}
		
		String stringNgayKetThuc = "", stringSpinnerNgayKetThuc = "", stringKetThuc = "NULL";
		if (NgayKetThuc.getDate() != null) {
			Date date = NgayKetThuc.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			stringNgayKetThuc = sdf.format(date);
			
			date = (Date)spinnerNgayKetThuc.getValue();
            sdf = new SimpleDateFormat("HH:mm:ss");
            stringSpinnerNgayKetThuc = sdf.format(date);
            stringKetThuc = stringNgayKetThuc + " " + stringSpinnerNgayKetThuc;
		}
		
		String stringHinhThuc = ""; 
		if (bgroupHinhThuc.getSelection() != null) {
			stringHinhThuc = bgroupHinhThuc.getSelection().getActionCommand();
		}				

		try {
			Connection connection = MyHome.getDatabase().getConnection();
			CallableStatement statement = connection.prepareCall("{ call rootdata.proc_cabenh_them1cabenh (?,?,?,?,?,?,?,?,?,?,?) }");
			statement.setString(1,textfieldMaCa.getText());
			statement.setString(2,textfieldMaBN.getText());
			statement.setString(3,textfieldMaBS.getText());
			statement.setString(4,textfieldMaBenh.getText());
			statement.setString(5,(String) comboBoxMucDo.getItemAt(comboBoxMucDo.getSelectedIndex()));
			statement.setString(6,stringHinhThuc);
			statement.setString(7,stringBatDau);
			statement.setString(8,stringKetThuc);
			statement.setString(9,(String) comboBoxTinhTrang.getItemAt(comboBoxTinhTrang.getSelectedIndex()));
			statement.setString(10,textfieldMaPhong.getText());
			statement.registerOutParameter(11,Types.INTEGER);
			
			statement.execute();
			
			int changedrows = (int) statement.getObject(11);
			if (changedrows > 0) {
				JOptionPane.showMessageDialog(null, "Them Moi Thanh Cong", "Thong Bao", JOptionPane.INFORMATION_MESSAGE);
				textfieldMaCa.setText("CA0" + Integer.toString(++maxRow));
			}
			
			statement.close();
			
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		//Refresh();
	}
	
	public int getMaxRow(){
        int maxRow = -1, compareNum;

		try {
			Connection connection = MyHome.getDatabase().getConnection();
			CallableStatement statement = connection.prepareCall("{ call rootdata.proc_cabenh_laycabenh (?) }");
			statement.registerOutParameter(1, OracleTypes.CURSOR);
			statement.execute();
			ResultSet resultset = (ResultSet) statement.getObject(1);
			while(resultset.next()) {
	                        compareNum = Integer.parseInt(resultset.getString("MACA").substring(2));
	                        if(compareNum > maxRow){
	                            maxRow = compareNum;
	                        }
			} 
			statement.close();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Loi: " + e.getMessage(), "Loi", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
        return (maxRow + 1);
    }
	
	public void Refresh() {
		textfieldMaCa.setText("");
		textfieldMaBN.setText("");
		textfieldMaBS.setText("");
		textfieldMaBenh.setText("");
		textfieldMaPhong.setText("");
		bgroupHinhThuc.clearSelection();
		NgayBatDau.setDate(Calendar.getInstance().getTime());
		NgayKetThuc.setDate(Calendar.getInstance().getTime());
		comboBoxMucDo.setSelectedIndex(0);
		comboBoxTinhTrang.setSelectedIndex(0);
		
		SpinnerDateModel modelNgayBatDau = new SpinnerDateModel();
        modelNgayBatDau.setValue(Calendar.getInstance().getTime());
        spinnerNgayBatDau.setModel(modelNgayBatDau);
        JSpinner.DateEditor editorNgayBatDau = new JSpinner.DateEditor(spinnerNgayBatDau, "HH:mm:ss");
        spinnerNgayBatDau.setEditor(editorNgayBatDau);
        DateFormatter formatterNgayBatDau = (DateFormatter)editorNgayBatDau.getTextField().getFormatter();
        formatterNgayBatDau.setAllowsInvalid(false);
        formatterNgayBatDau.setOverwriteMode(true);
        
        SpinnerDateModel modelNgayKetThuc = new SpinnerDateModel();
        modelNgayKetThuc.setValue(Calendar.getInstance().getTime());
        spinnerNgayKetThuc.setModel(modelNgayKetThuc);
        JSpinner.DateEditor editorNgayKetThuc = new JSpinner.DateEditor(spinnerNgayKetThuc, "HH:mm:ss");
        spinnerNgayKetThuc.setEditor(editorNgayKetThuc);
        DateFormatter formatterNgayKetThuc = (DateFormatter)editorNgayKetThuc.getTextField().getFormatter();
        formatterNgayKetThuc.setAllowsInvalid(false);
        formatterNgayKetThuc.setOverwriteMode(true);
	}
	
	public JPanel getpanelContent() {
		return panelContent;
	}
}
